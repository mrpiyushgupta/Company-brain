export interface EntityRef {
  id: string;
  name: string;
  type: string;
  subtitle?: string;
  extra?: Record<string, any>;
}

export interface Department {
  id: string;
  name: string;
  district: string;
  description: string;
  color: string;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
}

export interface EmployeeSummary {
  id: string;
  name: string;
  title: string;
  role: string;
  department_id: string;
  department_name?: string;
  email: string;
  avatar: string;
}

export interface EmployeeProfile {
  id: string;
  name: string;
  title: string;
  role: string;
  department_id: string;
  department_name?: string;
  email: string;
  avatar: string;
  bio: string;
  manager?: EntityRef;
  direct_reports: EntityRef[];
  skills: Skill[];
  projects: EntityRef[];
  tasks: EntityRef[];
  systems_owned: EntityRef[];
  incidents_resolved: EntityRef[];
  documents_authored: EntityRef[];
  collaborators: EntityRef[];
  connections: string[];
}

export interface ProjectBuilding {
  id: string;
  name: string;
  department_id: string;
  department_name?: string;
  status: string;
  priority: string;
  district_x: number;
  district_y: number;
  team_count: number;
  description: string;
  risks?: string;
}

export interface ProjectDetail {
  id: string;
  name: string;
  department_id: string;
  department_name?: string;
  status: string;
  priority: string;
  district_x: number;
  district_y: number;
  description: string;
  risks?: string;
  team_members: EntityRef[];
  systems_used: EntityRef[];
  dependencies: EntityRef[];
  tasks: EntityRef[];
  decisions: EntityRef[];
  documents: EntityRef[];
  incidents: EntityRef[];
}

export interface SystemModel {
  id: string;
  name: string;
  tier: string;
  technology: string;
  description: string;
  health_status: string;
  owners: EntityRef[];
  used_by_projects: EntityRef[];
  incidents: EntityRef[];
}

export interface DocumentModel {
  id: string;
  title: string;
  doc_type: string;
  summary: string;
  content: string;
  url?: string;
}

export interface DecisionModel {
  id: string;
  title: string;
  status: string;
  decided_at: string;
  rationale: string;
}

export interface IncidentModel {
  id: string;
  title: string;
  severity: string;
  status: string;
  root_cause: string;
  summary: string;
}

export interface CityData {
  company_name: string;
  departments: Department[];
  projects: ProjectBuilding[];
  employees: EmployeeSummary[];
  systems: SystemModel[];
  stats: Record<string, number>;
}

export interface GraphNode {
  id: string;
  label: string;
  type: string;
  properties: Record<string, any>;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: string;
  label: string;
  properties: Record<string, any>;
}

export interface GraphNeighborhood {
  center_id: string;
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface PathQueryResponse {
  found: boolean;
  nodes: GraphNode[];
  edges: GraphEdge[];
  explanation: string;
}

export interface ToolCallTrace {
  tool: string;
  args: Record<string, any>;
  row_count?: number;
}

export interface AssistantQueryResponse {
  question: string;
  answer: string;
  intent: string;
  agent?: string;
  tools_called?: ToolCallTrace[];
  tool_trace?: ToolCallTrace[];
  cypher_executed: string[] | string;
  graph_path?: Array<{ from: string; rel?: string; type?: string; to: string; direction?: string }>;
  evidence_path: string[];
  supporting_entities: EntityRef[];
  source_records: Array<{ id: string; type: string; title: string; snippet?: string; date?: string }>;
  highlighted_entity_ids: string[];
  session_id?: string;
  limitations?: string;
}

export interface HealthStatus {
  status: string;
  falkordb_connected: boolean;
  graph_name: string;
  node_count: number;
  edge_count: number;
  error?: string;
}

export interface CompanyInfo {
  id: string;
  name: string;
  industry: string;
  description: string;
  graph_name: string;
  node_count: number;
  edge_count: number;
}

