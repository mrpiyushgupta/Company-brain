import React, { useState, useEffect, useCallback } from 'react';
import ReactFlow, {
  Controls,
  Background,
  applyNodeChanges,
  applyEdgeChanges,
  Node,
  Edge,
  NodeChange,
  EdgeChange,
  Connection,
  MarkerType
} from 'reactflow';
import 'reactflow/dist/style.css';
import { 
  Network, Search, Compass, Eye, Filter, Sparkles, 
  ArrowRight, User, Briefcase, Server, AlertTriangle, 
  GitCommit, FileText, Award, RefreshCw, X
} from 'lucide-react';
import { api } from '../../services/api';
import { GraphNeighborhood, PathQueryResponse } from '../../types';

interface GraphExplorerProps {
  initialEntityId?: string;
  onSelectEmployee: (id: string) => void;
  onSelectProject: (id: string) => void;
}

const entityColors: Record<string, { bg: string; border: string; text: string; glow: string }> = {
  Employee: { bg: '#0369a1', border: '#38bdf8', text: '#e0f2fe', glow: 'rgba(56, 189, 248, 0.4)' },
  Project: { bg: '#581c87', border: '#c084fc', text: '#faf5ff', glow: 'rgba(192, 132, 252, 0.4)' },
  System: { bg: '#047857', border: '#34d399', text: '#ecfdf5', glow: 'rgba(52, 211, 153, 0.4)' },
  Incident: { bg: '#881337', border: '#fb7185', text: '#fff1f2', glow: 'rgba(251, 113, 133, 0.4)' },
  Decision: { bg: '#78350f', border: '#fbbf24', text: '#fffbeb', glow: 'rgba(251, 191, 36, 0.4)' },
  Document: { bg: '#1e3a8a', border: '#60a5fa', text: '#eff6ff', glow: 'rgba(96, 165, 250, 0.4)' },
  Department: { bg: '#1e293b', border: '#94a3b8', text: '#f8fafc', glow: 'rgba(148, 163, 184, 0.4)' },
  Skill: { bg: '#854d0e', border: '#facc15', text: '#fefce8', glow: 'rgba(250, 204, 21, 0.4)' },
};

export const GraphExplorer: React.FC<GraphExplorerProps> = ({
  initialEntityId = 'emp_maya',
  onSelectEmployee,
  onSelectProject,
}) => {
  const [currentCenterId, setCurrentCenterId] = useState<string>(initialEntityId);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<Edge | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  
  // Path Finding controls
  const [sourceId, setSourceId] = useState<string>('emp_maya');
  const [targetId, setTargetId] = useState<string>('sys_payment');
  const [pathResult, setPathResult] = useState<PathQueryResponse | null>(null);
  const [pathLoading, setPathLoading] = useState<boolean>(false);

  // Search
  const [searchEntity, setSearchEntity] = useState<string>('');

  // Load neighborhood
  const loadNeighborhood = useCallback((entityId: string) => {
    setLoading(true);
    setCurrentCenterId(entityId);
    api.getNeighborhood(entityId, 1)
      .then((data: GraphNeighborhood) => {
        // Lay out nodes radially around center
        const centerNode = data.nodes.find(n => n.id === entityId) || data.nodes[0];
        const otherNodes = data.nodes.filter(n => n.id !== centerNode?.id);
        
        const newNodes: Node[] = [];
        
        // Center node at (400, 300)
        if (centerNode) {
          const style = entityColors[centerNode.type] || entityColors.Employee;
          newNodes.push({
            id: centerNode.id,
            position: { x: 400, y: 280 },
            data: { 
              label: (
                <div className="p-3 rounded-xl border-2 text-center select-none shadow-2xl" style={{ backgroundColor: style.bg, borderColor: style.border, color: style.text, boxShadow: `0 0 20px ${style.glow}` }}>
                  <div className="text-[10px] uppercase font-bold tracking-wider opacity-80">{centerNode.type}</div>
                  <div className="font-bold text-xs mt-0.5">{centerNode.label}</div>
                  <div className="text-[9px] opacity-75 mt-0.5">Center Focus</div>
                </div>
              ),
              raw: centerNode
            }
          });
        }

        // Surrounding nodes
        otherNodes.forEach((node, idx) => {
          const angle = (idx / otherNodes.length) * 2 * Math.PI;
          const radius = 230;
          const x = 400 + Math.cos(angle) * radius;
          const y = 280 + Math.sin(angle) * radius;
          const style = entityColors[node.type] || entityColors.Employee;

          newNodes.push({
            id: node.id,
            position: { x, y },
            data: {
              label: (
                <div className="p-2.5 rounded-lg border text-center select-none shadow-lg cursor-pointer hover:scale-105 transition-transform" style={{ backgroundColor: style.bg, borderColor: style.border, color: style.text }}>
                  <div className="text-[9px] uppercase font-bold tracking-wider opacity-80">{node.type}</div>
                  <div className="font-semibold text-xs mt-0.5">{node.label}</div>
                </div>
              ),
              raw: node
            }
          });
        });

        const newEdges: Edge[] = data.edges.map(e => ({
          id: e.id,
          source: e.source,
          target: e.target,
          label: e.label,
          type: 'default',
          animated: true,
          style: { stroke: '#38bdf8', strokeWidth: 1.5 },
          labelStyle: { fill: '#94a3b8', fontSize: 10, fontWeight: 500 },
          labelBgStyle: { fill: '#0f172a', fillOpacity: 0.85, rx: 4, ry: 4 },
          markerEnd: { type: MarkerType.ArrowClosed, color: '#38bdf8' }
        }));

        setNodes(newNodes);
        setEdges(newEdges);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    loadNeighborhood(initialEntityId);
  }, [initialEntityId, loadNeighborhood]);

  const onNodesChange = useCallback(
    (changes: NodeChange[]) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const onEdgesChange = useCallback(
    (changes: EdgeChange[]) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    []
  );

  const onNodeClick = (_: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
    setSelectedEdge(null);
  };

  const onEdgeClick = (_: React.MouseEvent, edge: Edge) => {
    setSelectedEdge(edge);
    setSelectedNode(null);
  };

  // Run shortest path query
  const handleFindPath = () => {
    if (!sourceId || !targetId) return;
    setPathLoading(true);
    api.findPath(sourceId, targetId)
      .then((res) => {
        setPathResult(res);
        setPathLoading(false);
        // If path found, center on source
        if (res.found && res.nodes.length > 0) {
          loadNeighborhood(res.nodes[0].id);
        }
      })
      .catch((err) => {
        console.error(err);
        setPathLoading(false);
      });
  };

  return (
    <div className="flex h-full bg-[#0b0f19] text-slate-100 overflow-hidden">
      {/* Main Canvas Area */}
      <div className="flex-1 flex flex-col h-full relative">
        {/* Top Control Bar */}
        <div className="p-3 bg-[#0f172a]/95 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 z-10">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-cyan-400" />
              Focus Center:
            </span>
            <span className="px-2.5 py-1 bg-slate-800 text-cyan-300 font-mono text-xs rounded-md border border-slate-700">
              {currentCenterId}
            </span>
            <button
              onClick={() => loadNeighborhood(currentCenterId)}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              title="Refresh Neighborhood"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Path Finding Quick Controls */}
          <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-lg border border-slate-800 text-xs">
            <span className="text-slate-400 text-[11px] font-semibold">Traverse Path:</span>
            <input
              type="text"
              placeholder="Source ID"
              value={sourceId}
              onChange={(e) => setSourceId(e.target.value)}
              className="w-24 bg-slate-800 border border-slate-700 rounded px-2 py-0.5 text-xs text-slate-200"
            />
            <span className="text-slate-500">→</span>
            <input
              type="text"
              placeholder="Target ID"
              value={targetId}
              onChange={(e) => setTargetId(e.target.value)}
              className="w-28 bg-slate-800 border border-slate-700 rounded px-2 py-0.5 text-xs text-slate-200"
            />
            <button
              onClick={handleFindPath}
              disabled={pathLoading}
              className="px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors cursor-pointer"
            >
              {pathLoading ? 'Finding...' : 'Find Path'}
            </button>
          </div>

          {/* Quick Preset Centers */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs">
            <span className="text-slate-400 text-[11px]">Jump:</span>
            {['emp_maya', 'proj_atlas', 'sys_payment', 'inc_104', 'dec_202'].map(id => (
              <button
                key={id}
                onClick={() => loadNeighborhood(id)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono border transition-colors ${
                  currentCenterId === id 
                    ? 'bg-blue-600/30 border-blue-500 text-blue-200' 
                    : 'bg-slate-850 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {id}
              </button>
            ))}
          </div>
        </div>

        {/* Path Result Banner */}
        {pathResult && (
          <div className="p-3 bg-gradient-to-r from-blue-950/80 to-slate-900 border-b border-blue-900/60 flex items-center justify-between text-xs text-blue-200 animate-fade-in z-10">
            <div className="flex items-center gap-2 max-w-4xl overflow-x-auto">
              <span className="font-bold text-cyan-300 whitespace-nowrap">Traversed Path:</span>
              <span className="font-mono text-slate-300">{pathResult.explanation}</span>
            </div>
            <button onClick={() => setPathResult(null)} className="text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* React Flow Interactive Canvas */}
        <div className="flex-1 h-full w-full relative">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            onEdgeClick={onEdgeClick}
            fitView
            className="bg-[#090d16]"
          >
            <Background color="#1e293b" gap={20} size={1} />
            <Controls className="bg-slate-900 border-slate-700 text-white fill-white" />
          </ReactFlow>

          {/* Entity Type Legend Overlay */}
          <div className="absolute bottom-4 left-4 z-10 bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 text-[11px] space-y-1.5 shadow-xl pointer-events-none">
            <div className="font-bold text-slate-300 mb-1">Graph Entity Types</div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1">
              {Object.entries(entityColors).map(([type, style]) => (
                <div key={type} className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: style.border }} />
                  <span className="text-slate-300">{type}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Detail Inspector Drawer (Right Side) */}
      <div className="w-80 border-l border-slate-800 bg-[#0f172a] p-4 flex flex-col justify-between overflow-y-auto">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Graph Entity Inspector
            </h3>
            {selectedNode && (
              <button onClick={() => setSelectedNode(null)} className="text-slate-500 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {selectedNode ? (
            <div className="space-y-4 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-800 text-cyan-300">
                  {selectedNode.data.raw?.type}
                </span>
                <h4 className="text-base font-bold text-white mt-1.5">{selectedNode.data.raw?.label}</h4>
                <div className="font-mono text-slate-400 text-[11px]">ID: {selectedNode.id}</div>
              </div>

              {/* Node Properties */}
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-400 text-[11px]">PROPERTIES</div>
                {Object.entries(selectedNode.data.raw?.properties || {}).map(([key, val]) => (
                  <div key={key} className="text-slate-300 flex flex-col">
                    <span className="text-[10px] text-slate-500 uppercase">{key}</span>
                    <span className="text-slate-200 break-words">{String(val)}</span>
                  </div>
                ))}
              </div>

              {/* Action buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={() => loadNeighborhood(selectedNode.id)}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-lg text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Expand Neighborhood</span>
                </button>

                {selectedNode.data.raw?.type === 'Employee' && (
                  <button
                    onClick={() => onSelectEmployee(selectedNode.id)}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>Open Employee Profile</span>
                  </button>
                )}

                {selectedNode.data.raw?.type === 'Project' && (
                  <button
                    onClick={() => onSelectProject(selectedNode.id)}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Briefcase className="w-3.5 h-3.5" />
                    <span>Open Project Details</span>
                  </button>
                )}
              </div>
            </div>
          ) : selectedEdge ? (
            <div className="space-y-3 text-xs">
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-800 text-blue-300">
                RELATIONSHIP EDGE
              </span>
              <h4 className="text-sm font-bold text-white mt-1">{selectedEdge.label}</h4>
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
                <div className="text-slate-400">Source: <span className="text-cyan-300">{selectedEdge.source}</span></div>
                <div className="text-slate-400">Target: <span className="text-emerald-300">{selectedEdge.target}</span></div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500">
              <Network className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-xs">Click any node or relationship edge in the graph canvas to inspect its schema and properties.</p>
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500">
          Powered by FalkorDB Graph Traversal
        </div>
      </div>
    </div>
  );
};
