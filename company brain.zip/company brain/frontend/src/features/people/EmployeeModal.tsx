import React, { useEffect, useState } from 'react';
import { 
  X, User, Mail, Briefcase, Award, CheckSquare, Server, 
  AlertCircle, FileText, Users, Network, ArrowRight, Loader2
} from 'lucide-react';
import { EmployeeProfile } from '../../types';
import { api } from '../../services/api';

interface EmployeeModalProps {
  employeeId: string;
  onClose: () => void;
  onSelectEmployee: (id: string) => void;
  onSelectProject: (id: string) => void;
  onSelectSystem?: (id: string) => void;
  onExploreGraph: (id: string) => void;
}

export const EmployeeModal: React.FC<EmployeeModalProps> = ({
  employeeId,
  onClose,
  onSelectEmployee,
  onSelectProject,
  onSelectSystem,
  onExploreGraph,
}) => {
  const [profile, setProfile] = useState<EmployeeProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    api.getEmployeeProfile(employeeId)
      .then((data) => {
        if (isMounted) {
          setProfile(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Failed to load employee profile');
          setLoading(false);
        }
      });

    return () => { isMounted = false; };
  }, [employeeId]);

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-8 max-w-md w-full flex flex-col items-center text-center">
          <Loader2 className="w-8 h-8 text-blue-500 animate-spin mb-3" />
          <h3 className="text-white font-semibold text-sm">Traversing FalkorDB Knowledge Graph...</h3>
          <p className="text-slate-400 text-xs mt-1">Retrieving employee records & connected relationships</p>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 max-w-md w-full text-center">
          <AlertCircle className="w-10 h-10 text-rose-500 mx-auto mb-2" />
          <h3 className="text-white font-semibold">Employee Record Not Found</h3>
          <p className="text-slate-400 text-xs mt-1 mb-4">{error || 'Record is not documented in company graph.'}</p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0f172a] border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-gradient-to-r from-slate-900 to-slate-850 flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img
                src={profile.avatar}
                alt={profile.name}
                className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-blue-500/50 p-1 object-cover shadow-lg"
              />
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#0f172a]" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                {profile.name}
              </h2>
              <p className="text-sm text-cyan-400 font-medium">{profile.title}</p>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                <span>🏢 {profile.department_name || 'Engineering'}</span>
                <span>•</span>
                <span>Role: {profile.role}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onExploreGraph(profile.id)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/40 rounded-lg text-xs font-medium transition-colors cursor-pointer"
              title="Open in Knowledge Graph Explorer"
            >
              <Network className="w-3.5 h-3.5" />
              <span>Explore Graph</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-300">
          {/* Bio */}
          <div className="bg-slate-900/80 rounded-xl p-3.5 border border-slate-800/80">
            <p className="text-slate-300 leading-relaxed">{profile.bio}</p>
          </div>

          {/* Dedicated Graph Connections Section */}
          <div className="bg-gradient-to-r from-blue-950/40 to-slate-900 p-4 rounded-xl border border-blue-900/50">
            <div className="flex items-center gap-2 text-cyan-300 font-semibold text-xs mb-2.5">
              <Network className="w-4 h-4 text-cyan-400" />
              <span>GRAPH CONNECTIONS (MULTI-HOP EVIDENCE)</span>
            </div>
            {profile.connections && profile.connections.length > 0 ? (
              <div className="space-y-1.5 font-mono text-[11px]">
                {profile.connections.map((conn, idx) => (
                  <div key={idx} className="p-2 rounded bg-slate-900/90 border border-slate-800/80 text-blue-200 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    <span>{conn}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-slate-500 italic">No multi-hop connections documented.</p>
            )}
          </div>

          {/* Reporting Structure */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-blue-400" />
                <span>MANAGER (REPORTS_TO)</span>
              </div>
              {profile.manager ? (
                <button
                  onClick={() => onSelectEmployee(profile.manager!.id)}
                  className="w-full text-left p-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between group transition-colors"
                >
                  <div>
                    <div className="font-semibold text-white group-hover:text-cyan-300 transition-colors">
                      {profile.manager.name}
                    </div>
                    <div className="text-[10px] text-slate-400">{profile.manager.subtitle}</div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition-colors" />
                </button>
              ) : (
                <div className="text-slate-500 italic">Not documented / Reports to CEO</div>
              )}
            </div>

            <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span>DIRECT REPORTS ({profile.direct_reports.length})</span>
              </div>
              {profile.direct_reports.length > 0 ? (
                <div className="space-y-1.5 max-h-28 overflow-y-auto">
                  {profile.direct_reports.map((report) => (
                    <button
                      key={report.id}
                      onClick={() => onSelectEmployee(report.id)}
                      className="w-full text-left p-1.5 rounded bg-slate-800/40 hover:bg-slate-800 flex items-center justify-between group text-slate-200"
                    >
                      <span>{report.name} ({report.subtitle})</span>
                      <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-cyan-400" />
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No direct reports documented</div>
              )}
            </div>
          </div>

          {/* Skills & Expertise */}
          <div>
            <div className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>SKILLS & DOMAIN EXPERTISE</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {profile.skills.length > 0 ? (
                profile.skills.map((skill) => (
                  <span
                    key={skill.id}
                    className="px-2.5 py-1 rounded-full bg-slate-800 text-amber-300 border border-amber-500/30 text-[11px] font-medium"
                  >
                    {skill.name} • <span className="text-slate-400">{skill.category}</span>
                  </span>
                ))
              ) : (
                <span className="text-slate-500 italic">Not documented</span>
              )}
            </div>
          </div>

          {/* Active Projects & Systems Owned */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-indigo-400" />
                <span>ACTIVE PROJECTS (WORKED_ON)</span>
              </div>
              {profile.projects.length > 0 ? (
                <div className="space-y-1.5">
                  {profile.projects.map((proj) => (
                    <button
                      key={proj.id}
                      onClick={() => onSelectProject(proj.id)}
                      className="w-full text-left p-2 rounded-lg bg-slate-900 border border-slate-800 hover:border-indigo-500/50 flex items-center justify-between group transition-colors"
                    >
                      <span className="font-medium text-white group-hover:text-indigo-300">{proj.name}</span>
                      <span className="text-[10px] text-indigo-400">{proj.subtitle}</span>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">Not assigned to active projects</div>
              )}
            </div>

            <div>
              <div className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
                <Server className="w-3.5 h-3.5 text-teal-400" />
                <span>SYSTEMS OWNED (OWNS)</span>
              </div>
              {profile.systems_owned.length > 0 ? (
                <div className="space-y-1.5">
                  {profile.systems_owned.map((sys) => (
                    <div
                      key={sys.id}
                      className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between"
                    >
                      <span className="font-medium text-white">{sys.name}</span>
                      <span className="text-[10px] text-teal-400">{sys.subtitle}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No systems officially owned</div>
              )}
            </div>
          </div>

          {/* Incidents Resolved & Authored Documents */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>INCIDENTS RESOLVED ({profile.incidents_resolved.length})</span>
              </div>
              {profile.incidents_resolved.length > 0 ? (
                <div className="space-y-1.5">
                  {profile.incidents_resolved.map((inc) => (
                    <div key={inc.id} className="p-2 rounded-lg bg-rose-950/20 border border-rose-900/40 text-rose-200">
                      <div className="font-semibold text-rose-300">{inc.name}</div>
                      <div className="text-[10px] text-slate-400">{inc.subtitle}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No incidents resolved in record</div>
              )}
            </div>

            <div>
              <div className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                <span>DOCUMENTS AUTHORED ({profile.documents_authored.length})</span>
              </div>
              {profile.documents_authored.length > 0 ? (
                <div className="space-y-1.5">
                  {profile.documents_authored.map((doc) => (
                    <div key={doc.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200">
                      <div className="font-medium text-blue-300">{doc.name}</div>
                      <div className="text-[10px] text-slate-400">{doc.subtitle}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No documents authored in record</div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/80 flex items-center justify-between text-xs text-slate-400">
          <span>ID: <code className="text-slate-300 font-mono">{profile.id}</code></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
