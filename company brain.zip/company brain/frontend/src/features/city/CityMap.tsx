import React, { useState, useMemo } from 'react';
import { 
  Building2, Users, AlertTriangle, CheckCircle, Clock, 
  Layers, MapPin, Eye, Sparkles, Filter, RotateCcw, Search, X, ArrowRight, Network
} from 'lucide-react';
import { CityData, Department, ProjectBuilding, EmployeeSummary } from '../../types';

interface CityMapProps {
  data: CityData;
  onSelectEmployee: (id: string) => void;
  onSelectProject: (id: string) => void;
  onExploreInGraph?: (id: string) => void;
  highlightedEntityIds?: string[];
  searchQuery: string;
}

export const CityMap: React.FC<CityMapProps> = ({
  data,
  onSelectEmployee,
  onSelectProject,
  onExploreInGraph,
  highlightedEntityIds = [],
  searchQuery,
}) => {
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Steady Inspector state (never flickers)
  const [activeEntity, setActiveEntity] = useState<{
    id: string;
    name: string;
    type: 'employee' | 'project';
    titleOrStatus: string;
    department: string;
    details: string;
    avatar?: string;
  } | null>(null);

  // Filter projects
  const filteredProjects = useMemo(() => {
    return data.projects.filter(p => {
      const matchesSearch = !searchQuery || 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDistrict = !selectedDistrict || p.department_id === selectedDistrict;
      const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
      return matchesSearch && matchesDistrict && matchesStatus;
    });
  }, [data.projects, searchQuery, selectedDistrict, statusFilter]);

  // Filter employees
  const filteredEmployees = useMemo(() => {
    return data.employees.filter(e => {
      const matchesSearch = !searchQuery || 
        e.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.role.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDistrict = !selectedDistrict || e.department_id === selectedDistrict;
      return matchesSearch && matchesDistrict;
    });
  }, [data.employees, searchQuery, selectedDistrict]);

  // Coordinates mapping for employees around their departments
  const employeeCoords = useMemo(() => {
    const coords: Record<string, { x: number; y: number }> = {};
    const deptAnchors: Record<string, { x: number; y: number }> = {
      dept_eng: { x: 260, y: 190 },
      dept_prod: { x: 740, y: 190 },
      dept_ops: { x: 260, y: 490 },
      dept_research: { x: 740, y: 490 }
    };

    const counts: Record<string, number> = { dept_eng: 0, dept_prod: 0, dept_ops: 0, dept_research: 0 };

    data.employees.forEach(emp => {
      const dept = emp.department_id || 'dept_eng';
      const anchor = deptAnchors[dept] || { x: 500, y: 350 };
      const idx = counts[dept] || 0;
      counts[dept] = idx + 1;

      // Arrange in a soft circular orbit around department zone
      const angle = (idx * (2 * Math.PI / 6)) + (idx > 5 ? 0.5 : 0);
      const radius = idx < 6 ? 65 : 105;
      coords[emp.id] = {
        x: Math.round(anchor.x + Math.cos(angle) * radius),
        y: Math.round(anchor.y + Math.sin(angle) * radius)
      };
    });
    return coords;
  }, [data.employees]);

  const handleResetFilters = () => {
    setSelectedDistrict(null);
    setStatusFilter('all');
    setActiveEntity(null);
  };

  const isHighlighted = (id: string) => {
    return highlightedEntityIds.includes(id) || activeEntity?.id === id;
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 select-none">
      {/* Top Filter Controls */}
      <div className="px-6 py-2.5 bg-[#0f172a]/95 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* District Filter Buttons */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            Districts:
          </span>
          <button
            onClick={() => setSelectedDistrict(null)}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              selectedDistrict === null
                ? 'bg-blue-600 text-white font-medium'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            All Campus
          </button>
          {data.departments.map((dept) => (
            <button
              key={dept.id}
              onClick={() => setSelectedDistrict(dept.id)}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                selectedDistrict === dept.id
                  ? 'bg-blue-600 text-white font-medium'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {dept.name}
            </button>
          ))}
        </div>

        {/* Status Filter & Reset */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-medium">Status:</span>
          {['all', 'active', 'delayed', 'planning'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-2 py-0.5 rounded capitalize transition-colors ${
                statusFilter === status
                  ? 'bg-slate-700 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {status}
            </button>
          ))}

          {(selectedDistrict !== null || statusFilter !== 'all' || activeEntity !== null) && (
            <button
              onClick={handleResetFilters}
              className="ml-2 flex items-center gap-1 text-slate-400 hover:text-rose-400 text-[11px] transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Main City SVG Canvas */}
      <div className="flex-1 relative overflow-hidden bg-[#090d16] flex items-center justify-center p-2">
        <svg
          viewBox="0 0 1000 680"
          className="w-full h-full max-h-[calc(100vh-140px)] drop-shadow-2xl"
          style={{ maxHeight: 'calc(100vh - 120px)' }}
        >
          <defs>
            {/* Subtle Grid Pattern */}
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.5" strokeOpacity="0.4" />
            </pattern>

            {/* Glowing filter */}
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>

            {/* District Gradients */}
            <radialGradient id="gradEng" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#0284c7" stopOpacity="0.14" />
              <stop offset="100%" stopColor="#0b0f19" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="gradProd" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.14" />
              <stop offset="100%" stopColor="#0b0f19" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="gradOps" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.14" />
              <stop offset="100%" stopColor="#0b0f19" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="gradResearch" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.14" />
              <stop offset="100%" stopColor="#0b0f19" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Background Grid */}
          <rect width="1000" height="680" fill="url(#grid)" />

          {/* Connected Campus Avenues / Roads */}
          <g stroke="#1e293b" strokeWidth="36" strokeLinecap="round" strokeLinejoin="round" opacity="0.6">
            <line x1="500" y1="40" x2="500" y2="640" />
            <line x1="60" y1="340" x2="940" y2="340" />
          </g>
          {/* Avenue Center Dashes */}
          <g stroke="#334155" strokeWidth="1.5" strokeDasharray="8 8" opacity="0.5">
            <line x1="500" y1="40" x2="500" y2="640" />
            <line x1="60" y1="340" x2="940" y2="340" />
          </g>

          {/* Central Plaza Roundabout */}
          <circle cx="500" cy="340" r="52" fill="#0f172a" stroke="#334155" strokeWidth="2" />
          <circle cx="500" cy="340" r="42" fill="#1e293b" stroke="#38bdf8" strokeWidth="1" strokeDasharray="3 3" opacity="0.8" />
          <text x="500" y="337" textAnchor="middle" fill="#38bdf8" fontSize="10" fontWeight="bold">
            CENTRAL
          </text>
          <text x="500" y="349" textAnchor="middle" fill="#94a3b8" fontSize="8">
            PLAZA
          </text>

          {/* 4 Major District Zones */}
          {/* 1. Engineering District (Top-Left) */}
          <g
            className="cursor-pointer"
            onClick={() => setSelectedDistrict(selectedDistrict === 'dept_eng' ? null : 'dept_eng')}
          >
            <rect
              x="60" y="40" width="400" height="270" rx="16"
              fill="url(#gradEng)"
              stroke={selectedDistrict === 'dept_eng' ? '#38bdf8' : '#1e293b'}
              strokeWidth={selectedDistrict === 'dept_eng' ? 2 : 1}
            />
            <rect x="75" y="55" width="150" height="24" rx="6" fill="#0c4a6e" fillOpacity="0.5" stroke="#0284c7" strokeWidth="0.8" />
            <text x="85" y="71" fill="#7dd3fc" fontSize="11" fontWeight="bold">
              ENGINEERING DISTRICT
            </text>
          </g>

          {/* 2. Product District (Top-Right) */}
          <g
            className="cursor-pointer"
            onClick={() => setSelectedDistrict(selectedDistrict === 'dept_prod' ? null : 'dept_prod')}
          >
            <rect
              x="540" y="40" width="400" height="270" rx="16"
              fill="url(#gradProd)"
              stroke={selectedDistrict === 'dept_prod' ? '#c084fc' : '#1e293b'}
              strokeWidth={selectedDistrict === 'dept_prod' ? 2 : 1}
            />
            <rect x="555" y="55" width="135" height="24" rx="6" fill="#581c87" fillOpacity="0.5" stroke="#9333ea" strokeWidth="0.8" />
            <text x="565" y="71" fill="#d8b4fe" fontSize="11" fontWeight="bold">
              PRODUCT DISTRICT
            </text>
          </g>

          {/* 3. Operations District (Bottom-Left) */}
          <g
            className="cursor-pointer"
            onClick={() => setSelectedDistrict(selectedDistrict === 'dept_ops' ? null : 'dept_ops')}
          >
            <rect
              x="60" y="370" width="400" height="270" rx="16"
              fill="url(#gradOps)"
              stroke={selectedDistrict === 'dept_ops' ? '#34d399' : '#1e293b'}
              strokeWidth={selectedDistrict === 'dept_ops' ? 2 : 1}
            />
            <rect x="75" y="385" width="150" height="24" rx="6" fill="#064e3b" fillOpacity="0.5" stroke="#059669" strokeWidth="0.8" />
            <text x="85" y="401" fill="#6ee7b7" fontSize="11" fontWeight="bold">
              OPERATIONS DISTRICT
            </text>
          </g>

          {/* 4. Research & Data District (Bottom-Right) */}
          <g
            className="cursor-pointer"
            onClick={() => setSelectedDistrict(selectedDistrict === 'dept_research' ? null : 'dept_research')}
          >
            <rect
              x="540" y="370" width="400" height="270" rx="16"
              fill="url(#gradResearch)"
              stroke={selectedDistrict === 'dept_research' ? '#fbbf24' : '#1e293b'}
              strokeWidth={selectedDistrict === 'dept_research' ? 2 : 1}
            />
            <rect x="555" y="385" width="165" height="24" rx="6" fill="#78350f" fillOpacity="0.5" stroke="#d97706" strokeWidth="0.8" />
            <text x="565" y="401" fill="#fde68a" fontSize="11" fontWeight="bold">
              RESEARCH & DATA DISTRICT
            </text>
          </g>

          {/* Render Project Buildings */}
          {filteredProjects.map((proj) => {
            const buildingPositions: Record<string, { x: number; y: number; w: number; h: number }> = {
              proj_atlas: { x: 100, y: 100, w: 150, h: 74 },
              proj_billing: { x: 280, y: 100, w: 145, h: 74 },
              proj_portal: { x: 570, y: 100, w: 155, h: 74 },
              proj_pulse: { x: 755, y: 100, w: 145, h: 74 },
              proj_migration: { x: 100, y: 430, w: 160, h: 74 },
              proj_ai_search: { x: 570, y: 430, w: 160, h: 74 },
              proj_rag: { x: 755, y: 430, w: 145, h: 74 },
            };

            const pos = buildingPositions[proj.id] || { 
              x: Math.min(800, Math.max(100, proj.district_x)), 
              y: Math.min(550, Math.max(100, proj.district_y)), 
              w: 145, 
              h: 74 
            };

            const isDelayed = proj.status === 'delayed';
            const highlighted = isHighlighted(proj.id);

            return (
              <g
                key={proj.id}
                className="cursor-pointer"
                onClick={() => {
                  setActiveEntity({
                    id: proj.id,
                    name: proj.name,
                    type: 'project',
                    titleOrStatus: `Status: ${proj.status.toUpperCase()}`,
                    department: proj.department_name || 'Engineering',
                    details: `${proj.team_count} Team Members • Priority: ${proj.priority.toUpperCase()} • ${proj.risks || 'No blockers reported'}`
                  });
                  onSelectProject(proj.id);
                }}
                onMouseEnter={() => {
                  setActiveEntity({
                    id: proj.id,
                    name: proj.name,
                    type: 'project',
                    titleOrStatus: `Status: ${proj.status.toUpperCase()}`,
                    department: proj.department_name || 'Engineering',
                    details: `${proj.team_count} Team Members • Priority: ${proj.priority.toUpperCase()} • ${proj.risks || 'No blockers reported'}`
                  });
                }}
              >
                {/* Hit Target */}
                <rect
                  x={pos.x - 4}
                  y={pos.y - 4}
                  width={pos.w + 8}
                  height={pos.h + 8}
                  fill="transparent"
                />

                {/* Highlight Halo */}
                {highlighted && (
                  <rect
                    x={pos.x - 4}
                    y={pos.y - 4}
                    width={pos.w + 8}
                    height={pos.h + 8}
                    rx="10"
                    fill="none"
                    stroke={isDelayed ? '#ef4444' : '#38bdf8'}
                    strokeWidth="2.5"
                    filter="url(#glow)"
                  />
                )}

                {/* Building Base */}
                <rect
                  x={pos.x}
                  y={pos.y}
                  width={pos.w}
                  height={pos.h}
                  rx="8"
                  fill={isDelayed ? '#261215' : '#1e293b'}
                  stroke={isDelayed ? '#ef4444' : highlighted ? '#38bdf8' : '#475569'}
                  strokeWidth={isDelayed ? 2 : 1.5}
                />

                {/* Building Roof Accent */}
                <path
                  d={`M ${pos.x} ${pos.y + 16} L ${pos.x + pos.w} ${pos.y + 16}`}
                  stroke={isDelayed ? '#991b1b' : '#334155'}
                  strokeWidth="2"
                />

                {/* Status Dot */}
                <circle
                  cx={pos.x + 14}
                  cy={pos.y + 10}
                  r={4}
                  fill={isDelayed ? '#ef4444' : proj.status === 'active' ? '#10b981' : '#3b82f6'}
                />

                {/* Project Building Label */}
                <text
                  x={pos.x + 24}
                  y={pos.y + 13}
                  fill="#f8fafc"
                  fontSize="11"
                  fontWeight="bold"
                >
                  {proj.name}
                </text>

                {/* Subtitle / Details */}
                <text
                  x={pos.x + 12}
                  y={pos.y + 35}
                  fill="#94a3b8"
                  fontSize="9.5"
                >
                  {proj.department_name || 'Team Platform'}
                </text>

                {/* Team Count Badge */}
                <g transform={`translate(${pos.x + 12}, ${pos.y + 45})`}>
                  <rect width="64" height="16" rx="4" fill="#0f172a" stroke="#334155" strokeWidth="0.8" />
                  <text x="6" y="11" fill="#cbd5e1" fontSize="8.5">
                    👥 {proj.team_count} Members
                  </text>
                </g>

                {/* Delayed Blocker Warning Banner */}
                {isDelayed && (
                  <g transform={`translate(${pos.x + pos.w - 48}, ${pos.y + 45})`}>
                    <rect width="42" height="16" rx="4" fill="#7f1d1d" stroke="#ef4444" strokeWidth="0.8" />
                    <text x="4" y="11" fill="#fecaca" fontSize="8" fontWeight="bold">
                      DELAYED
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Render Employee Avatars (Zero-Flicker) */}
          {filteredEmployees.map((emp) => {
            const coord = employeeCoords[emp.id] || { x: 500, y: 340 };
            const highlighted = isHighlighted(emp.id);

            return (
              <g
                key={emp.id}
                className="cursor-pointer"
                transform={`translate(${coord.x}, ${coord.y})`}
                onClick={() => {
                  setActiveEntity({
                    id: emp.id,
                    name: emp.name,
                    type: 'employee',
                    titleOrStatus: `${emp.title} • ${emp.role}`,
                    department: emp.department_name || 'Engineering',
                    details: emp.email,
                    avatar: emp.avatar
                  });
                  onSelectEmployee(emp.id);
                }}
                onMouseEnter={() => {
                  setActiveEntity({
                    id: emp.id,
                    name: emp.name,
                    type: 'employee',
                    titleOrStatus: `${emp.title} • ${emp.role}`,
                    department: emp.department_name || 'Engineering',
                    details: emp.email,
                    avatar: emp.avatar
                  });
                }}
              >
                {/* Large Invisible Hit Area to completely prevent cursor flicker */}
                <circle
                  r="26"
                  fill="transparent"
                  style={{ pointerEvents: 'all' }}
                />

                {/* Selection Halo */}
                {highlighted && (
                  <circle
                    r="18"
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="2.5"
                    filter="url(#glow)"
                    className="pointer-events-none"
                    style={{ pointerEvents: 'none' }}
                  />
                )}

                {/* Avatar Circle Container (Fixed size, steady) */}
                <circle
                  r="14"
                  fill="#1e293b"
                  stroke={highlighted ? '#38bdf8' : '#64748b'}
                  strokeWidth="1.5"
                  className="pointer-events-none"
                  style={{ pointerEvents: 'none' }}
                />

                {/* DiceBear SVG Image */}
                <clipPath id={`clip-${emp.id}`}>
                  <circle r="13" />
                </clipPath>
                <image
                  href={emp.avatar}
                  x="-13"
                  y="-13"
                  width="26"
                  height="26"
                  clipPath={`url(#clip-${emp.id})`}
                  className="pointer-events-none"
                  style={{ pointerEvents: 'none' }}
                />

                {/* Employee Name */}
                <text
                  y="24"
                  textAnchor="middle"
                  fill={highlighted ? '#38bdf8' : '#e2e8f0'}
                  fontSize="8.5"
                  fontWeight={highlighted ? 'bold' : 'normal'}
                  className="pointer-events-none drop-shadow-md select-none"
                  style={{ pointerEvents: 'none' }}
                >
                  {emp.name.split(' ')[0]}
                </text>
              </g>
            );
          })}

          {/* Infrastructure Systems Hub */}
          <g transform="translate(130, 520)">
            <rect width="280" height="90" rx="8" fill="#064e3b" fillOpacity="0.2" stroke="#059669" strokeWidth="1" strokeDasharray="3 3" />
            <text x="12" y="18" fill="#a7f3d0" fontSize="9.5" fontWeight="bold">
              CLOUD SYSTEMS & SERVICES
            </text>
            {data.systems.slice(0, 4).map((sys, idx) => (
              <g key={sys.id} transform={`translate(${14 + (idx % 2) * 128}, ${28 + Math.floor(idx / 2) * 28})`}>
                <rect width="120" height="22" rx="4" fill="#0f172a" stroke={sys.health_status === 'degraded' ? '#f59e0b' : '#334155'} strokeWidth="1" />
                <circle cx="8" cy="11" r="2.5" fill={sys.health_status === 'degraded' ? '#f59e0b' : '#10b981'} />
                <text x="16" y="14" fill="#f1f5f9" fontSize="8.5" fontWeight="bold">
                  {sys.name}
                </text>
              </g>
            ))}
          </g>

        </svg>

        {/* Steady Docked Entity Inspector / Quick Preview Card (Zero-Flicker) */}
        {activeEntity && (
          <div className="absolute bottom-4 right-4 z-30 w-80 bg-slate-900/95 backdrop-blur-md text-white p-3.5 rounded-xl shadow-2xl border border-slate-700 animate-in fade-in slide-in-from-bottom-2 duration-150">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                {activeEntity.type === 'employee' ? (
                  <img
                    src={activeEntity.avatar}
                    alt={activeEntity.name}
                    className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-lg bg-blue-900/60 border border-blue-700 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-blue-400" />
                  </div>
                )}
                <div>
                  <h4 className="font-semibold text-sm text-slate-100">{activeEntity.name}</h4>
                  <p className="text-xs text-cyan-400 font-medium">{activeEntity.titleOrStatus}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveEntity(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
                title="Dismiss inspector"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-2 text-xs text-slate-300">
              <span className="text-slate-400 font-medium">{activeEntity.department}</span>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{activeEntity.details}</p>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center gap-2">
              <button
                onClick={() => {
                  if (activeEntity.type === 'employee') onSelectEmployee(activeEntity.id);
                  else onSelectProject(activeEntity.id);
                }}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition-colors cursor-pointer"
              >
                <span>View Full Profile</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              {onExploreInGraph && (
                <button
                  onClick={() => onExploreInGraph(activeEntity.id)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
                  title="Explore neighborhood in Knowledge Graph"
                >
                  <Network className="w-4 h-4 text-cyan-400" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
