import React, { useEffect, useState } from 'react';
import { 
  X, Briefcase, Users, Server, AlertTriangle, FileText, 
  GitCommit, CheckCircle2, Network, ArrowRight, Loader2, Link as LinkIcon
} from 'lucide-react';
import { ProjectDetail } from '../../types';
import { api } from '../../services/api';

interface ProjectModalProps {
  projectId: string;
  onClose: () => void;
  onSelectEmployee: (id: string) => void;
  onSelectProject: (id: string) => void;
  onExploreGraph: (id: string) => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  projectId,
  onClose,
  onSelectEmployee,
  onSelectProject,
  onExploreGraph,
}) => {
  const [project, setProject] = useState<ProjectDetail | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'team' | 'dependencies' | 'decisions' | 'documents' | 'incidents'>('overview');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    api.getProjectDetail(projectId)
      .then((data) => {
        if (isMounted) {
          setProject(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Failed to load project details');
          setLoading(false);
        }
      });

    return () => { isMounted = false; };
  }, [projectId]);

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-8 max-w-md w-full flex flex-col items-center text-center">
          <Loader2 className="w-8 h-8 text-blue-500 animate-spin mb-3" />
          <h3 className="text-white font-semibold text-sm">Querying FalkorDB Project Graph...</h3>
          <p className="text-slate-400 text-xs mt-1">Retrieving team, dependencies, decisions & incidents</p>
        </div>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-[#0f172a] border border-slate-800 rounded-2xl p-6 max-w-md w-full text-center">
          <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto mb-2" />
          <h3 className="text-white font-semibold">Project Not Found</h3>
          <p className="text-slate-400 text-xs mt-1 mb-4">{error || 'Project record does not exist in graph.'}</p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  const isDelayed = project.status === 'delayed';

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0f172a] border border-slate-800 rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className={`p-6 border-b border-slate-800 ${isDelayed ? 'bg-gradient-to-r from-rose-950/40 via-slate-900 to-slate-900' : 'bg-slate-900'} flex items-start justify-between gap-4`}>
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                isDelayed ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              }`}>
                {project.status}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                Priority: {project.priority}
              </span>
              <span className="text-xs text-slate-400">
                🏢 {project.department_name || 'Engineering'}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              {project.name}
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">{project.description}</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onExploreGraph(project.id)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/40 rounded-lg text-xs font-medium transition-colors cursor-pointer"
            >
              <Network className="w-3.5 h-3.5" />
              <span>Explore Graph</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-800 bg-slate-900/60 overflow-x-auto text-xs">
          {[
            { id: 'overview', label: 'Overview' },
            { id: 'team', label: `Team (${project.team_members.length})` },
            { id: 'dependencies', label: `Dependencies (${project.dependencies.length + project.systems_used.length})` },
            { id: 'decisions', label: `Decisions (${project.decisions.length})` },
            { id: 'documents', label: `Documents (${project.documents.length})` },
            { id: 'incidents', label: `Incidents (${project.incidents.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-2 border-b-2 font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'border-blue-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-300 flex-1">
          {/* TAB: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-5">
              {/* Risks & Blockers Section */}
              {project.risks && (
                <div className={`p-4 rounded-xl border ${
                  isDelayed 
                    ? 'bg-rose-950/30 border-rose-900/60 text-rose-200' 
                    : 'bg-amber-950/20 border-amber-900/40 text-amber-200'
                }`}>
                  <div className="flex items-center gap-2 font-semibold text-xs mb-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    <span>DOCUMENTED RISKS & BLOCKERS</span>
                  </div>
                  <p className="text-xs leading-relaxed">{project.risks}</p>
                </div>
              )}

              {/* Quick Summary Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <div className="text-slate-400 text-[11px] mb-1">TEAM SIZE</div>
                  <div className="text-lg font-bold text-white">{project.team_members.length} Engineers</div>
                </div>
                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <div className="text-slate-400 text-[11px] mb-1">SYSTEMS USED</div>
                  <div className="text-lg font-bold text-white">{project.systems_used.length} Services</div>
                </div>
                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <div className="text-slate-400 text-[11px] mb-1">RECORDED DECISIONS</div>
                  <div className="text-lg font-bold text-white">{project.decisions.length} Decisions</div>
                </div>
              </div>

              {/* Tasks List */}
              <div>
                <h4 className="text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>PROJECT TASKS ({project.tasks.length})</span>
                </h4>
                {project.tasks.length > 0 ? (
                  <div className="space-y-1.5">
                    {project.tasks.map((task) => (
                      <div key={task.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                        <span className="font-medium text-slate-200">{task.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                          {task.subtitle}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-slate-500 italic">No tasks currently documented</div>
                )}
              </div>
            </div>
          )}

          {/* TAB: TEAM */}
          {activeTab === 'team' && (
            <div>
              <h4 className="text-slate-400 font-semibold mb-3">ENGINEERING & PRODUCT TEAM MEMBERS</h4>
              {project.team_members.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {project.team_members.map((member) => (
                    <button
                      key={member.id}
                      onClick={() => onSelectEmployee(member.id)}
                      className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 flex items-center justify-between text-left group transition-all"
                    >
                      <div>
                        <div className="font-semibold text-white group-hover:text-blue-300 transition-colors">
                          {member.name}
                        </div>
                        <div className="text-[11px] text-slate-400">{member.subtitle}</div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-colors" />
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No team members assigned in graph</div>
              )}
            </div>
          )}

          {/* TAB: DEPENDENCIES */}
          {activeTab === 'dependencies' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-slate-400 font-semibold mb-2">SYSTEMS & SERVICES USED (USES)</h4>
                <div className="space-y-2">
                  {project.systems_used.map((sys) => (
                    <div key={sys.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-white">{sys.name}</div>
                        <div className="text-[11px] text-slate-400">{sys.subtitle}</div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-cyan-300 font-mono">
                        Tier 1 / 2
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {project.dependencies.length > 0 && (
                <div>
                  <h4 className="text-slate-400 font-semibold mb-2">HARD DEPENDENCIES (DEPENDS_ON)</h4>
                  <div className="space-y-2">
                    {project.dependencies.map((dep) => (
                      <div key={dep.id} className="p-3 rounded-xl bg-rose-950/20 border border-rose-900/40 flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-rose-300">{dep.name}</div>
                          <div className="text-[11px] text-slate-400">Target Type: {dep.type}</div>
                        </div>
                        <span className="text-[10px] text-rose-400 font-medium">Critical Blocker</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: DECISIONS */}
          {activeTab === 'decisions' && (
            <div>
              <h4 className="text-slate-400 font-semibold mb-3">ARCHITECTURAL DECISIONS (DECISIONS)</h4>
              {project.decisions.length > 0 ? (
                <div className="space-y-3">
                  {project.decisions.map((dec) => (
                    <div key={dec.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-cyan-300 text-sm">{dec.name}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-medium">
                          Status: {dec.subtitle}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                        {dec.extra?.rationale || 'Rationale documented in company architecture repository.'}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No formal decisions recorded for this project</div>
              )}
            </div>
          )}

          {/* TAB: DOCUMENTS */}
          {activeTab === 'documents' && (
            <div>
              <h4 className="text-slate-400 font-semibold mb-3">SUPPORTING DOCUMENTS & RFCS</h4>
              {project.documents.length > 0 ? (
                <div className="space-y-2.5">
                  {project.documents.map((doc) => (
                    <div key={doc.id} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="font-semibold text-blue-300 flex items-center gap-2">
                        <FileText className="w-3.5 h-3.5 text-blue-400" />
                        <span>{doc.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-900">
                          {doc.subtitle}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1.5">{doc.extra?.summary}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No documents currently linked to this project</div>
              )}
            </div>
          )}

          {/* TAB: INCIDENTS */}
          {activeTab === 'incidents' && (
            <div>
              <h4 className="text-slate-400 font-semibold mb-3">LINKED INCIDENTS & OUTAGES</h4>
              {project.incidents.length > 0 ? (
                <div className="space-y-2.5">
                  {project.incidents.map((inc) => (
                    <div key={inc.id} className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-900/40">
                      <div className="font-semibold text-rose-300 flex items-center justify-between">
                        <span>{inc.name}</span>
                        <span className="text-[10px] text-rose-400">{inc.subtitle}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500 italic">No incidents directly affected this project</div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/80 flex items-center justify-between text-xs text-slate-400">
          <span>Project ID: <code className="text-slate-300 font-mono">{project.id}</code></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
