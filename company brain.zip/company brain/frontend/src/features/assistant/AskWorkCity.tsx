import React, { useState } from 'react';
import { 
  Send, Sparkles, Network, MapPin, FileText, 
  ChevronDown, ChevronRight, Terminal, 
  Copy, Check, Wrench, X, ExternalLink
} from 'lucide-react';
import { AssistantQueryResponse } from '../../types';
import { api } from '../../services/api';

interface AskWorkCityProps {
  onSelectEmployee: (id: string) => void;
  onSelectProject: (id: string) => void;
  onHighlightInCity: (entityIds: string[]) => void;
  onExploreInGraph: (entityId: string) => void;
  sessionId: string;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  response?: AssistantQueryResponse;
}

const CHIP_QUESTIONS = [
  "Who knows the payment service best?",
  "Why was Project Atlas delayed?",
  "Which decision supersedes DEC-202?",
  "What could break if core-db goes down?",
  "Who is the most central employee in the company?",
  "What changed in the last 30 days?"
];

export const AskWorkCity: React.FC<AskWorkCityProps> = ({
  onSelectEmployee,
  onSelectProject,
  onHighlightInCity,
  onExploreInGraph,
  sessionId,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: "👋 Welcome to **WorkCity — The Living Company Brain**.\n\nEvery answer is derived directly from multi-hop Cypher queries and graph algorithms running on FalkorDB. Ask a question below or pick a sample question to explore how company knowledge connects."
    }
  ]);
  const [inputValue, setInputValue] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [openPanels, setOpenPanels] = useState<Record<string, boolean>>({});
  const [copiedQuery, setCopiedQuery] = useState<string | null>(null);
  const [selectedSnippet, setSelectedSnippet] = useState<{ title: string; snippet: string; id: string; type: string } | null>(null);

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputValue;
    if (!textToSend.trim() || loading) return;

    const userMsgId = `user_${Date.now()}`;
    const newMessages: ChatMessage[] = [
      ...messages,
      { id: userMsgId, sender: 'user', text: textToSend }
    ];
    setMessages(newMessages);
    setInputValue('');
    setLoading(true);

    try {
      const res = await api.askAssistant(textToSend, undefined, sessionId);
      const assistantMsgId = `assistant_${Date.now()}`;

      // Open "How this was answered" by default for easy inspection
      setOpenPanels(prev => ({ ...prev, [assistantMsgId]: true }));

      setMessages([
        ...newMessages,
        {
          id: assistantMsgId,
          sender: 'assistant',
          text: res.answer,
          response: res
        }
      ]);
    } catch (err: any) {
      setMessages([
        ...newMessages,
        {
          id: `assistant_err_${Date.now()}`,
          sender: 'assistant',
          text: `⚠️ **Error querying FalkorDB:** ${err.message || 'Could not complete graph traversal.'}`
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const togglePanel = (msgId: string) => {
    setOpenPanels(prev => ({ ...prev, [msgId]: !prev[msgId] }));
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedQuery(id);
    setTimeout(() => setCopiedQuery(null), 2000);
  };

  const renderSimpleMarkdown = (text: string) => {
    const lines = text.split('\n');
    return (
      <div className="space-y-2 text-sm leading-relaxed text-slate-200">
        {lines.map((line, idx) => {
          if (!line.trim()) return <div key={idx} className="h-1.5" />;
          if (line.startsWith('### ')) {
            return <h3 key={idx} className="text-base font-bold text-white pt-2">{line.replace('### ', '')}</h3>;
          }
          if (line.startsWith('> ')) {
            return (
              <blockquote key={idx} className="pl-3 border-l-2 border-cyan-500 text-cyan-200 italic my-1.5 bg-cyan-950/20 py-1 rounded-r">
                {line.replace('> ', '')}
              </blockquote>
            );
          }
          if (line.startsWith('- ') || line.startsWith('* ')) {
            return (
              <div key={idx} className="flex items-start gap-2 pl-2">
                <span className="text-cyan-400 mt-1 text-xs">•</span>
                <span>{line.replace(/^[-*]\s+/, '')}</span>
              </div>
            );
          }
          if (/^\d+\.\s/.test(line)) {
            const num = line.match(/^(\d+)\.\s/)?.[1];
            return (
              <div key={idx} className="flex items-start gap-2 pl-2 font-medium">
                <span className="text-blue-400 text-xs mt-0.5">{num}.</span>
                <span>{line.replace(/^\d+\.\s+/, '')}</span>
              </div>
            );
          }
          return <p key={idx}>{line}</p>;
        })}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0f19] text-slate-100 max-w-5xl mx-auto w-full border-x border-slate-800">
      {/* Top Search Bar & Sample Chips */}
      <div className="p-4 sm:p-6 bg-[#0f172a] border-b border-slate-800 shadow-lg">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="relative flex items-center"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask anything about employees, projects, systems, decisions, or incidents..."
            disabled={loading}
            className="w-full pl-4 pr-12 py-3 bg-slate-900 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all shadow-inner"
          />
          <button
            type="submit"
            disabled={loading || !inputValue.trim()}
            className="absolute right-2 p-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white disabled:opacity-40 disabled:hover:bg-blue-600 transition-all cursor-pointer shadow-md"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* 6 Chips Below Search Bar */}
        <div className="mt-3 flex flex-wrap gap-2">
          {CHIP_QUESTIONS.map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSend(q)}
              disabled={loading}
              className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs transition-all cursor-pointer text-left shadow-sm hover:border-slate-600"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Messages Thread */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            {msg.sender === 'user' ? (
              <div className="max-w-xl bg-blue-600 text-white px-4 py-2.5 rounded-2xl rounded-tr-sm text-sm font-medium shadow-md">
                {msg.text}
              </div>
            ) : (
              <div className="w-full max-w-3xl space-y-3">
                {/* Assistant Answer Box */}
                <div className="bg-[#131b2e] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
                  {renderSimpleMarkdown(msg.text)}

                  {/* Supporting Entity Action Buttons */}
                  {msg.response && (
                    <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {msg.response.highlighted_entity_ids.length > 0 && (
                          <button
                            onClick={() => onHighlightInCity(msg.response!.highlighted_entity_ids)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/40 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                          >
                            <MapPin className="w-3.5 h-3.5" />
                            <span>Highlight in City</span>
                          </button>
                        )}

                        {msg.response.supporting_entities[0] && (
                          <button
                            onClick={() => onExploreInGraph(msg.response!.supporting_entities[0].id)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                          >
                            <Network className="w-3.5 h-3.5" />
                            <span>View in Graph Explorer</span>
                          </button>
                        )}
                      </div>

                      {/* How This Was Answered Toggle */}
                      <button
                        onClick={() => togglePanel(msg.id)}
                        className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/60 rounded-md border border-slate-700/60 transition-colors cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3 text-amber-400" />
                        <span>How this was answered</span>
                        {openPanels[msg.id] ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  )}
                </div>

                {/* Collapsible "How this was answered" panel */}
                {msg.response && openPanels[msg.id] && (
                  <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-4 shadow-xl space-y-4 animate-in fade-in duration-150">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-400 border-b border-slate-800 pb-2">
                      <div className="flex items-center gap-2 text-cyan-400">
                        <Terminal className="w-4 h-4" />
                        <span>FALKORDB GRAPH REASONING TRACE</span>
                      </div>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 uppercase">
                        Agent: {msg.response.agent || 'deterministic'}
                      </span>
                    </div>

                    {/* 1. Tools Called with Arguments */}
                    {msg.response.tools_called && msg.response.tools_called.length > 0 && (
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <Wrench className="w-3 h-3 text-blue-400" />
                          <span>Tools Executed</span>
                        </div>
                        <div className="space-y-1">
                          {msg.response.tools_called.map((t, tIdx) => (
                            <div key={tIdx} className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs font-mono flex items-center justify-between">
                              <div>
                                <span className="text-cyan-400 font-bold">{t.tool}</span>
                                <span className="text-slate-400">({JSON.stringify(t.args)})</span>
                              </div>
                              {t.row_count !== undefined && (
                                <span className="text-[10px] text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded">
                                  {t.row_count} rows
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* 2. Cypher Queries Executed with Copy Button */}
                    {msg.response.cypher_executed && (
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <Terminal className="w-3 h-3 text-emerald-400" />
                          <span>Cypher Queries Executed</span>
                        </div>
                        {Array.isArray(msg.response.cypher_executed) ? (
                          msg.response.cypher_executed.map((cypherText, cIdx) => (
                            <div key={cIdx} className="relative group bg-[#090d16] border border-slate-800 rounded-lg p-3">
                              <pre className="text-xs font-mono text-emerald-300 overflow-x-auto whitespace-pre-wrap">
                                {cypherText}
                              </pre>
                              <button
                                onClick={() => copyToClipboard(cypherText, `${msg.id}_cypher_${cIdx}`)}
                                className="absolute top-2 right-2 p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1 transition-colors cursor-pointer"
                                title="Copy Cypher query"
                              >
                                {copiedQuery === `${msg.id}_cypher_${cIdx}` ? (
                                  <>
                                    <Check className="w-3 h-3 text-emerald-400" />
                                    <span className="text-[10px] text-emerald-400">Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3 h-3" />
                                    <span className="text-[10px]">Copy</span>
                                  </>
                                )}
                              </button>
                            </div>
                          ))
                        ) : (
                          <div className="relative group bg-[#090d16] border border-slate-800 rounded-lg p-3">
                            <pre className="text-xs font-mono text-emerald-300 overflow-x-auto whitespace-pre-wrap">
                              {msg.response.cypher_executed}
                            </pre>
                            <button
                              onClick={() => copyToClipboard(msg.response!.cypher_executed as string, `${msg.id}_cypher`)}
                              className="absolute top-2 right-2 p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1 transition-colors cursor-pointer"
                              title="Copy Cypher query"
                            >
                              {copiedQuery === `${msg.id}_cypher` ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-400" />
                                  <span className="text-[10px] text-emerald-400">Copied</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3 h-3" />
                                  <span className="text-[10px]">Copy</span>
                                </>
                              )}
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {/* 3. Graph Path Traversed */}
                    {((msg.response.graph_path && msg.response.graph_path.length > 0) || (msg.response.evidence_path && msg.response.evidence_path.length > 0)) && (
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <Network className="w-3 h-3 text-cyan-400" />
                          <span>Graph Path Traversed</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {msg.response.evidence_path.map((pathStr, pIdx) => (
                            <span key={pIdx} className="px-2.5 py-1 rounded bg-[#090d16] border border-slate-800 font-mono text-xs text-blue-300">
                              {pathStr}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* 4. Source Records & Documents Cited */}
                    {msg.response.source_records && msg.response.source_records.length > 0 && (
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <FileText className="w-3 h-3 text-amber-400" />
                          <span>Cited Source Records (Click to inspect)</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {msg.response.source_records.map((rec, rIdx) => (
                            <button
                              key={rIdx}
                              onClick={() => setSelectedSnippet({
                                title: rec.title,
                                snippet: rec.snippet || 'No text excerpt available.',
                                id: rec.id,
                                type: rec.type
                              })}
                              className="p-2.5 rounded-lg bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-left transition-colors cursor-pointer group flex items-start justify-between gap-2"
                            >
                              <div>
                                <div className="text-xs font-semibold text-slate-200 group-hover:text-blue-400 flex items-center gap-1.5">
                                  <span>{rec.title}</span>
                                </div>
                                <div className="text-[10px] text-slate-400 mt-0.5">
                                  `{rec.id}` • {rec.type}
                                </div>
                              </div>
                              <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-blue-400 flex-shrink-0 mt-0.5" />
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-3 text-xs text-slate-400 bg-slate-900/60 p-3 rounded-xl border border-slate-800/60 max-w-md animate-pulse">
            <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" />
            <span>Traversing FalkorDB knowledge graph...</span>
          </div>
        )}
      </div>

      {/* Snippet Inspection Modal / Drawer */}
      {selectedSnippet && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0f172a] border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider">
                  {selectedSnippet.type} • {selectedSnippet.id}
                </span>
                <h4 className="text-base font-bold text-white mt-0.5">{selectedSnippet.title}</h4>
              </div>
              <button
                onClick={() => setSelectedSnippet(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 text-sm text-slate-300 leading-relaxed max-h-60 overflow-y-auto">
              {selectedSnippet.snippet}
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setSelectedSnippet(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium cursor-pointer"
              >
                Close Excerpt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
