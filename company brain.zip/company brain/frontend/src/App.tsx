import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { CityMap } from './features/city/CityMap';
import { GraphExplorer } from './features/graph/GraphExplorer';
import { AskWorkCity } from './features/assistant/AskWorkCity';
import { EmployeeModal } from './features/people/EmployeeModal';
import { ProjectModal } from './features/projects/ProjectModal';
import { api } from './services/api';
import { CityData, HealthStatus } from './types';
import { AlertCircle, Loader2 } from 'lucide-react';

export function App() {
  // 3 tabs only: default to 'assistant' (Ask WorkCity)
  const [activeTab, setActiveTab] = useState<'assistant' | 'city' | 'graph'>('assistant');
  const [cityData, setCityData] = useState<CityData | null>(null);
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Session state in localStorage
  const [sessionId, setSessionId] = useState<string>(() => {
    let sid = localStorage.getItem('workcity_session_id');
    if (!sid) {
      sid = 'session_' + Math.random().toString(36).substring(2, 11);
      localStorage.setItem('workcity_session_id', sid);
    }
    return sid;
  });

  // Modal inspection states
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  // Cross-tab interaction states
  const [highlightedEntityIds, setHighlightedEntityIds] = useState<string[]>([]);
  const [graphFocusId, setGraphFocusId] = useState<string>('emp_maya');

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [h, c] = await Promise.all([
        api.getHealth(),
        api.getCity()
      ]);
      setHealth(h);
      setCityData(c);
    } catch (err: any) {
      console.error("Initialization error:", err);
      setError(err.message || 'Failed to connect to FalkorDB or load NovaWorks brain data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleNewChat = () => {
    const newSid = 'session_' + Math.random().toString(36).substring(2, 11);
    localStorage.setItem('workcity_session_id', newSid);
    setSessionId(newSid);
  };

  const handleHighlightInCity = (entityIds: string[]) => {
    setHighlightedEntityIds(entityIds);
    setActiveTab('city');
  };

  const handleExploreInGraph = (entityId: string) => {
    setGraphFocusId(entityId);
    setActiveTab('graph');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0b0f19] text-slate-100 overflow-hidden font-sans select-none">
      {/* Clean Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onNewChat={handleNewChat}
      />

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {loading && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#0b0f19]/80 backdrop-blur-sm gap-3">
            <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
            <div className="text-sm font-medium text-slate-300">Loading NovaWorks Company Brain...</div>
          </div>
        )}

        {error && (
          <div className="p-4 bg-red-950/80 border-b border-red-800 text-red-200 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400" />
              <span>{error}</span>
            </div>
            <button
              onClick={loadData}
              className="px-2.5 py-1 bg-red-900 hover:bg-red-800 rounded font-medium cursor-pointer"
            >
              Retry
            </button>
          </div>
        )}

        {/* Tab 1: Ask WorkCity (Default) */}
        {activeTab === 'assistant' && (
          <div className="h-full w-full">
            <AskWorkCity
              sessionId={sessionId}
              onSelectEmployee={setSelectedEmployeeId}
              onSelectProject={setSelectedProjectId}
              onHighlightInCity={handleHighlightInCity}
              onExploreInGraph={handleExploreInGraph}
            />
          </div>
        )}

        {/* Tab 2: City View */}
        {activeTab === 'city' && cityData && (
          <div className="h-full w-full">
            <CityMap
              data={cityData}
              searchQuery=""
              onSelectEmployee={setSelectedEmployeeId}
              onSelectProject={setSelectedProjectId}
              onExploreInGraph={handleExploreInGraph}
              highlightedEntityIds={highlightedEntityIds}
            />
          </div>
        )}

        {/* Tab 3: Graph Explorer */}
        {activeTab === 'graph' && (
          <div className="h-full w-full">
            <GraphExplorer
              initialEntityId={graphFocusId}
              onSelectEmployee={setSelectedEmployeeId}
              onSelectProject={setSelectedProjectId}
            />
          </div>
        )}
      </main>

      {/* Employee Profile Detail Modal */}
      {selectedEmployeeId && (
        <EmployeeModal
          employeeId={selectedEmployeeId}
          onClose={() => setSelectedEmployeeId(null)}
          onSelectProject={(projId: string) => {
            setSelectedEmployeeId(null);
            setSelectedProjectId(projId);
          }}
          onSelectEmployee={(empId: string) => setSelectedEmployeeId(empId)}
          onExploreGraph={(id: string) => {
            setSelectedEmployeeId(null);
            handleExploreInGraph(id);
          }}
        />
      )}

      {/* Project Detail Modal */}
      {selectedProjectId && (
        <ProjectModal
          projectId={selectedProjectId}
          onClose={() => setSelectedProjectId(null)}
          onSelectEmployee={(empId: string) => {
            setSelectedProjectId(null);
            setSelectedEmployeeId(empId);
          }}
          onSelectProject={(projId: string) => {
            setSelectedProjectId(projId);
          }}
          onExploreGraph={(id: string) => {
            setSelectedProjectId(null);
            handleExploreInGraph(id);
          }}
        />
      )}
    </div>
  );
}
export default App;
