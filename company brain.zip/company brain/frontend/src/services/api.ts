import {
  CityData, EmployeeProfile, EmployeeSummary, ProjectBuilding, ProjectDetail,
  SystemModel, DocumentModel, DecisionModel, IncidentModel, GraphNeighborhood,
  PathQueryResponse, AssistantQueryResponse, HealthStatus
} from '../types';

const API_BASE = '/api/v1';

async function fetchJson<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, options);
  if (!res.ok) {
    let errorMsg = `HTTP Error ${res.status}`;
    try {
      const errData = await res.json();
      if (errData.detail) errorMsg = errData.detail;
    } catch {
      // ignore
    }
    throw new Error(errorMsg);
  }
  return res.json();
}

export const api = {
  getHealth: () => fetchJson<HealthStatus>(`${API_BASE}/health`),
  getCity: () => fetchJson<CityData>(`${API_BASE}/city`),
  getEmployees: (query?: string, departmentId?: string) => {
    const params = new URLSearchParams();
    if (query) params.set('query', query);
    if (departmentId) params.set('department_id', departmentId);
    return fetchJson<EmployeeSummary[]>(`${API_BASE}/employees?${params.toString()}`);
  },
  getEmployeeProfile: (id: string) => fetchJson<EmployeeProfile>(`${API_BASE}/employees/${id}`),
  getProjects: (query?: string, departmentId?: string, status?: string) => {
    const params = new URLSearchParams();
    if (query) params.set('query', query);
    if (departmentId) params.set('department_id', departmentId);
    if (status) params.set('status', status);
    return fetchJson<ProjectBuilding[]>(`${API_BASE}/projects?${params.toString()}`);
  },
  getProjectDetail: (id: string) => fetchJson<ProjectDetail>(`${API_BASE}/projects/${id}`),
  getSystems: () => fetchJson<SystemModel[]>(`${API_BASE}/systems`),
  getSystemDetail: (id: string) => fetchJson<SystemModel>(`${API_BASE}/systems/${id}`),
  getDocuments: () => fetchJson<DocumentModel[]>(`${API_BASE}/documents`),
  getDecisions: () => fetchJson<DecisionModel[]>(`${API_BASE}/decisions`),
  getIncidents: () => fetchJson<IncidentModel[]>(`${API_BASE}/incidents`),
  getNeighborhood: (entityId: string, hops: number = 1) =>
    fetchJson<GraphNeighborhood>(`${API_BASE}/graph/neighborhood/${entityId}?hops=${hops}`),
  findPath: (sourceId: string, targetId: string) =>
    fetchJson<PathQueryResponse>(`${API_BASE}/graph/path?from=${encodeURIComponent(sourceId)}&to=${encodeURIComponent(targetId)}`),
  askAssistant: (question: string, contextEntityId?: string, sessionId?: string) =>
    fetchJson<AssistantQueryResponse>(`${API_BASE}/assistant/ask`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question,
        context_entity_id: contextEntityId,
        session_id: sessionId
      })
    }),
  getSession: (sessionId: string) => fetchJson<any>(`${API_BASE}/sessions/${sessionId}`)
};
