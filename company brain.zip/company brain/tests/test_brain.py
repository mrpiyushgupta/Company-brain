import sys
from pathlib import Path
import pytest

# Ensure backend is in python path
backend_path = Path(__file__).resolve().parent.parent / "backend"
if str(backend_path) not in sys.path:
    sys.path.insert(0, str(backend_path))

from app.seed_generator import build_seed_data
from app.tools import who_knows, blast_radius, decision_trace, central_nodes, search_documents, shortest_path
from app.assistant.pipeline import assistant_pipeline
from app.services.graph_service import graph_service

def test_seed_generates_expected_shape():
    """Verify seed generator produces target counts without dangling references."""
    data = build_seed_data()
    assert len(data["departments"]) == 4
    assert len(data["employees"]) >= 40
    assert len(data["projects"]) >= 12
    assert len(data["systems"]) >= 14
    assert len(data["documents"]) >= 30
    assert len(data["decisions"]) >= 15
    assert len(data["incidents"]) >= 20
    assert len(data["tickets"]) >= 40
    assert len(data["chat_threads"]) >= 25
    assert len(data["relationships"]) > 500

    # Verify no dangling edge references
    all_node_ids = set()
    for cat in ["departments", "employees", "projects", "systems", "skills", "documents", "decisions", "incidents", "tickets", "chat_threads"]:
        for item in data.get(cat, []):
            all_node_ids.add(item["id"])

    for rel in data["relationships"]:
        assert rel["from"] in all_node_ids, f"Dangling source ID: {rel['from']}"
        assert rel["to"] in all_node_ids, f"Dangling target ID: {rel['to']}"

def test_tools_return_grounded_data():
    """Verify graph tools return verified FalkorDB rows."""
    wk = who_knows("sys_payment")
    assert len(wk["rows"]) > 0
    assert any(r["employee_id"] in ["emp_piyush", "emp_maya"] for r in wk["rows"])

    br = blast_radius("sys_core_db")
    assert len(br["rows"]) > 0
    assert len(br["rows"][0]["direct_projects"]) > 0

    dt = decision_trace("dec_202")
    assert len(dt["rows"]) > 0
    assert dt["rows"][0]["decision_id"] == "dec_202"
    assert dt["rows"][0]["superseded_by"] is not None

    cn = central_nodes()
    assert len(cn["rows"]) > 0
    assert cn["rows"][0]["score"] > 0

    sd = search_documents("latency")
    assert len(sd["rows"]) > 0
    assert any("latency" in r["snippet"].lower() or "latency" in r["title"].lower() for r in sd["rows"])

def test_pipeline_answers_known_questions():
    """Verify 8 check questions return non-empty grounded answers and valid tool trace."""
    questions = [
        "Who knows the payment service best?",
        "Why was Project Atlas delayed?",
        "Which decision supersedes DEC-202?",
        "What could break if core-db goes down?",
        "Who is the most central employee in the company?",
        "What changed in the last 30 days?",
        "How is Carlos connected to Maya?"
    ]
    for q in questions:
        resp = assistant_pipeline.answer_question(q, session_id="pytest-session-1")
        assert resp.answer, f"Empty answer for: {q}"
        assert "Information not documented" not in resp.answer or "status" in q.lower(), f"Unexpected unknown for: {q}"
        assert len(resp.tools_called) > 0, f"No tools executed for: {q}"
        assert len(resp.highlighted_entity_ids) > 0, f"No entities cited for: {q}"

def test_session_continuity():
    """Verify multi-turn session resolves pronouns from previous turn."""
    sid = "pytest-session-followup"
    r1 = assistant_pipeline.answer_question("Tell me about sys_payment", session_id=sid)
    assert "Payment" in r1.answer
    assert "sys_payment" in r1.highlighted_entity_ids

    r2 = assistant_pipeline.answer_question("Who owns it?", session_id=sid)
    assert "Piyush" in r2.answer or "sys_payment" in r2.answer
    assert len(r2.tools_called) > 0
    assert r2.tools_called[0]["tool"] == "who_knows"

def test_runtime_ingestion():
    """Verify newly ingested documents are dynamically linked in the graph and queryable."""
    doc_data = {
        "title": "ADR-099: Microservices Protocol Transition",
        "doc_type": "ADR",
        "content": "Transitioning core gRPC protocols across sys_payment and sys_auth under guidance of Maya Verma.",
        "summary": "Protocol transition for Payment Service and Auth Service led by Maya Verma."
    }
    ingest_res = graph_service.ingest_document(doc_data)
    assert ingest_res.id.startswith("doc_")
    assert len(ingest_res.new_edges) >= 2

    # Verify neighborhood includes linked entities
    neigh = graph_service.get_neighborhood(ingest_res.id)
    node_ids = {n.id for n in neigh.nodes}
    assert "emp_maya" in node_ids or "sys_payment" in node_ids or "sys_auth" in node_ids

    # Verify queryability via assistant
    resp = assistant_pipeline.answer_question("What documents mention Maya Verma?", session_id="pytest-doc-test")
    assert "ADR-099" in resp.answer or ingest_res.id in resp.answer
