# WorkCity — The Living Company Brain
> **Track 3: Company Brain** | WeMakeDevs × FalkorDB Graph Hacks Hackathon

WorkCity turns organizational knowledge into an interactive virtual city powered by **FalkorDB**. Instead of static wikis or lossy vector search, WorkCity maps employees, teams, projects, systems, decisions, documents, and incidents into a connected, multi-hop knowledge graph. Every answer is grounded in factual Cypher traversals.

---

## ⚡ Quickstart (One Command)

Everything runs in one command and is served at a single address:

```bash
docker compose up --build
```

Open your browser to:
👉 **[http://localhost:8000](http://localhost:8000)**

- **Single Address:** `http://localhost:8000` (FastAPI serves both the built React SPA and API endpoints).
- **Zero External Calls:** Avatars are rendered using offline embedded SVG data URIs. No CDNs, no external font services.
- **Zero LLM Dependency:** Works out of the box with an intelligent deterministic graph agent. (Optional OpenAI-compatible LLMs can be attached via `.env`).

---

## 💡 Why Graph Beats Vector Search for Company Brains

Vector search excels at fuzzy text similarity, but companies fail on structural relationships:
- *Vector search* cannot reliably compute multi-hop dependencies (e.g. *If Service X degrades, which downstream projects break?*).
- *Vector search* cannot trace chronologies or supersedes chains (e.g. *Which architectural decision invalidated our earlier caching strategy?*).
- *Vector search* cannot calculate network centrality or expertise scoring (e.g. *Who is the most central collaborator? Who owns and resolved incidents on this service?*).

WorkCity leverages **FalkorDB** to execute precise parameterized Cypher traversals, pathfinding, and graph algorithms with sub-millisecond response times.

---

## 🎯 6 Demo Questions to Try

Click any of the 6 quick-access chips on the **Ask WorkCity** tab:

1. **"Who knows the payment service best?"**
   - *Graph Traversal:* Traverses `OWNS`, `RESOLVED_BY` (incidents), `AUTHORED` (RFCs/ADRs), and `WORKED_ON` (projects) to compute a weighted multi-hop expertise ranking, identifying owner **Piyush Sharma** and incident resolver **Maya Verma**.
2. **"Why was Project Atlas delayed?"**
   - *Graph Traversal:* Follows `(Project Atlas)-[:USES]->(Payment Service)<-[:AFFECTED]-(INC-104)` to identify upstream latency timeouts, postmortem `doc_02`, and active mitigation tickets.
3. **"Which decision supersedes DEC-202?"**
   - *Graph Traversal:* Follows bidirectional `[:SUPERSEDES]` relationships to trace decision lineage from `dec_202` to the active `dec_206` (*Project Atlas Resumed & Partition Cutover Plan*).
4. **"What could break if core-db goes down?"**
   - *Graph Traversal:* Executes a 2-hop blast-radius query following `[:USES]` and `[:DEPENDS_ON]` edges to reveal all affected projects, downstream services, and historical incidents.
5. **"Who is the most central employee in the company?"**
   - *Graph Traversal:* Calls FalkorDB native PageRank (`CALL algo.pageRank('Employee', 'COLLABORATES_WITH')`) across the collaboration network to identify key organizational influencers.
6. **"What changed in the last 30 days?"**
   - *Graph Traversal:* Queries newest `Document`, `Decision`, `Incident`, and `Ticket` nodes ordered chronologically by modification dates.

---

## 🏛️ Architecture

```mermaid
flowchart TD
    User([User Browser])
    subgraph WorkCityContainer ["WorkCity Docker Container (Port 8000)"]
        FastAPI["FastAPI App (/app/backend)"]
        ReactSPA["React + Vite + Tailwind SPA (/app/frontend/dist)"]
        Pipeline["Assistant Pipeline (Deterministic / LLM)"]
        Tools["Graph Tools Layer (app/tools.py)"]
    end
    subgraph FalkorContainer ["FalkorDB Container (Internal Network)"]
        FalkorDB[("FalkorDB Graph Engine\n(workcity_novaworks)")]
    end
    OptionalLLM["Optional LLM (OpenAI / Ollama / vLLM)"]

    User -->|HTTP :8000| FastAPI
    FastAPI -->|Static Mount /| ReactSPA
    FastAPI -->|API /api/v1/*| Pipeline
    Pipeline --> Tools
    Tools -->|Parameterized Cypher & Algorithms| FalkorDB
    Pipeline -.->|Optional 2-Step Protocol| OptionalLLM
```

---

## 📊 Knowledge Graph Schema

- **Nodes:**
  - `Employee` (40 people with job titles, departments, skills, reporting hierarchy)
  - `Department` (Engineering, Product, Operations, Research & Data)
  - `Project` (12 projects with status, priority, and risks)
  - `System` (14 infrastructure services with tiers and health statuses)
  - `Document` (30+ RFCs, ADRs, postmortems, status reports)
  - `Decision` (15 architectural decisions with `:SUPERSEDES` links)
  - `Incident` (20 operational incidents with root causes and severity)
  - `Ticket` (40 engineering tasks assigned to employees and projects)
  - `ChatThread` (25 discussion threads mentioning systems and projects)
  - `Session` & `Question` & `Answer` (in-graph session memory)
- **Relationships:**
  - `BELONGS_TO`, `REPORTS_TO`, `COLLABORATES_WITH`, `OWNS`, `USES`, `DEPENDS_ON`, `WORKED_ON`, `RESOLVED_BY`, `AFFECTED`, `AUTHORED`, `DOCUMENTED_IN`, `SUPERSEDES`, `MENTIONS`, `ASSIGNED_TO`, `BELONGS_TO_PROJECT`, `RELATES_TO`, `PARTICIPATED_IN`, `ASKED`, `ANSWERED_WITH`, `CITED`.

---

## 🚀 FalkorDB Features Leveraged

1. **Native Graph Algorithms:** Executes native PageRank (`CALL algo.pageRank('Employee', 'COLLABORATES_WITH')`) for organizational centrality.
2. **Shortest Path Analysis:** Uses FalkorDB `shortestPath((s)-[*..5]-(t))` to discover multi-hop connections between any two entities.
3. **Session Memory in the Graph:** Every user interaction is persisted directly in FalkorDB: `(Session)-[:ASKED]->(Question)-[:ANSWERED_WITH]->(Answer)-[:CITED]->(Entity)`, allowing the agent to resolve pronouns (*"Who owns it?"*) across turns.
4. **Runtime Graph Ingestion:** Ingesting new markdown documents or JSON at `/api/v1/ingest/document` immediately links entities and updates query results.
5. **Strictly Parameterized Cypher:** Every query uses Cypher query parameters (`$param`), preventing injection and ensuring maximum cache utilization.

---

## 🧪 Testing

Run backend test suite against FalkorDB:

```bash
pytest tests/ -v
```

All 5 core tests verify graph shape, tool row grounding, 8 demo questions, multi-turn pronoun continuity, and dynamic document ingestion.
