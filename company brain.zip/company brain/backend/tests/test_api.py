import pytest
import sys
import os

# Ensure backend root is in PYTHONPATH
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient
from app.main import app
from app.services.graph_service import graph_service

client = TestClient(app)

@pytest.fixture(scope="session", autouse=True)
def setup_database():
    """Ensure graph is seeded before tests run."""
    health = graph_service.get_health()
    if health.falkordb_connected:
        graph_service.seed_data(force=True)

def test_health():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["falkordb_connected"] is True
    assert data["node_count"] > 0
    assert data["edge_count"] > 0

def test_seed_idempotency():
    # Calling seed multiple times must not produce duplicate errors and retain counts
    res1 = client.post("/api/v1/seed")
    assert res1.status_code == 200
    node_count_1 = res1.json()["node_count"]

    res2 = client.post("/api/v1/seed")
    assert res2.status_code == 200
    node_count_2 = res2.json()["node_count"]
    assert node_count_1 == node_count_2

def test_city_layout():
    response = client.get("/api/v1/city")
    assert response.status_code == 200
    data = response.json()
    assert data["company_name"] == "NovaWorks"
    assert len(data["departments"]) == 4
    assert len(data["projects"]) == 6
    assert len(data["employees"]) == 20
    assert len(data["systems"]) == 8

def test_employee_profile():
    response = client.get("/api/v1/employees/emp_maya")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Maya Verma"
    assert data["title"] == "Principal Architect"
    assert len(data["skills"]) >= 2
    assert len(data["connections"]) >= 1
    # Check that Maya's connection includes payment service
    assert any("Payment" in conn for conn in data["connections"])

def test_project_detail_delayed_atlas():
    response = client.get("/api/v1/projects/proj_atlas")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Project Atlas"
    assert data["status"] == "delayed"
    assert len(data["systems_used"]) > 0
    assert len(data["decisions"]) > 0
    assert len(data["documents"]) > 0

def test_assistant_payment_expertise():
    payload = {"question": "Who has experience with the payment service?"}
    response = client.post("/api/v1/assistant/ask", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "PAYMENT_EXPERTISE"
    assert "Maya Verma" in data["answer"]
    assert len(data["evidence_path"]) > 0
    assert len(data["supporting_entities"]) > 0

def test_assistant_incident_investigation():
    payload = {"question": "Who helped resolve the previous payment-service incident?"}
    response = client.post("/api/v1/assistant/ask", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "INCIDENT_INVESTIGATION"
    assert "Maya Verma" in data["answer"]
    assert "INC-104" in data["answer"]
    assert len(data["source_records"]) > 0

def test_assistant_decision_provenance():
    payload = {"question": "Which decision explains our authentication redesign?"}
    response = client.post("/api/v1/assistant/ask", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "DECISION_PROVENANCE"
    assert "DEC-201" in data["answer"]
    assert "Alex Rivera" in data["answer"]
    assert "DOC-03" in data["answer"]

def test_assistant_project_delay():
    payload = {"question": "Why was Project Atlas delayed?"}
    response = client.post("/api/v1/assistant/ask", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "PROJECT_DELAY"
    assert "DEC-202" in data["answer"]
    assert "Core Database" in data["answer"]
    assert "Liam Chen" in data["answer"]

def test_assistant_unknown_information():
    payload = {"question": "Who is working on Project Apollo and the quantum compiler?"}
    response = client.post("/api/v1/assistant/ask", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "UNKNOWN_QUERY"
    assert "not documented" in data["answer"].lower()
    assert len(data["supporting_entities"]) == 0

def test_graph_path():
    payload = {"source_id": "emp_maya", "target_id": "sys_payment", "max_hops": 3}
    response = client.post("/api/v1/graph/path", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["found"] is True
    assert len(data["nodes"]) >= 2
    assert "Maya Verma" in data["explanation"]
    assert "Payment" in data["explanation"]

def test_document_ingestion():
    payload = {
        "id": "doc_test_101",
        "title": "API Gateway Rate Limiting RFC",
        "doc_type": "RFC",
        "summary": "Token bucket rate limiter specification for public endpoints.",
        "content": "This RFC specifies a leaky bucket rate limit of 100 req/sec per API key.",
        "author_id": "emp_maya",
        "system_id": "sys_payment"
    }
    response = client.post("/api/v1/ingest/document", json=payload)
    assert response.status_code == 200
    assert response.json()["status"] == "success"
