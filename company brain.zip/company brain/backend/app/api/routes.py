from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List, Dict, Any
from app.services.graph_service import graph_service
from app.assistant.pipeline import assistant_pipeline
from app.tools import shortest_path
from app.schemas.models import (
    CityResponse, EmployeeSummary, EmployeeProfile, ProjectBuilding,
    ProjectDetail, SystemModel, DocumentModel, DecisionModel, IncidentModel,
    GraphNeighborhood, PathQueryRequest, PathQueryResponse, GraphNode, GraphEdge,
    AssistantQueryRequest, AssistantQueryResponse, HealthResponse,
    IngestJsonRequest, IngestDocRequest, IngestDocResponse, SessionDetail
)

router = APIRouter(prefix="/api/v1")

@router.get("/health", response_model=HealthResponse)
def get_health():
    """Verify FalkorDB connectivity and return graph entity counts."""
    health = graph_service.get_health()
    if not health.falkordb_connected:
        raise HTTPException(
            status_code=503,
            detail=f"FalkorDB connection failed: {health.error}. Check that FalkorDB Docker container is running."
        )
    return health

@router.get("/city", response_model=CityResponse)
def get_city():
    """Get complete layout data for the interactive company city."""
    try:
        return graph_service.get_city_data()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load city data: {str(e)}")

@router.get("/employees", response_model=List[EmployeeSummary])
def get_employees(query: Optional[str] = None, department_id: Optional[str] = None):
    """Search and filter employees by name, title, role, or department."""
    return graph_service.get_employees(query=query, department_id=department_id)

@router.get("/employees/{employee_id}", response_model=EmployeeProfile)
def get_employee_profile(employee_id: str):
    """Retrieve deep employee profile with all connected graph relationships."""
    profile = graph_service.get_employee_profile(employee_id)
    if not profile:
        raise HTTPException(status_code=404, detail=f"Employee '{employee_id}' not found.")
    return profile

@router.get("/projects", response_model=List[ProjectBuilding])
def get_projects(query: Optional[str] = None, department_id: Optional[str] = None, status: Optional[str] = None):
    """Search and filter projects."""
    return graph_service.get_projects(query=query, department_id=department_id, status=status)

@router.get("/projects/{project_id}", response_model=ProjectDetail)
def get_project_detail(project_id: str):
    """Retrieve complete project details with team, dependencies, decisions, and incidents."""
    project = graph_service.get_project_detail(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found.")
    return project

@router.get("/systems", response_model=List[SystemModel])
def get_systems():
    """List company infrastructure systems and services."""
    return graph_service.get_systems()

@router.get("/systems/{system_id}", response_model=SystemModel)
def get_system_detail(system_id: str):
    """Retrieve detailed system information including owners, callers, and incidents."""
    system = graph_service.get_system_detail(system_id)
    if not system:
        raise HTTPException(status_code=404, detail=f"System '{system_id}' not found.")
    return system

@router.get("/documents", response_model=List[DocumentModel])
def get_documents():
    """List technical documents, RFCs, and postmortems."""
    return graph_service.get_documents()

@router.get("/decisions", response_model=List[DecisionModel])
def get_decisions():
    """List architectural and organizational decisions."""
    return graph_service.get_decisions()

@router.get("/incidents", response_model=List[IncidentModel])
def get_incidents():
    """List documented operational incidents and fixes."""
    return graph_service.get_incidents()

@router.get("/graph/neighborhood/{entity_id}", response_model=GraphNeighborhood)
def get_graph_neighborhood(entity_id: str, hops: int = Query(default=1, ge=1, le=2)):
    """Retrieve graph neighborhood around a selected entity for visual exploration."""
    return graph_service.get_neighborhood(entity_id, hops=hops)

@router.get("/entities/{entity_id}/relationships", response_model=GraphNeighborhood)
def get_entity_relationships(entity_id: str):
    """Alias for entity neighborhood relationships."""
    return graph_service.get_neighborhood(entity_id, hops=1)

@router.get("/graph/path", response_model=PathQueryResponse)
def get_graph_path(
    from_id: str = Query(..., alias="from"),
    to_id: str = Query(..., alias="to")
):
    """Find the shortest relationship path between two entities via query params."""
    res = shortest_path(from_id, to_id, max_hops=5)
    if not res.get("rows"):
        return PathQueryResponse(
            found=False,
            nodes=[],
            edges=[],
            explanation=f"No graph path discovered between '{from_id}' and '{to_id}'."
        )
    row = res["rows"][0]
    nodes = [GraphNode(id=n["id"], label=n["name"], type=n["type"]) for n in row.get("nodes", [])]
    edges = [
        GraphEdge(
            id=f"p_{e['from']}_{e['type']}_{e['to']}",
            source=e["from"],
            target=e["to"],
            type=e["type"],
            label=e["type"]
        ) for e in row.get("edges", [])
    ]
    return PathQueryResponse(
        found=True,
        nodes=nodes,
        edges=edges,
        explanation=row.get("summary", "Connected path")
    )

@router.post("/graph/path", response_model=PathQueryResponse)
def find_graph_path(req: PathQueryRequest):
    """Find the shortest relationship path between two entities via JSON body."""
    return graph_service.find_path(req.source_id, req.target_id, max_hops=req.max_hops)

@router.post("/assistant/ask", response_model=AssistantQueryResponse)
def ask_assistant(req: AssistantQueryRequest):
    """Ask WorkCity a natural-language question backed by real FalkorDB graph traversals."""
    try:
        return assistant_pipeline.answer_question(
            req.question,
            context_entity_id=req.context_entity_id,
            session_id=req.session_id
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Assistant reasoning failed: {str(e)}")

@router.get("/sessions/{session_id}", response_model=SessionDetail)
def get_session(session_id: str):
    """Retrieve historical turns and cited entities for a session."""
    return graph_service.get_session_history(session_id)

@router.post("/ingest/json")
def ingest_json(req: IngestJsonRequest):
    """Import structured entity records and relationships into FalkorDB."""
    try:
        data_dict = req.model_dump(exclude_none=True)
        return graph_service.ingest_json(data_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to ingest JSON: {str(e)}")

@router.post("/ingest/document", response_model=IngestDocResponse)
def ingest_document(req: IngestDocRequest):
    """Ingest a text or markdown document and connect it to graph entities."""
    try:
        return graph_service.ingest_document(req.model_dump())
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to ingest document: {str(e)}")
