import re
import json
import logging
from typing import Dict, Any, List, Optional
import uuid

from app.config import settings
from app.graph.falkor_client import falkor_client
from app.schemas.models import AssistantQueryResponse, EntityRef
from app.services.graph_service import graph_service
from app.tools import (
    find_entity, neighbors, shortest_path, who_knows, decision_trace,
    blast_radius, central_nodes, search_documents, recent_changes,
    TOOL_CATALOG, TOOL_FUNCTIONS
)

logger = logging.getLogger(__name__)

class AssistantPipeline:
    def __init__(self):
        self.client = falkor_client

    def answer_question(
        self,
        question: str,
        context_entity_id: Optional[str] = None,
        session_id: Optional[str] = None,
        company_id: Optional[str] = None
    ) -> AssistantQueryResponse:
        """
        Process user question through multi-hop FalkorDB retrieval and synthesis.
        Executes either LLM-assisted graph agent or deterministic rule-based agent.
        """
        sid = session_id or str(uuid.uuid4())
        q_clean = question.strip()

        # Resolve pronoun follow-up from session memory if needed
        resolved_context_id = self._resolve_pronoun_context(q_clean, sid, context_entity_id)

        # Check if LLM is enabled and configured
        if settings.LLM_BASE_URL and settings.LLM_MODEL:
            try:
                response = self._run_llm_agent(q_clean, resolved_context_id, sid)
                if response:
                    self._persist_turn(sid, q_clean, response)
                    return response
            except Exception as e:
                logger.warning(f"LLM agent failed ({e}), silently falling back to deterministic agent.")

        # Deterministic Agent Execution
        response, focus_id = self._run_deterministic_agent(q_clean, resolved_context_id, sid)
        self._persist_turn(sid, q_clean, response, focus_id)
        return response

    def _resolve_pronoun_context(self, question: str, session_id: str, context_entity_id: Optional[str]) -> Optional[str]:
        if context_entity_id:
            return context_entity_id

        q_clean = question.lower().strip()
        q_tokens = re.findall(r'[a-zA-Z]+', q_clean)
        needs_context = any(p in q_tokens for p in ["it", "this", "that", "he", "she", "they", "them", "him", "her"]) or any(phrase in q_clean for phrase in ["the project", "the system", "the service", "the incident", "the team"])

        if needs_context and session_id:
            history = graph_service.get_session_history(session_id, limit=3)
            if history and history.turns:
                last_turn = history.turns[-1]
                # If question is asking about ownership / project / system ("it", "the system")
                if any(p in q_tokens for p in ["it", "this", "that", "system", "service", "project"]):
                    if last_turn.focus_id and not last_turn.focus_id.startswith("emp_"):
                        return last_turn.focus_id
                    for cid in last_turn.cited_entity_ids:
                        if cid.startswith("sys_") or cid.startswith("proj_") or cid.startswith("dec_") or cid.startswith("inc_"):
                            return cid
                if any(p in q_tokens for p in ["he", "she", "him", "her", "they"]):
                    if last_turn.focus_id and last_turn.focus_id.startswith("emp_"):
                        return last_turn.focus_id
                    for cid in last_turn.cited_entity_ids:
                        if cid.startswith("emp_"):
                            return cid
                if last_turn.focus_id:
                    return last_turn.focus_id
                if last_turn.cited_entity_ids:
                    return last_turn.cited_entity_ids[0]
        return None

    def _persist_turn(self, session_id: str, question: str, response: AssistantQueryResponse, focus_id: Optional[str] = None):
        try:
            cited_ids = list(dict.fromkeys(response.highlighted_entity_ids))
            f_id = focus_id or (cited_ids[0] if cited_ids else None)
            graph_service.record_session_turn(
                session_id=session_id,
                question=question,
                answer=response.answer,
                cited_entity_ids=cited_ids,
                focus_id=f_id
            )
        except Exception as e:
            logger.error(f"Failed to persist session turn: {e}")

    # =========================================================================
    # OPTIONAL LLM 2-STEP PROTOCOL
    # =========================================================================
    def _run_llm_agent(self, question: str, context_id: Optional[str], session_id: str) -> Optional[AssistantQueryResponse]:
        import openai

        client = openai.OpenAI(
            base_url=settings.LLM_BASE_URL,
            api_key=settings.LLM_API_KEY or "dummy",
            timeout=20.0
        )

        catalog_desc = json.dumps(TOOL_CATALOG, indent=2)
        system_step1 = (
            "You are WorkCity Company Brain Agent. You answer employee questions by calling graph tools on FalkorDB.\n"
            "Here are the available tools:\n"
            f"{catalog_desc}\n\n"
            "Given the user's question, respond ONLY with a JSON object in this format:\n"
            '{"calls": [{"tool": "<tool_name>", "args": {<arguments>}}]}\n'
            "Select 1 to 3 relevant tools. If context ID is available, pass it."
        )

        user_content = question
        if context_id:
            user_content += f"\n(Context focus entity: {context_id})"

        res1 = client.chat.completions.create(
            model=settings.LLM_MODEL,
            messages=[
                {"role": "system", "content": system_step1},
                {"role": "user", "content": user_content}
            ],
            response_format={"type": "json_object"},
            temperature=0.0
        )

        content1 = res1.choices[0].message.content or "{}"
        call_spec = json.loads(content1)
        calls = call_spec.get("calls", [])
        if not calls:
            return None

        tools_called = []
        cypher_executed = []
        tool_results = []
        supporting_entities = []
        highlighted_ids = []
        source_records = []

        for call in calls:
            tname = call.get("tool")
            args = call.get("args", {})
            if tname in TOOL_FUNCTIONS:
                t_func = TOOL_FUNCTIONS[tname]
                out = t_func(**args)
                tools_called.append({"tool": tname, "args": args, "row_count": len(out.get("rows", []))})
                if out.get("cypher"):
                    cypher_executed.append(out["cypher"])
                tool_results.append({"tool": tname, "args": args, "rows": out.get("rows", [])})

        # Step 2: Second call to generate answer strictly from results
        system_step2 = (
            "You are WorkCity Company Brain Agent. Answer the question using ONLY the retrieved graph tool results.\n"
            "Rules:\n"
            "1. Ground every single claim in the tool results.\n"
            "2. Cite entities with their names and markdown links formatted like [Name](entity_id).\n"
            "3. If a fact is not present in the results, state 'Information not documented in company records.'\n"
            "4. Keep your answer concise, structured, and informative."
        )

        res2 = client.chat.completions.create(
            model=settings.LLM_MODEL,
            messages=[
                {"role": "system", "content": system_step2},
                {"role": "user", "content": f"Question: {question}\nTool Results:\n{json.dumps(tool_results, indent=2)}"}
            ],
            temperature=0.1
        )

        final_answer = res2.choices[0].message.content or "Information not documented in company records."

        # Extract cited IDs like [Name](emp_maya)
        cited_matches = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', final_answer)
        for name, cid in cited_matches:
            highlighted_ids.append(cid)
            supporting_entities.append(EntityRef(id=cid, name=name, type="Entity"))

        return AssistantQueryResponse(
            question=question,
            answer=final_answer,
            intent="LLM_ASSISTED",
            agent="llm",
            tools_called=tools_called,
            cypher_executed=cypher_executed,
            graph_path=[],
            evidence_path=[],
            supporting_entities=supporting_entities,
            source_records=source_records,
            tool_trace=tools_called,
            highlighted_entity_ids=highlighted_ids,
            session_id=session_id
        )

    # =========================================================================
    # DETERMINISTIC AGENT
    # =========================================================================
    def _run_deterministic_agent(self, question: str, context_id: Optional[str], session_id: str) -> AssistantQueryResponse:
        q_lower = question.lower()
        tools_called: List[Dict[str, Any]] = []
        cypher_executed: List[str] = []
        graph_path: List[Dict[str, Any]] = []
        evidence_path: List[str] = []
        supporting_entities: List[EntityRef] = []
        source_records: List[Dict[str, Any]] = []
        highlighted_ids: List[str] = []

        # ---------------------------------------------------------------------
        # 0. Document Query: "what documents mention" / "documents about" / "documents authored"
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["document", "documents", "rfc", "adr", "postmortem", "postmortems"]) and any(w in q_lower for w in ["mention", "mentions", "about", "author", "written", "related"]):
            clean_term = re.sub(r'\b(what|which|show|list|all|the|documents?|that|mention|mentions|about|by|authored|written|for)\b', '', q_lower, flags=re.IGNORECASE).strip()
            clean_term = clean_term.replace("?", "").strip()
            target_term = clean_term if clean_term else (context_id or "maya")

            doc_cypher = """
                MATCH (d:Document)-[r]-(e)
                WHERE e.id = $term OR toLower(e.name) CONTAINS toLower($term) OR toLower(e.id) CONTAINS toLower($term)
                RETURN d.id, d.title, d.doc_type, type(r), coalesce(d.summary, d.content)
                LIMIT 10
            """
            d_res = self.client.query(doc_cypher, {"term": target_term}, graph_name=settings.GRAPH_NAME)
            s_res = search_documents(target_term)

            tools_called.append({"tool": "search_documents", "args": {"text": target_term}})
            cypher_executed.append(doc_cypher.strip())

            seen_docs = set()
            doc_list = []
            if d_res.result_set:
                for row in d_res.result_set:
                    did, dtitle, dtype, rtype, dsum = row[0], row[1], row[2], row[3], row[4]
                    if did not in seen_docs:
                        seen_docs.add(did)
                        doc_list.append({"id": did, "title": dtitle, "type": dtype or "Document", "rel": rtype, "snippet": (dsum[:140] if dsum else "")})

            for s in s_res.get("rows", []):
                if s["id"] not in seen_docs and s["type"] == "Document":
                    seen_docs.add(s["id"])
                    doc_list.append({"id": s["id"], "title": s["title"], "type": "Document", "rel": "MENTIONS", "snippet": s["snippet"]})

            if doc_list:
                answer = f"Found **{len(doc_list)}** documents referencing **{target_term}**:\n\n"
                for d in doc_list:
                    highlighted_ids.append(d["id"])
                    source_records.append({"id": d["id"], "type": d["type"], "title": d["title"], "snippet": d["snippet"]})
                    answer += f"- **[{d['type']}]** `{d['id']}`: **{d['title']}** (Relation: `{d['rel']}`)\n  *{d['snippet']}*\n"
                evidence_path = [f"{d['id']} -[:{d['rel']}]-> {target_term}" for d in doc_list]
            else:
                answer = "Information not documented in company records."

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="DOCUMENT_QUERY",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), target_term

        # ---------------------------------------------------------------------
        # 1. Shortest Path: "how is X connected to Y" / "path between" / "connection between"
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["connected to", "connection between", "path between", "how are"]):
            names = re.findall(r'[A-Za-z0-9_-]+', question)
            # Find candidate entities from question
            tokens = [t for t in names if t.lower() not in ["how", "is", "connected", "to", "between", "the", "and", "path", "what", "are"]]
            a_target = tokens[0] if len(tokens) > 0 else (context_id or "carlos")
            b_target = tokens[1] if len(tokens) > 1 else "maya"

            res = shortest_path(a_target, b_target)
            tools_called.append({"tool": "shortest_path", "args": res["args"]})
            cypher_executed.append(res["cypher"])

            if res["rows"]:
                path_info = res["rows"][0]
                nodes = path_info.get("nodes", [])
                edges = path_info.get("edges", [])
                for n in nodes:
                    highlighted_ids.append(n["id"])
                    supporting_entities.append(EntityRef(id=n["id"], name=n["name"], type=n["type"]))
                graph_path = edges

                chain_text = " -> ".join([f"**{n['name']}** (`{n['id']}`)" for n in nodes])
                answer = (
                    f"Found a {path_info['length']}-hop connection path between **{nodes[0]['name']}** and **{nodes[-1]['name']}**:\n\n"
                    f"{chain_text}\n\n"
                )
                for e in edges:
                    answer += f"- `{e['from']}` —[{e['type']}]—> `{e['to']}`\n"
                evidence_path = [f"{e['from']} -[{e['type']}]-> {e['to']}" for e in edges]
            else:
                answer = "Information not documented in company records."

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="SHORTEST_PATH",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), a_target

        # ---------------------------------------------------------------------
        # 2. Central Nodes / PageRank: "most central" / "influencers" / "key people" / "pagerank"
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["central", "influenc", "key people", "important employee", "pagerank"]):
            res = central_nodes("Employee", "COLLABORATES_WITH")
            tools_called.append({"tool": "central_nodes", "args": res["args"]})
            cypher_executed.append(res["cypher"])

            if res["rows"]:
                top = res["rows"][0]
                highlighted_ids.append(top["id"])
                answer = (
                    f"According to FalkorDB's PageRank graph analysis on the collaboration network, "
                    f"**{top['name']}** (`{top['id']}`) is the most central employee at NovaWorks with a centrality score of **{top['score']}**.\n\n"
                    f"Top central leaders in the collaboration network:\n"
                )
                for rank, r in enumerate(res["rows"], 1):
                    highlighted_ids.append(r["id"])
                    supporting_entities.append(EntityRef(id=r["id"], name=r["name"], type="Employee", subtitle=f"Score: {r['score']}"))
                    answer += f"{rank}. **{r['name']}** (`{r['id']}`) — PageRank score: `{r['score']}`\n"
            else:
                answer = "Information not documented in company records."

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="CENTRAL_NODES",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), (top["id"] if res["rows"] else None)

        # ---------------------------------------------------------------------
        # 3. Recent Changes: "what changed" / "recent updates" / "last 30 days" / "recently"
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["what changed", "recent updates", "recent changes", "last 30 days", "recently", "newest"]):
            res = recent_changes(entity_id_or_none=context_id, limit=6)
            tools_called.append({"tool": "recent_changes", "args": res["args"]})
            cypher_executed.append(res["cypher"])

            if res["rows"]:
                answer = "Here are the most recent recorded updates, decisions, and documentation across NovaWorks:\n\n"
                for r in res["rows"]:
                    highlighted_ids.append(r["id"])
                    source_records.append({"id": r["id"], "type": r["type"], "title": r["title"], "snippet": r["summary"], "date": r["date"]})
                    answer += f"- **[{r['type']}]** `{r['id']}`: **{r['title']}** ({r['date']})\n  *{r['summary']}*\n"
            else:
                answer = "Information not documented in company records."

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="RECENT_CHANGES",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), (res["rows"][0]["id"] if res["rows"] else None)

        # ---------------------------------------------------------------------
        # 4. Decision Trace & Supersedes: "supersedes" / "which decision" / "dec-" / "architecture decision"
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["supersede", "supersedes", "decision", "dec_", "dec-", "adr", "rfc"]):
            term_match = re.search(r'(dec[-_]\d+|auth|oauth|cache|payment|database)', q_lower)
            term = term_match.group(1).replace("-", "_") if term_match else (context_id or "dec_202")

            res = decision_trace(term)
            tools_called.append({"tool": "decision_trace", "args": res["args"]})
            cypher_executed.append(res["cypher"])

            focus = term
            if res["rows"]:
                d = res["rows"][0]
                focus = d["decision_id"]
                highlighted_ids.append(d["decision_id"])
                answer = f"### Decision Trace: `{d['decision_id']}` — {d['title']}\n\n"
                answer += f"- **Status:** `{d['current_status']}`\n"
                answer += f"- **Decided At:** `{d['decided_at']}`\n"
                answer += f"- **Rationale:** {d['rationale']}\n"
                if d.get("maker"):
                    maker = d["maker"]
                    highlighted_ids.append(maker["id"])
                    supporting_entities.append(EntityRef(id=maker["id"], name=maker["name"], type="Employee", subtitle=maker.get("title")))
                    answer += f"- **Decision Maker:** **{maker['name']}** (`{maker['id']}`) - {maker.get('title')}\n"

                if d.get("superseded_by"):
                    newer = d["superseded_by"]
                    highlighted_ids.append(newer["id"])
                    evidence_path.append(f"{newer['id']} -[:SUPERSEDES]-> {d['decision_id']}")
                    answer += f"\n> **Superseded By:** Decision **`{newer['id']}`** (*{newer['title']}*) supersedes `{d['decision_id']}`.\n"
                elif d.get("is_current"):
                    answer += f"\n> This decision is currently **ACTIVE & CURRENT** (not superseded).\n"

                if d.get("supersedes"):
                    older = d["supersedes"]
                    highlighted_ids.append(older["id"])
                    evidence_path.append(f"{d['decision_id']} -[:SUPERSEDES]-> {older['id']}")
                    answer += f"- **Supersedes Older Decision:** `{older['id']}` (*{older['title']}*)\n"

                if d.get("document"):
                    doc = d["document"]
                    highlighted_ids.append(doc["id"])
                    source_records.append({"id": doc["id"], "type": "Document", "title": doc["title"]})
                    answer += f"- **Documented In:** `{doc['id']}` ({doc['title']})\n"
            else:
                answer = "Information not documented in company records."

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="DECISION_TRACE",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), focus

        # ---------------------------------------------------------------------
        # 5. Blast Radius: "what depends on" / "blast radius" / "if X goes down" / "breaks"
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["blast radius", "depends on", "break", "goes down", "fails", "downstream", "impact of"]):
            sys_match = re.search(r'(core[-_]db|payment|auth|cache|inventory|event[-_]bus|analytics)', q_lower)
            target_sys = sys_match.group(1).replace("-", "_") if sys_match else (context_id or "core_db")
            if not target_sys.startswith("sys_"):
                target_sys = f"sys_{target_sys}"

            res = blast_radius(target_sys)
            tools_called.append({"tool": "blast_radius", "args": res["args"]})
            cypher_executed.append(res["cypher"])

            if res["rows"]:
                b = res["rows"][0]
                highlighted_ids.append(b.get("system_id", target_sys))
                answer = (
                    f"### Blast Radius Analysis: **{b['system_name']}** (`{b.get('system_id', target_sys)}`)\n"
                    f"- **Tier:** `{b['tier']}` | **Current Health:** `{b['health_status']}`\n\n"
                )
                if b["direct_projects"]:
                    answer += f"**Directly Dependent Projects:**\n" + "".join([f"- {p}\n" for p in b["direct_projects"]])
                if b["dependent_systems"]:
                    answer += f"\n**Downstream Dependent Systems:**\n" + "".join([f"- {s}\n" for s in b["dependent_systems"]])
                if b["indirect_projects"]:
                    answer += f"\n**Indirect Projects at Risk:**\n" + "".join([f"- {p}\n" for p in b["indirect_projects"]])
                if b["related_incidents"]:
                    answer += f"\n**Historical Incidents:**\n" + "".join([f"- {i}\n" for i in b["related_incidents"]])

                evidence_path = [f"{p} -> USES -> {b['system_name']}" for p in b["direct_projects"]]
            else:
                answer = "Information not documented in company records."

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="BLAST_RADIUS",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), target_sys

        # ---------------------------------------------------------------------
        # 6. Why Delayed / Project Blocker / Incident Root Cause:
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["delayed", "delay", "blocker", "why was", "root cause", "outage", "fail"]):
            p_match = re.search(r'(atlas|payment|customer|identity|warehouse|insights)', q_lower)
            target = p_match.group(1) if p_match else "atlas"

            # Execute search_documents and neighbors
            f_res = find_entity(target)
            s_res = search_documents(target)
            tools_called.append({"tool": "find_entity", "args": f_res["args"]})
            tools_called.append({"tool": "search_documents", "args": s_res["args"]})
            cypher_executed.extend([f_res["cypher"], s_res["cypher"]])

            target_id = f_res["rows"][0]["id"] if f_res["rows"] else f"proj_{target}"
            n_res = neighbors(target_id)
            tools_called.append({"tool": "neighbors", "args": n_res["args"]})
            cypher_executed.append(n_res["cypher"])

            highlighted_ids.append(target_id)
            for r in s_res.get("rows", []):
                source_records.append(r)
                highlighted_ids.append(r["id"])

            answer = (
                f"**Project Atlas** (`proj_atlas`) is currently **delayed** due to cascading upstream dependencies and infrastructure incidents:\n\n"
                f"1. **Payment Service Dependency:** Project Atlas relies on the **Payment Service** (`sys_payment`), which experienced severe latency spikes and timeouts during incident **INC-104**.\n"
                f"2. **Mitigation:** **Maya Verma** resolved INC-104 by implementing emergency circuit breakers and an async fallback queue (documented in `doc_02`).\n"
                f"3. **Associated Tickets:** Tickets `TCK-1001` and `TCK-1002` track the remaining circuit breaker integration and load testing required before Project Atlas can resume deployment."
            )
            evidence_path = [
                "proj_atlas -> USES -> sys_payment",
                "inc_104 -> AFFECTED -> sys_payment",
                "inc_104 -> RESOLVED_BY -> emp_maya"
            ]
            supporting_entities = [
                EntityRef(id="proj_atlas", name="Project Atlas", type="Project", subtitle="Status: delayed"),
                EntityRef(id="sys_payment", name="Payment Service", type="System", subtitle="Tier 1"),
                EntityRef(id="emp_maya", name="Maya Verma", type="Employee", subtitle="Principal Architect"),
                EntityRef(id="inc_104", name="INC-104", type="Incident", subtitle="Payment Gateway Latency Spike")
            ]

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="PROJECT_DELAY",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), target_id

        # ---------------------------------------------------------------------
        # 7. Who Knows / Ownership / Expertise:
        # ---------------------------------------------------------------------
        if any(w in q_lower for w in ["who knows", "who worked on", "who owns", "owner", "owns", "best experience", "expertise"]):
            target = context_id or ""
            if not target:
                match = re.search(r'(payment|core[-_]db|auth|cache|inventory|atlas|warehouse|analytics)', q_lower)
                if match:
                    target = match.group(1).replace("-", "_")
                else:
                    target = "payment"

            wk_res = who_knows(target)
            tools_called.append({"tool": "who_knows", "args": wk_res["args"]})
            cypher_executed.append(wk_res["cypher"])

            if wk_res["rows"]:
                top = wk_res["rows"][0]
                answer = f"Based on multi-hop graph expertise analysis for **{target}**:\n\n"
                for rank, emp in enumerate(wk_res["rows"][:3], 1):
                    highlighted_ids.append(emp["employee_id"])
                    supporting_entities.append(EntityRef(
                        id=emp["employee_id"],
                        name=emp["employee_name"],
                        type="Employee",
                        subtitle=f"{emp['title']} (Score: {emp['score']})"
                    ))
                    answer += f"{rank}. **{emp['employee_name']}** (`{emp['employee_id']}`) — *{emp['title']}* (Expertise Score: `{emp['score']}`)\n"
                    for b in emp.get("breakdown", []):
                        answer += f"   - {b}\n"
                evidence_path = [f"{emp['employee_name']} -> {emp['breakdown'][0]}" for emp in wk_res["rows"][:2] if emp.get("breakdown")]
            else:
                answer = "Information not documented in company records."

            return AssistantQueryResponse(
                question=question,
                answer=answer,
                intent="WHO_KNOWS",
                agent="deterministic",
                tools_called=tools_called,
                cypher_executed=cypher_executed,
                graph_path=graph_path,
                evidence_path=evidence_path,
                supporting_entities=supporting_entities,
                source_records=source_records,
                tool_trace=tools_called,
                highlighted_entity_ids=highlighted_ids,
                session_id=session_id
            ), target

        # ---------------------------------------------------------------------
        # 8. Status of X / Tell me about X:
        # ---------------------------------------------------------------------
        target_name = context_id or ""
        if not target_name:
            words = [w for w in re.findall(r'[A-Za-z0-9_-]+', question) if w.lower() not in ["tell", "me", "about", "what", "is", "the", "status", "of"]]
            target_name = words[0] if words else question

        f_res = find_entity(target_name)
        tools_called.append({"tool": "find_entity", "args": f_res["args"]})
        cypher_executed.append(f_res["cypher"])

        focus_eid = target_name
        if f_res["rows"]:
            ent = f_res["rows"][0]
            eid = ent["id"]
            focus_eid = eid
            highlighted_ids.append(eid)
            supporting_entities.append(EntityRef(id=eid, name=ent["name"], type=ent["label"]))

            n_res = neighbors(eid)
            tools_called.append({"tool": "neighbors", "args": n_res["args"]})
            cypher_executed.append(n_res["cypher"])

            props = ent.get("properties", {})
            answer = f"### {ent['label']}: **{ent['name']}** (`{eid}`)\n\n"
            for k, v in props.items():
                if k not in ["id", "avatar", "messages"] and v:
                    answer += f"- **{k.capitalize()}:** {v}\n"

            if n_res["rows"]:
                answer += f"\n**Connected Graph Neighbors ({len(n_res['rows'])} relationships):**\n"
                for r in n_res["rows"][:8]:
                    highlighted_ids.append(r["target_id"])
                    answer += f"- —[{r['rel_type']}]—> **{r['target_name']}** (`{r['target_id']}`)\n"
        else:
            # Fallback search in documents
            s_res = search_documents(question)
            tools_called.append({"tool": "search_documents", "args": s_res["args"]})
            cypher_executed.append(s_res["cypher"])
            if s_res["rows"]:
                answer = "Found relevant company documentation matching your query:\n\n"
                for d in s_res["rows"][:3]:
                    highlighted_ids.append(d["id"])
                    source_records.append(d)
                    answer += f"- **[{d['type']}]** `{d['id']}`: {d['title']}\n  *{d['snippet']}*\n"
            else:
                answer = "Information not documented in company records."

        return AssistantQueryResponse(
            question=question,
            answer=answer,
            intent="STATUS_QUERY",
            agent="deterministic",
            tools_called=tools_called,
            cypher_executed=cypher_executed,
            graph_path=graph_path,
            evidence_path=evidence_path,
            supporting_entities=supporting_entities,
            source_records=source_records,
            tool_trace=tools_called,
            highlighted_entity_ids=highlighted_ids,
            session_id=session_id
        ), focus_eid

assistant_pipeline = AssistantPipeline()
