from falkordb import FalkorDB
from app.config import settings
import logging
from typing import Dict, Optional, Any

logger = logging.getLogger(__name__)

class FalkorClient:
    def __init__(self):
        self._db: FalkorDB | None = None
        self._graphs: Dict[str, Any] = {}

    def get_db(self) -> FalkorDB:
        if self._db is None:
            self._db = FalkorDB(
                host=settings.FALKORDB_HOST,
                port=settings.FALKORDB_PORT,
                password=settings.FALKORDB_PASSWORD
            )
        return self._db

    def get_graph(self, graph_name: Optional[str] = None):
        target = graph_name or settings.GRAPH_NAME
        if target not in self._graphs:
            db = self.get_db()
            self._graphs[target] = db.select_graph(target)
            logger.info(f"Selected FalkorDB graph '{target}'")
        return self._graphs[target]

    def query(self, cypher: str, params: dict | None = None, graph_name: Optional[str] = None):
        """Execute a Cypher query with optional parameters on specified graph."""
        g = self.get_graph(graph_name)
        if params:
            return g.query(cypher, params)
        return g.query(cypher)

    def ping(self) -> bool:
        """Verify if FalkorDB is live and reachable."""
        try:
            db = self.get_db()
            g = db.select_graph(settings.GRAPH_NAME)
            g.query("RETURN 1")
            return True
        except Exception as e:
            logger.warning(f"FalkorDB ping failed: {e}")
            return False

falkor_client = FalkorClient()
