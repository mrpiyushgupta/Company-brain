import os
import asyncio
import logging
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import router
from app.services.graph_service import graph_service
from app.schemas.models import HealthResponse

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("workcity")

def _bootstrap_graph():
    """Wait for FalkorDB, then seed if the graph is empty. Runs in a worker thread."""
    import time
    for attempt in range(90):
        try:
            health = graph_service.get_health()
            if health.falkordb_connected:
                logger.info(f"FalkorDB connected (attempt {attempt+1}). Nodes: {health.node_count}, Edges: {health.edge_count}")
                if health.node_count == 0:
                    logger.info("Graph is empty. Seeding NovaWorks data...")
                    graph_service.seed_data(force=True)
                    logger.info("Graph seeded successfully.")
                return
        except Exception:
            logger.exception("Bootstrap attempt failed")
            return
        time.sleep(1)
    logger.error("Could not connect to FalkorDB after 90s.")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start serving immediately; connect and seed in the background.
    task = asyncio.create_task(asyncio.to_thread(_bootstrap_graph))
    yield
    task.cancel()
    logger.info("WorkCity shutting down...")

app = FastAPI(
    title="WorkCity API",
    description="The Living Company Brain powered by FalkorDB",
    version="1.0.0",
    lifespan=lifespan
)

# Same-origin CORS policy with local dev support
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:[0-9]+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Root /health alias
@app.get("/health", response_model=HealthResponse, tags=["Health"])
def root_health():
    return graph_service.get_health()

# Include primary API router
app.include_router(router)

# Locate frontend static dist folder
dist_candidates = [
    Path("/app/frontend/dist"),
    Path(__file__).resolve().parent.parent / "frontend" / "dist",
    Path(__file__).resolve().parent.parent.parent / "frontend" / "dist",
]

frontend_dist = None
for candidate in dist_candidates:
    if candidate.exists() and (candidate / "index.html").exists():
        frontend_dist = candidate
        break

if frontend_dist:
    logger.info(f"Mounting static frontend from {frontend_dist}")
    app.mount("/assets", StaticFiles(directory=frontend_dist / "assets"), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(request: Request, full_path: str):
        # Don't intercept API or docs routes
        if full_path.startswith("api/") or full_path.startswith("docs") or full_path.startswith("openapi.json"):
            return JSONResponse(status_code=404, content={"detail": "Not Found"})
        file_path = frontend_dist / full_path
        if file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(frontend_dist / "index.html")
else:
    logger.info("No built frontend found yet. Root serving API discovery.")
    @app.get("/")
    def root_info():
        return {
            "name": "WorkCity — The Living Company Brain",
            "version": "1.0.0",
            "status": "online",
            "docs_url": "/docs",
            "health_url": "/api/v1/health"
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
