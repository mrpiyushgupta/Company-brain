"""
Deterministic seed data generator for NovaWorks WorkCity.
Generates data/seed_data.json with fixed random seed, ensuring zero dangling references
and all required hackathon demo entities/relationships.
"""

import json
import os
import random
from typing import Dict, Any, List, Set

def generate_svg_avatar(initials: str, bg_color: str) -> str:
    """Generate self-contained inline SVG avatar (no external network calls)."""
    svg = (
        f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'>"
        f"<circle cx='50' cy='50' r='50' fill='{bg_color}'/>"
        f"<text x='50' y='60' font-size='38' font-weight='bold' font-family='system-ui, -apple-system, sans-serif' "
        f"text-anchor='middle' fill='white'>{initials}</text>"
        f"</svg>"
    )
    import urllib.parse
    return f"data:image/svg+xml;utf8,{urllib.parse.quote(svg)}"

def build_seed_data() -> Dict[str, Any]:
    random.seed(42)

    colors = ["#2563eb", "#7c3aed", "#059669", "#d97706", "#dc2626", "#0891b2", "#4f46e5", "#be185d"]

    # 1. Company
    company = {
        "name": "NovaWorks",
        "description": "NovaWorks is an intelligent enterprise platform powering distributed cloud infrastructure, payments, and commerce telemetry."
    }

    # 2. Departments (4)
    departments = [
        {"id": "dept_eng", "name": "Engineering", "district": "Engineering District", "description": "Core software architecture, backend platforms, services, and frontend applications.", "color": "#3b82f6"},
        {"id": "dept_prod", "name": "Product", "district": "Product District", "description": "Product strategy, user experience design, customer research, and feature roadmaps.", "color": "#8b5cf6"},
        {"id": "dept_ops", "name": "Operations", "district": "Operations District", "description": "Cloud infrastructure, security, site reliability, database management, and deployment pipelines.", "color": "#10b981"},
        {"id": "dept_research", "name": "Research & Data", "district": "Research & Data District", "description": "Data engineering, machine learning telemetry, graph analytics, and AI operational research.", "color": "#f59e0b"}
    ]

    # 3. Skills (16)
    skills = [
        {"id": "skill_dist_sys", "name": "Distributed Systems", "category": "Backend"},
        {"id": "skill_payment", "name": "Payment Processing", "category": "Domain"},
        {"id": "skill_sys_arch", "name": "System Architecture", "category": "Architecture"},
        {"id": "skill_k8s", "name": "Kubernetes", "category": "DevOps"},
        {"id": "skill_cloud_infra", "name": "Cloud Infrastructure", "category": "DevOps"},
        {"id": "skill_ml", "name": "Machine Learning", "category": "AI/Data"},
        {"id": "skill_graph_db", "name": "Graph Databases", "category": "Database"},
        {"id": "skill_oauth", "name": "OAuth2 & Security", "category": "Security"},
        {"id": "skill_cicd", "name": "CI/CD & Kafka", "category": "DevOps"},
        {"id": "skill_react", "name": "React & TypeScript", "category": "Frontend"},
        {"id": "skill_python", "name": "Python & AsyncIO", "category": "Backend"},
        {"id": "skill_redis", "name": "Redis & In-Memory Caching", "category": "Database"},
        {"id": "skill_security", "name": "Zero-Trust & Cryptography", "category": "Security"},
        {"id": "skill_graphql", "name": "GraphQL & API Gateways", "category": "Backend"},
        {"id": "skill_product_strategy", "name": "Product Strategy & Metrics", "category": "Product"},
        {"id": "skill_data_pipeline", "name": "Data Pipelines & ETL", "category": "AI/Data"}
    ]

    # 4. Employees (40)
    # Existing 20 employees
    existing_employees = [
        {"id": "emp_maya", "name": "Maya Verma", "title": "Principal Architect", "role": "Architecture Lead", "dept": "dept_eng", "bio": "Principal architect leading payment resilience, fault tolerance, and high-concurrency distributed designs."},
        {"id": "emp_piyush", "name": "Piyush Sharma", "title": "Staff Backend Engineer", "role": "Payment Core Lead", "dept": "dept_eng", "bio": "Specialist in high-throughput Go services, transaction settlement, and Redis-backed state machines."},
        {"id": "emp_elena", "name": "Elena Rostova", "title": "VP of Engineering", "role": "Executive Engineering Leader", "dept": "dept_eng", "bio": "Leads engineering organization, oversees technical roadmaps, reliability culture, and platform scale."},
        {"id": "emp_carlos", "name": "Carlos Mendez", "title": "Staff Infrastructure Engineer", "role": "Database & Cluster Lead", "dept": "dept_ops", "bio": "Leads database reliability, PostgreSQL sharding, connection pooling, and multi-region replication."},
        {"id": "emp_priya", "name": "Priya Nair", "title": "Lead Data Scientist", "role": "AI Telemetry Lead", "dept": "dept_research", "bio": "Researches anomaly detection, telemetry graph clustering, and automated incident triage models."},
        {"id": "emp_liam", "name": "Liam Chen", "title": "Senior Product Manager", "role": "Core Platform PM", "dept": "dept_prod", "bio": "Drives enterprise roadmap, system dependency scheduling, customer migration, and API SLAs."},
        {"id": "emp_marcus", "name": "Marcus Vance", "title": "Chief Technology Officer", "role": "Technical Executive", "dept": "dept_eng", "bio": "Sets multi-year technology vision, architecture council standards, and infrastructure modernization."},
        {"id": "emp_sophia", "name": "Sophia Patel", "title": "Senior DevOps Engineer", "role": "Streaming Infrastructure Lead", "dept": "dept_ops", "bio": "Architect of NovaWorks Kafka streaming cluster, event schema registries, and observability brokers."},
        {"id": "emp_arjun", "name": "Arjun Mehta", "title": "Senior Frontend Engineer", "role": "Web Experience Lead", "dept": "dept_eng", "bio": "Builds high-performance React applications, isometric graph visualizers, and design system components."},
        {"id": "emp_alex", "name": "Alex Rivera", "title": "Senior Security Engineer", "role": "Identity & Cryptography Lead", "dept": "dept_ops", "bio": "Designs zero-trust authentication gateways, OAuth2/OIDC protocols, and cryptographic token vaults."},
        {"id": "emp_nina", "name": "Nina Kowalski", "title": "Backend Software Engineer", "role": "Inventory Platform Engineer", "dept": "dept_eng", "bio": "Maintains distributed inventory catalog services, gRPC pipelines, and idempotent ledger updates."},
        {"id": "emp_kenji", "name": "Kenji Sato", "title": "Site Reliability Engineer", "role": "Caching & Low-Latency Lead", "dept": "dept_ops", "bio": "Specializes in Redis cluster performance, tail latency mitigation, and automated chaos testing."},
        {"id": "emp_chloe", "name": "Chloe Dubois", "title": "Principal Product Designer", "role": "Design Systems Lead", "dept": "dept_prod", "bio": "Designs user journeys, enterprise admin dashboards, and accessible visual components."},
        {"id": "emp_rachel", "name": "Rachel Kim", "title": "Staff Product Manager", "role": "Commerce & Billing PM", "dept": "dept_prod", "bio": "Spearheads recurring billing, merchant settlements, invoice pipelines, and PCI compliance roadmaps."},
        {"id": "emp_david", "name": "David O'Connor", "title": "Senior Data Engineer", "role": "Metrics Pipeline Lead", "dept": "dept_research", "bio": "Constructs real-time streaming ETL pipelines, metrics rollups, and ClickHouse telemetry stores."},
        {"id": "emp_tariq", "name": "Tariq Mansoor", "title": "Systems Reliability Engineer", "role": "Messaging & Alerts Lead", "dept": "dept_ops", "bio": "Owns incident alert routing, webhook dispatch engines, and cross-region message broker failover."},
        {"id": "emp_emily", "name": "Emily Watson", "title": "VP of Product", "role": "Executive Product Leader", "dept": "dept_prod", "bio": "Oversees global product vision, enterprise customer advisory boards, and cross-functional feature strategy."},
        {"id": "emp_omar", "name": "Omar Farooq", "title": "Machine Learning Engineer", "role": "Graph Neural Networks Specialist", "dept": "dept_research", "bio": "Implements graph representation learning, knowledge graph embeddings, and contextual entity ranking."},
        {"id": "emp_zoe", "name": "Zoe Martinez", "title": "Full Stack Engineer", "role": "Internal Developer Tools Lead", "dept": "dept_eng", "bio": "Develops internal developer portals, sandbox environments, and automated graph query explorers."},
        {"id": "emp_sarah", "name": "Sarah Jenkins", "title": "Engineering Director", "role": "Core Services Director", "dept": "dept_eng", "bio": "Manages core platform engineering pods, resource allocation, hiring, and system reliability governance."}
    ]

    # Additional 20 employees to reach 40 total
    new_employees = [
        {"id": "emp_lucas", "name": "Lucas Silva", "title": "Senior SRE", "role": "Kubernetes Fleet Lead", "dept": "dept_ops", "bio": "Maintains multi-cluster EKS infrastructure, Cilium service meshes, and automated node scaling."},
        {"id": "emp_dina", "name": "Dina Al-Hassan", "title": "Staff SRE", "role": "Incident Commander", "dept": "dept_ops", "bio": "Leads operational readiness reviews, major outage response, and runbook automation."},
        {"id": "emp_ananya", "name": "Ananya Roy", "title": "Software Engineer II", "role": "Payment Settlement Dev", "dept": "dept_eng", "bio": "Builds ledger reconciliation jobs, fraud prevention webhooks, and retry queue workers."},
        {"id": "emp_ben", "name": "Benjamin Cole", "title": "Senior Backend Engineer", "role": "Core DB Specialist", "dept": "dept_eng", "bio": "Focuses on high-volume PostgreSQL query optimization, connection pooling, and CDC replication."},
        {"id": "emp_fiona", "name": "Fiona Gallagher", "title": "Product Manager", "role": "Developer Experience PM", "dept": "dept_prod", "bio": "Manages public API specs, SDK releases, and developer documentation satisfaction metrics."},
        {"id": "emp_samuel", "name": "Samuel Jackson", "title": "Staff Security Engineer", "role": "Cloud Security Lead", "dept": "dept_ops", "bio": "Architects IAM boundaries, automated dependency vulnerability scanners, and KMS key rotation."},
        {"id": "emp_leila", "name": "Leila Moradi", "title": "Data Scientist", "role": "Churn Prediction Dev", "dept": "dept_research", "bio": "Trains predictive customer health models and usage anomaly classifiers using FalkorDB graphs."},
        {"id": "emp_victor", "name": "Victor Chen", "title": "Software Engineer II", "role": "API Gateway Engineer", "dept": "dept_eng", "bio": "Develops Envoy proxy filters, rate limiting plugins, and mTLS certificate automation."},
        {"id": "emp_grace", "name": "Grace Hopper-Lee", "title": "Senior Frontend Engineer", "role": "Design Systems Dev", "dept": "dept_eng", "bio": "Maintains NovaWorks Tailwind UI library, micro-frontends, and charting telemetry widgets."},
        {"id": "emp_hassan", "name": "Hassan Raza", "title": "Product Operations Lead", "role": "Release Coordinator", "dept": "dept_prod", "bio": "Coordinates cross-team release trains, feature flag rollouts, and customer migration stages."},
        {"id": "emp_isabella", "name": "Isabella Rossi", "title": "QA Automation Lead", "role": "E2E Testing Architect", "dept": "dept_eng", "bio": "Designs end-to-end synthetic testing suites, mock payment gateways, and load tests."},
        {"id": "emp_jacob", "name": "Jacob Stern", "title": "Data Platform Engineer", "role": "Kafka Pipeline Dev", "dept": "dept_research", "bio": "Manages schema registry governance, Avro serialization pipelines, and ClickHouse ingest."},
        {"id": "emp_kevin", "name": "Kevin Zhang", "title": "Backend Engineer", "role": "Search Platform Dev", "dept": "dept_eng", "bio": "Builds hybrid vector and full-text search indexing services using FalkorDB and Elasticsearch."},
        {"id": "emp_laura", "name": "Laura Bennett", "title": "Product Marketing Lead", "role": "Technical Enablement", "dept": "dept_prod", "bio": "Produces technical whitepapers, architectural case studies, and enterprise battlecards."},
        {"id": "emp_mikhail", "name": "Mikhail Volkov", "title": "Infrastructure Architect", "role": "Disaster Recovery Lead", "dept": "dept_ops", "bio": "Directs cross-region failover drills, backup integrity verification, and RTO/RPO SLAs."},
        {"id": "emp_nadia", "name": "Nadia Toure", "title": "Frontend Engineer", "role": "Dashboard Specialist", "dept": "dept_eng", "bio": "Builds real-time telemetry dashboards and interactive dependency graph explorers."},
        {"id": "emp_oliver", "name": "Oliver Hansen", "title": "Backend Engineer", "role": "Billing Engine Dev", "dept": "dept_eng", "bio": "Implements subscription invoice generators, Stripe webhook handlers, and tax computation services."},
        {"id": "emp_paula", "name": "Paula Gomez", "title": "Operations Analyst", "role": "Cost Optimization Lead", "dept": "dept_ops", "bio": "Tracks cloud infrastructure expenditure, reserved instance purchasing, and cluster rightsizing."},
        {"id": "emp_quinn", "name": "Quinn Taylor", "title": "AI Research Scientist", "role": "LLM Reasoning Lead", "dept": "dept_research", "bio": "Develops graph-augmented LLM retrieval agents, structured query planners, and verification benchmarks."},
        {"id": "emp_ramon", "name": "Ramon Diaz", "title": "Support Engineering Lead", "role": "Tier 3 Escalations", "dept": "dept_ops", "bio": "Triages complex production edge-cases, customer network traces, and distributed transaction logs."}
    ]

    all_emp_defs = existing_employees + new_employees
    employees = []
    for emp in all_emp_defs:
        parts = emp["name"].split()
        initials = (parts[0][0] + (parts[1][0] if len(parts) > 1 else "")).upper()
        avatar = generate_svg_avatar(initials, colors[hash(emp["id"]) % len(colors)])
        employees.append({
            "id": emp["id"],
            "name": emp["name"],
            "title": emp["title"],
            "role": emp["role"],
            "department_id": emp["dept"],
            "email": f"{emp['id']}@novaworks.internal",
            "avatar": avatar,
            "bio": emp["bio"]
        })

    # 5. Systems (14)
    # Existing: sys_payment, sys_core_db, sys_auth, sys_cache, sys_inventory, sys_event_bus, sys_metrics, sys_notifications
    systems = [
        {"id": "sys_payment", "name": "Payment Platform", "tier": "Tier 1", "technology": "Go, Redis, Postgres", "description": "High-throughput credit card processing, merchant settlement, and transaction ledger.", "health_status": "healthy"},
        {"id": "sys_core_db", "name": "Core Database", "tier": "Tier 1", "technology": "PostgreSQL 16 Cluster", "description": "Primary transactional multi-tenant cluster with sharded tables and streaming replicas.", "health_status": "degraded"},
        {"id": "sys_auth", "name": "Auth Gateway", "tier": "Tier 1", "technology": "Rust, Envoy, OAuth2/OIDC", "description": "Identity provider, asymmetric JWT issuing service, session token vault, and MFA gateway.", "health_status": "healthy"},
        {"id": "sys_cache", "name": "Shared Cache Cluster", "tier": "Tier 2", "technology": "Redis 7.2 Sentinel", "description": "In-memory caching layer for user sessions, rate-limit buckets, and entity lookups.", "health_status": "healthy"},
        {"id": "sys_inventory", "name": "Inventory Service", "tier": "Tier 2", "technology": "Go, gRPC, PostgreSQL", "description": "Tracks catalog items, inventory reservations, real-time stock counts, and SKU allocations.", "health_status": "healthy"},
        {"id": "sys_event_bus", "name": "Event Bus", "tier": "Tier 1", "technology": "Apache Kafka 3.6 Cluster", "description": "Enterprise event streaming backbone for transaction, auditing, and telemetry topics.", "health_status": "healthy"},
        {"id": "sys_metrics", "name": "Telemetry & Metrics Store", "tier": "Tier 2", "technology": "ClickHouse, Prometheus", "description": "Time-series database storing operational infrastructure telemetry and billing metrics.", "health_status": "healthy"},
        {"id": "sys_notifications", "name": "Notification Dispatcher", "tier": "Tier 3", "technology": "Node.js, AWS SES/SNS", "description": "Multi-channel notification engine routing SMS, transactional emails, and merchant webhooks.", "health_status": "healthy"},
        {"id": "sys_api_gateway", "name": "Edge API Gateway", "tier": "Tier 1", "technology": "Envoy, Lua, Wasm", "description": "Edge routing layer managing global ingress, DDoS mitigation, and request authorization.", "health_status": "healthy"},
        {"id": "sys_billing_svc", "name": "Billing & Invoicing Engine", "tier": "Tier 1", "technology": "Python, Stripe API, Postgres", "description": "Subscription life-cycle manager, proration calculator, and monthly PDF invoice generator.", "health_status": "healthy"},
        {"id": "sys_ledger", "name": "Immutable Double-Entry Ledger", "tier": "Tier 1", "technology": "Go, Cryptographic Chain", "description": "Tamper-evident audit ledger recording every credit and debit in micro-cents.", "health_status": "healthy"},
        {"id": "sys_analytics_dw", "name": "Analytics Data Warehouse", "tier": "Tier 2", "technology": "Snowflake, dbt", "description": "Historical data warehouse powering executive reporting, KPI rollups, and ML pipelines.", "health_status": "healthy"},
        {"id": "sys_search", "name": "Search & Discovery Engine", "tier": "Tier 2", "technology": "FalkorDB Graph & Vector Index", "description": "Semantic knowledge search indexing employee bios, documentation, and operational entities.", "health_status": "healthy"},
        {"id": "sys_config", "name": "Dynamic Configuration Hub", "tier": "Tier 2", "technology": "etcd, Consul", "description": "Centralized feature-flag and dynamic configuration store with sub-second propagation.", "health_status": "healthy"}
    ]

    # 6. Projects (12)
    # Existing: proj_atlas (delayed), proj_payment (active), proj_cloud (active), proj_inventory (active), proj_ai_ops (active), proj_portal (active)
    projects = [
        {"id": "proj_atlas", "name": "Project Atlas", "department_id": "dept_eng", "status": "delayed", "priority": "critical", "district_x": 120, "district_y": 110, "description": "Next-generation distributed database sharding and cross-region customer catalog partition.", "risks": "Delayed by 6 weeks due to Core Database lock contention during table migration (INC-108)."},
        {"id": "proj_payment", "name": "Payment Platform Modernization", "department_id": "dept_eng", "status": "active", "priority": "critical", "district_x": 280, "district_y": 110, "description": "Zero-downtime PCI-DSS migration, idempotent settlement workflows, and payment gateway retry automation.", "risks": "Strict p99 latency threshold of 120ms for bank settlement endpoints."},
        {"id": "proj_cloud", "name": "Nova Cloud Console", "department_id": "dept_prod", "status": "active", "priority": "high", "district_x": 580, "district_y": 110, "description": "Unified self-service management console for enterprise customer accounts and permission governance.", "risks": "Dependency on Auth Gateway migration to complete seamless token SSO."},
        {"id": "proj_inventory", "name": "Global Inventory Sync", "department_id": "dept_eng", "status": "active", "priority": "medium", "district_x": 760, "district_y": 110, "description": "Sub-second synchronization pipeline for omnichannel enterprise stock counts and warehouse allocations.", "risks": "High-volume lock contention on Redis hot keys during flash sales."},
        {"id": "proj_ai_ops", "name": "AIOps Graph Intelligence", "department_id": "dept_research", "status": "active", "priority": "high", "district_x": 120, "district_y": 420, "description": "Real-time incident blast radius estimation and root cause topology analyzer powered by FalkorDB.", "risks": "Continuous graph index synchronizations under heavy incident alert streams."},
        {"id": "proj_portal", "name": "Developer Ecosystem Portal", "department_id": "dept_prod", "status": "active", "priority": "medium", "district_x": 280, "district_y": 420, "description": "Public developer documentation, interactive API console, and automated webhook sandbox.", "risks": "Tight integration required with Edge API Gateway routing layers."},
        {"id": "proj_ledger", "name": "Cryptographic Ledger Audit", "department_id": "dept_eng", "status": "active", "priority": "high", "district_x": 580, "district_y": 420, "description": "Immutable ledger tracking all financial balance transfers with zero-knowledge proof verification.", "risks": "High memory consumption during large block batching cycles."},
        {"id": "proj_analytics", "name": "Real-Time Telemetry Lake", "department_id": "dept_research", "status": "in_review", "priority": "medium", "district_x": 760, "district_y": 420, "description": "Low-latency ClickHouse ingestion pipeline aggregating operational health metrics from 10,000 nodes.", "risks": "Storage cost optimization on AWS S3 cold tier lifecycle policies."},
        {"id": "proj_checkout", "name": "One-Click Checkout V3", "department_id": "dept_prod", "status": "delayed", "priority": "high", "district_x": 200, "district_y": 250, "description": "Streamlined buyer experience with biometric auth and integrated localized payment rails.", "risks": "Blocked waiting for Payment Platform modernization bank adapters."},
        {"id": "proj_observability", "name": "OpenTelemetry Unification", "department_id": "dept_ops", "status": "completed", "priority": "high", "district_x": 380, "district_y": 250, "description": "Consolidated tracing, logging, and metrics standard across all internal Go, Rust, and Python services.", "risks": "Fully rolled out across 100% of production workloads."},
        {"id": "proj_billing", "name": "Usage-Based Billing V2", "department_id": "dept_prod", "status": "completed", "priority": "medium", "district_x": 660, "district_y": 250, "description": "Automated metering pipeline supporting per-seat, per-query, and tiered monthly invoice calculations.", "risks": "Successfully reconciled 99.999% of monthly merchant invoices."},
        {"id": "proj_mobile", "name": "Executive Mobile Brain", "department_id": "dept_prod", "status": "in_review", "priority": "low", "district_x": 840, "district_y": 250, "description": "Mobile executive companion application providing real-time operational status and knowledge graph querying.", "risks": "Security review of offline credential storage on iOS devices."}
    ]

    # 7. Decisions (15)
    # dec_201: Auth Redesign
    # dec_202: Project Atlas Delay
    # dec_206: SUPERSEDES dec_202 (resumed & cutover plan)
    # dec_190: Cookie-based auth (SUPERSEDED by dec_201)
    decisions = [
        {"id": "dec_201", "title": "Authentication Redesign to OAuth2 / OIDC", "status": "Approved", "created_at": "2026-06-10T10:00:00Z", "decided_at": "2026-06-15T14:30:00Z", "rationale": "Replaced stateful legacy cookie sessions with stateless asymmetric JWT bearer tokens issued by Auth Gateway (sys_auth) to eliminate session fixation and enable seamless SSO across Nova Cloud Console and Customer Portal.", "maker_id": "emp_alex", "project_id": "proj_cloud", "document_id": "doc_03"},
        {"id": "dec_202", "title": "Project Atlas Schedule Adjustment & Delay", "status": "Superseded", "created_at": "2026-08-18T09:00:00Z", "decided_at": "2026-08-20T16:00:00Z", "rationale": "Project Atlas target Beta milestone shifted by 6 weeks due to severe lock contention (INC-108) on Core Database (sys_core_db) during online schema partition migration.", "maker_id": "emp_liam", "project_id": "proj_atlas", "document_id": "doc_04"},
        {"id": "dec_206", "title": "Project Atlas Resumed & Partition Cutover Plan", "status": "Approved", "created_at": "2026-09-10T11:00:00Z", "decided_at": "2026-09-15T15:00:00Z", "rationale": "Supersedes DEC-202. Resumes Project Atlas partition rollout using pg_repack with statement timeouts capped at 5s during scheduled weekend maintenance window. Confirmed zero production lock contention.", "maker_id": "emp_carlos", "project_id": "proj_atlas", "document_id": "doc_10"},
        {"id": "dec_190", "title": "Cookie-Based Session State Storage", "status": "Superseded", "created_at": "2025-03-01T10:00:00Z", "decided_at": "2025-03-05T12:00:00Z", "rationale": "Initial MVP authentication architecture utilizing encrypted session cookies backed by shared Redis instances. Deprecated and superseded by DEC-201 due to cross-domain SSO limitations.", "maker_id": "emp_marcus", "project_id": "proj_cloud", "document_id": "doc_11"},
        {"id": "dec_203", "title": "Adoption of FalkorDB as Enterprise Knowledge Graph Engine", "status": "Approved", "created_at": "2026-05-01T09:00:00Z", "decided_at": "2026-05-10T11:00:00Z", "rationale": "Selected FalkorDB for real-time Cypher graph traversals, low-latency Redis protocol integration, and sub-millisecond multi-hop relationship indexing across internal systems and teams.", "maker_id": "emp_marcus", "project_id": "proj_ai_ops", "document_id": "doc_12"},
        {"id": "dec_204", "title": "Migration to Kafka 3.6 for Event Streaming", "status": "Approved", "created_at": "2026-04-12T10:00:00Z", "decided_at": "2026-04-20T16:00:00Z", "rationale": "Standardized all asynchronous microservice communication on Kafka with strict Avro schema registry validation and exactly-once event processing semantics.", "maker_id": "emp_sophia", "project_id": "proj_payment", "document_id": "doc_13"},
        {"id": "dec_205", "title": "Payment Settlement Idempotency Protocol Standard", "status": "Approved", "created_at": "2026-07-01T13:00:00Z", "decided_at": "2026-07-08T15:00:00Z", "rationale": "Mandated dual-key idempotency headers (Client-Request-Id + Merchant-Id) stored in Redis with 24-hour TTL for every payment processing endpoint to guarantee zero double-charging.", "maker_id": "emp_maya", "project_id": "proj_payment", "document_id": "doc_01"},
        {"id": "dec_207", "title": "ClickHouse for High-Volume Observability Telemetry", "status": "Approved", "created_at": "2026-06-05T10:00:00Z", "decided_at": "2026-06-12T14:00:00Z", "rationale": "Replaced legacy Elasticsearch cluster with ClickHouse for operational metrics and traces, reducing cloud infrastructure storage costs by 68%.", "maker_id": "emp_david", "project_id": "proj_analytics", "document_id": "doc_14"},
        {"id": "dec_208", "title": "Deprecation of REST APIs in Favor of Internal gRPC", "status": "Approved", "created_at": "2026-03-15T09:00:00Z", "decided_at": "2026-03-25T11:00:00Z", "rationale": "Transitioned internal service-to-service communication from JSON-over-HTTP to Protobuf-over-gRPC, achieving a 4x reduction in CPU serialization overhead.", "maker_id": "emp_piyush", "project_id": "proj_payment", "document_id": "doc_15"},
        {"id": "dec_209", "title": "Envoy Global Ingress Architecture", "status": "Approved", "created_at": "2026-05-18T10:00:00Z", "decided_at": "2026-05-28T16:00:00Z", "rationale": "Deployed Envoy proxy across edge Kubernetes clusters to unify rate-limiting, Wasm auth filters, and automatic TLS termination.", "maker_id": "emp_victor", "project_id": "proj_portal", "document_id": "doc_16"},
        {"id": "dec_210", "title": "PostgreSQL 16 Multi-Region Logical Replication Strategy", "status": "Approved", "created_at": "2026-04-02T11:00:00Z", "decided_at": "2026-04-15T15:00:00Z", "rationale": "Implemented pglogical replication to create read-only replica nodes in Europe and Asia, reducing cross-region query latency from 220ms to 8ms.", "maker_id": "emp_carlos", "project_id": "proj_atlas", "document_id": "doc_17"},
        {"id": "dec_211", "title": "Mandatory Rust Implementation for Cryptographic Ledger", "status": "Approved", "created_at": "2026-07-15T10:00:00Z", "decided_at": "2026-07-22T14:00:00Z", "rationale": "Selected Rust for Immutable Double-Entry Ledger (sys_ledger) to ensure memory safety without garbage collection latency pauses.", "maker_id": "emp_samuel", "project_id": "proj_ledger", "document_id": "doc_18"},
        {"id": "dec_212", "title": "Zero-Trust Service-to-Service mTLS Mandate", "status": "Approved", "created_at": "2026-02-10T10:00:00Z", "decided_at": "2026-02-20T12:00:00Z", "rationale": "Enforced SPIFFE/SPIRE cryptographic workload identities with mutual TLS on all internal service mesh calls.", "maker_id": "emp_alex", "project_id": "proj_observability", "document_id": "doc_19"},
        {"id": "dec_213", "title": "One-Click Checkout Biometric Auth Specification", "status": "Draft", "created_at": "2026-08-01T09:00:00Z", "decided_at": "2026-08-10T11:00:00Z", "rationale": "Introduces WebAuthn FIDO2 biometric authentication for instant merchant checkout on mobile and desktop browsers.", "maker_id": "emp_rachel", "project_id": "proj_checkout", "document_id": "doc_20"},
        {"id": "dec_214", "title": "Consolidated Incident Severity Matrix & P1 Escalation Policy", "status": "Approved", "created_at": "2026-01-15T10:00:00Z", "decided_at": "2026-01-25T14:00:00Z", "rationale": "Defined standardized criteria for P1 (critical customer impact, 15m page SLA), P2 (degraded service, 1h page SLA), and P3 (minor, business hours SLA).", "maker_id": "emp_dina", "project_id": "proj_observability", "document_id": "doc_21"}
    ]

    # 8. Documents (30) with rich multi-paragraph technical content
    documents = [
        {"id": "doc_01", "title": "RFC 402: Payment Platform Resilience & Retry Protocol", "doc_type": "RFC", "summary": "Architecture specification for idempotent payment processing and circuit breakers.", "content": "This RFC establishes the reliability requirements for Payment Platform (sys_payment). All client checkouts must transmit an idempotent key. In the event of a gateway timeout, exponential backoff with full jitter will protect upstream bank partner connections. Authored by Maya Verma and approved by Architecture Council.", "author_id": "emp_maya", "project_id": "proj_payment", "system_id": "sys_payment", "created_at": "2026-07-02T10:00:00Z", "updated_at": "2026-07-08T15:00:00Z"},
        {"id": "doc_02", "title": "Postmortem: INC-104 Payment Webhook Timeout and Redis Recovery", "doc_type": "Postmortem", "summary": "Root cause analysis for payment webhook timeouts during bank partner failover.", "content": "During peak hours on July 14, Payment Platform (sys_payment) experienced elevated p99 latency exceeding 8000ms. An unindexed Redis transaction lock blocked worker threads. Staff Engineer Maya Verma diagnosed connection pool exhaustion and deployed a Redis Sentinel failover script, restoring nominal 45ms settlement latency.", "author_id": "emp_maya", "project_id": "proj_payment", "system_id": "sys_payment", "created_at": "2026-07-15T09:00:00Z", "updated_at": "2026-07-15T16:00:00Z"},
        {"id": "doc_03", "title": "ADR: Auth Gateway Migration to OAuth2 and OIDC (DEC-201)", "doc_type": "ADR", "summary": "Architecture Decision Record detailing migration from legacy cookie sessions to OAuth2 JWT tokens.", "content": "Documenting DEC-201. Auth Gateway (sys_auth) will issue RS256 signed JWT tokens with 15-minute expiration and refresh rotation. Alex Rivera verified that this architecture eliminates cross-site scripting vulnerabilities and enables unified single sign-on across Nova Cloud Console (proj_cloud) and Customer Portal.", "author_id": "emp_alex", "project_id": "proj_cloud", "system_id": "sys_auth", "created_at": "2026-06-12T10:00:00Z", "updated_at": "2026-06-15T14:30:00Z"},
        {"id": "doc_04", "title": "Status Report: Project Atlas Schedule Adjustment & Dependency Impact (DEC-202)", "doc_type": "Status Report", "summary": "Detailed notification of Project Atlas delay following Core Database lock contention.", "content": "Project Atlas (proj_atlas) target Beta milestone is formally extended by 6 weeks per DEC-202. The delay stems directly from database migration lock contention (INC-108) on Core Database (sys_core_db). Carlos Mendez terminated the blocking lock query. Testing will resume once partition cutover scripts are verified in staging.", "author_id": "emp_liam", "project_id": "proj_atlas", "system_id": "sys_core_db", "created_at": "2026-08-19T09:00:00Z", "updated_at": "2026-08-20T16:00:00Z"},
        {"id": "doc_05", "title": "Postmortem: INC-108 Core Database Table Partition Lock Contention", "doc_type": "Postmortem", "summary": "Postmortem analyzing exclusive table locks that halted Project Atlas migration.", "content": "On August 18, execution of ALTER TABLE schema migration scripts on Core Database (sys_core_db) acquired an ACCESS EXCLUSIVE lock on the customer orders table. Carlos Mendez halted the destructive query and instituted mandatory statement timeouts. This incident directly informed DEC-202 and the eventual DEC-206 recovery plan.", "author_id": "emp_carlos", "project_id": "proj_atlas", "system_id": "sys_core_db", "created_at": "2026-08-20T10:00:00Z", "updated_at": "2026-08-21T12:00:00Z"},
        {"id": "doc_06", "title": "Research: AIOps Telemetry Graph Anomaly Detection", "doc_type": "Research", "summary": "Methodology for training graph neural networks on live telemetry topology.", "content": "Priya Nair and Omar Farooq outline the mathematical foundations of graph embeddings applied to NovaWorks infrastructure topologies in FalkorDB. The model identifies anomalous blast radius patterns 4.2 minutes faster than traditional threshold alerting.", "author_id": "emp_priya", "project_id": "proj_ai_ops", "system_id": "sys_metrics", "created_at": "2026-05-15T11:00:00Z", "updated_at": "2026-05-20T17:00:00Z"},
        {"id": "doc_07", "title": "Runbook: Inventory Catalog gRPC Failover & Sync", "doc_type": "Runbook", "summary": "Step-by-step operational instructions for recovering Inventory Service nodes.", "content": "Operational procedures for recovering Inventory Service (sys_inventory) during Redis cache cluster outages. Written by Nina Kowalski. Outlines cache pre-warming commands, database connection throttling, and dead-letter queue drain procedures.", "author_id": "emp_nina", "project_id": "proj_inventory", "system_id": "sys_inventory", "created_at": "2026-04-10T10:00:00Z", "updated_at": "2026-04-15T14:00:00Z"},
        {"id": "doc_08", "title": "Postmortem: INC-107 Redis Cache Shard Eviction Storm", "doc_type": "Postmortem", "summary": "Analysis of Redis memory eviction storm on Shared Cache Cluster.", "content": "Kenji Sato resolved a severe cache eviction storm on Shared Cache Cluster (sys_cache) caused by misconfigured TTL parameters in user profile caching. Upgraded maxmemory policy to allkeys-lru and doubled sentinel node memory limits.", "author_id": "emp_kenji", "project_id": "proj_payment", "system_id": "sys_cache", "created_at": "2026-06-25T11:00:00Z", "updated_at": "2026-06-26T15:00:00Z"},
        {"id": "doc_09", "title": "Architecture RFC: Event Bus Kafka Partition Scaling", "doc_type": "RFC", "summary": "Technical roadmap for expanding Kafka broker topology to 32 partitions per topic.", "content": "Sophia Patel outlines partition rebalancing strategies for Event Bus (sys_event_bus) to support peak transaction throughput during holiday shopping events. Details disk volume IOPS provisioning and consumer group rebalance optimizations.", "author_id": "emp_sophia", "project_id": "proj_payment", "system_id": "sys_event_bus", "created_at": "2026-03-18T10:00:00Z", "updated_at": "2026-03-22T16:00:00Z"},
        {"id": "doc_10", "title": "Status Report: Project Atlas Resumed & Safe Cutover Plan (DEC-206)", "doc_type": "Status Report", "summary": "Notice of Project Atlas restart and safe database cutover window, superseding DEC-202.", "content": "Formal announcement superseding DEC-202. Carlos Mendez and Liam Chen report that Project Atlas (proj_atlas) partition cutover has been successfully rescheduled using non-blocking pg_repack routines. Lock analysis verifies zero contention on Core Database (sys_core_db). Beta launch confirmed for November 1.", "author_id": "emp_carlos", "project_id": "proj_atlas", "system_id": "sys_core_db", "created_at": "2026-09-12T10:00:00Z", "updated_at": "2026-09-15T15:00:00Z"},
        {"id": "doc_11", "title": "Legacy Architecture: Cookie Session State Spec (DEC-190)", "doc_type": "Architecture Spec", "summary": "Historical specification for cookie-based session state, superseded by DEC-201.", "content": "Historical documentation for DEC-190. Outlines the initial encrypted session cookie design implemented during NovaWorks founding. Superseded by DEC-201 (OAuth2/OIDC) to address mobile app compatibility and cross-domain token federation.", "author_id": "emp_marcus", "project_id": "proj_cloud", "system_id": "sys_auth", "created_at": "2025-03-02T10:00:00Z", "updated_at": "2025-03-05T12:00:00Z"},
        {"id": "doc_12", "title": "ADR: FalkorDB Selection for Organizational Brain (DEC-203)", "doc_type": "ADR", "summary": "Technical decision rationale for choosing FalkorDB graph engine.", "content": "Marcus Vance details why FalkorDB was selected over Neo4j and AWS Neptune: native Redis protocol compatibility, microsecond Cypher query execution, linear horizontal scaling, and seamless integration with Python AI agents.", "author_id": "emp_marcus", "project_id": "proj_ai_ops", "system_id": "sys_search", "created_at": "2026-05-05T10:00:00Z", "updated_at": "2026-05-10T11:00:00Z"},
        {"id": "doc_13", "title": "Standard Operating Procedure: Kafka Topic Creation & Schema Governance", "doc_type": "SOP", "summary": "Rules for registering and evolving event bus Avro schemas.", "content": "Sophia Patel documents the mandatory compatibility levels for Schema Registry topics on Event Bus (sys_event_bus). Breaking schema changes without backward compatibility are automatically rejected by CI/CD linters.", "author_id": "emp_sophia", "project_id": "proj_payment", "system_id": "sys_event_bus", "created_at": "2026-04-15T11:00:00Z", "updated_at": "2026-04-20T16:00:00Z"},
        {"id": "doc_14", "title": "Benchmarking Report: ClickHouse vs Elasticsearch for Telemetry", "doc_type": "Benchmarking", "summary": "Empirical comparison of telemetry storage engines supporting DEC-207.", "content": "David O'Connor provides synthetic benchmarks comparing query latency and disk footprint across 5 billion log events. ClickHouse achieved 12x higher compression and sub-second aggregations, directly supporting decision DEC-207.", "author_id": "emp_david", "project_id": "proj_analytics", "system_id": "sys_metrics", "created_at": "2026-06-08T10:00:00Z", "updated_at": "2026-06-12T14:00:00Z"},
        {"id": "doc_15", "title": "RFC 510: Internal gRPC API Guidelines & Error Standards", "doc_type": "RFC", "summary": "Standard protobuf definitions and status code conventions for internal microservices.", "content": "Piyush Sharma specifies standard error models, tracing interceptors, and timeout propagation rules for all gRPC services connected to Payment Platform (sys_payment). Implements DEC-208.", "author_id": "emp_piyush", "project_id": "proj_payment", "system_id": "sys_payment", "created_at": "2026-03-20T10:00:00Z", "updated_at": "2026-03-25T11:00:00Z"},
        {"id": "doc_16", "title": "Runbook: Edge API Gateway Ingress Failover & Wasm Filter Deployment", "doc_type": "Runbook", "summary": "Operational procedures for deploying Wasm plugins to Envoy Edge Gateways.", "content": "Victor Chen details safe blue/green deployment protocols for Envoy plugins on Edge API Gateway (sys_api_gateway), including automatic healthcheck canary verification and rollback commands.", "author_id": "emp_victor", "project_id": "proj_portal", "system_id": "sys_api_gateway", "created_at": "2026-05-22T10:00:00Z", "updated_at": "2026-05-28T16:00:00Z"},
        {"id": "doc_17", "title": "Architecture Spec: Multi-Region PostgreSQL Replication (DEC-210)", "doc_type": "Architecture Spec", "summary": "Design for asynchronous pglogical cross-region streaming replication.", "content": "Carlos Mendez and Benjamin Cole document the active-passive replica topology connecting primary US-East Core Database (sys_core_db) to read-replicas in Frankfurt and Singapore.", "author_id": "emp_carlos", "project_id": "proj_atlas", "system_id": "sys_core_db", "created_at": "2026-04-10T10:00:00Z", "updated_at": "2026-04-15T15:00:00Z"},
        {"id": "doc_18", "title": "Security Audit: Immutable Double-Entry Ledger Verification (DEC-211)", "doc_type": "Audit Report", "summary": "Third-party cryptographic audit report confirming zero balance mutability.", "content": "Samuel Jackson reviews the Rust implementation of Immutable Double-Entry Ledger (sys_ledger). Confirms SHA-256 block hashing guarantees tamper evidence across all historical financial records.", "author_id": "emp_samuel", "project_id": "proj_ledger", "system_id": "sys_ledger", "created_at": "2026-07-18T10:00:00Z", "updated_at": "2026-07-22T14:00:00Z"},
        {"id": "doc_19", "title": "Security Policy: Zero-Trust Service-to-Service mTLS (DEC-212)", "doc_type": "Policy", "summary": "Mandatory cryptographic certificate renewal rules for internal Kubernetes pods.", "content": "Alex Rivera establishes certificate lifetime limits of 24 hours managed by HashiCorp Vault and SPIRE. Any unencrypted plaintext TCP connection inside the cluster is dropped by firewall rules.", "author_id": "emp_alex", "project_id": "proj_observability", "system_id": "sys_auth", "created_at": "2026-02-15T10:00:00Z", "updated_at": "2026-02-20T12:00:00Z"},
        {"id": "doc_20", "title": "Product PRD: One-Click Checkout Biometric Auth (DEC-213)", "doc_type": "PRD", "summary": "Product requirements document for frictionless biometric checkout on merchant websites.", "content": "Rachel Kim and Chloe Dubois outline user onboarding flows for FIDO2 biometric authentication. Projected to increase merchant checkout conversion by 14% while eliminating password stuffing risks.", "author_id": "emp_rachel", "project_id": "proj_checkout", "system_id": "sys_payment", "created_at": "2026-08-05T10:00:00Z", "updated_at": "2026-08-10T11:00:00Z"},
        {"id": "doc_21", "title": "Operations Manual: Incident Command & P1 Escalation Matrix (DEC-214)", "doc_type": "Operations Manual", "summary": "Standard operating procedures for managing high-severity production outages.", "content": "Dina Al-Hassan and Ramon Diaz detail incident commander roles, war-room Zoom protocols, and executive status communication schedules during P1 platform outages.", "author_id": "emp_dina", "project_id": "proj_observability", "system_id": "sys_notifications", "created_at": "2026-01-20T10:00:00Z", "updated_at": "2026-01-25T14:00:00Z"},
        {"id": "doc_22", "title": "Postmortem: INC-114 Event Bus Broker Network Partition", "doc_type": "Postmortem", "summary": "Resolution of cross-AZ network split affecting Kafka message producers.", "content": "Dina Al-Hassan successfully resolved a split-brain condition on Event Bus (sys_event_bus) after AWS availability zone packet drops. Enforced a minimum insync replicas setting of 2.", "author_id": "emp_dina", "project_id": "proj_payment", "system_id": "sys_event_bus", "created_at": "2026-07-28T10:00:00Z", "updated_at": "2026-07-28T16:00:00Z"},
        {"id": "doc_23", "title": "Postmortem: INC-102 Auth Gateway TLS Certificate Expiration", "doc_type": "Postmortem", "summary": "Root cause analysis of brief token signing disruption due to stale intermediate certs.", "content": "Alex Rivera rotated expired intermediate root certificates on Auth Gateway (sys_auth) within 12 minutes of automated canary alert. Automated certificate renewal scripts were patched.", "author_id": "emp_alex", "project_id": "proj_cloud", "system_id": "sys_auth", "created_at": "2026-05-18T10:00:00Z", "updated_at": "2026-05-18T14:00:00Z"},
        {"id": "doc_24", "title": "Runbook: Billing Engine Daily Ledger Reconciliation", "doc_type": "Runbook", "summary": "Automated reconciliation job checks between Payment Platform and Stripe.", "content": "Oliver Hansen documents the automated balance matching scripts comparing entries in Billing & Invoicing Engine (sys_billing_svc) against Immutable Double-Entry Ledger (sys_ledger).", "author_id": "emp_oliver", "project_id": "proj_billing", "system_id": "sys_billing_svc", "created_at": "2026-06-20T10:00:00Z", "updated_at": "2026-06-25T14:00:00Z"},
        {"id": "doc_25", "title": "Architecture RFC: Dynamic Configuration & Fast Flag Propagation", "doc_type": "RFC", "summary": "Low-latency feature flagging infrastructure utilizing etcd watch channels.", "content": "Lucas Silva outlines the rollout of Dynamic Configuration Hub (sys_config), allowing feature flags to toggle across 1,000 microservice pods within 200 milliseconds.", "author_id": "emp_lucas", "project_id": "proj_cloud", "system_id": "sys_config", "created_at": "2026-04-25T10:00:00Z", "updated_at": "2026-04-30T15:00:00Z"},
        {"id": "doc_26", "title": "Research: LLM Agent Semantic Query Planning on FalkorDB", "doc_type": "Research", "summary": "Evaluation of structured tool execution versus generative hallucination.", "content": "Quinn Taylor evaluates deterministic agent pipelines against OpenAI models, proving graph-backed factual context retrieval eliminates hallucinations across enterprise compliance queries.", "author_id": "emp_quinn", "project_id": "proj_ai_ops", "system_id": "sys_search", "created_at": "2026-08-15T10:00:00Z", "updated_at": "2026-08-20T15:00:00Z"},
        {"id": "doc_27", "title": "Runbook: Database Read Replica Promotion & Disaster Recovery", "doc_type": "Runbook", "summary": "Failsafe promotion manual for Core Database standby clusters.", "content": "Benjamin Cole details emergency failover commands for promoting read replica nodes to primary on Core Database (sys_core_db) during primary hardware failure.", "author_id": "emp_ben", "project_id": "proj_atlas", "system_id": "sys_core_db", "created_at": "2026-06-18T10:00:00Z", "updated_at": "2026-06-22T14:00:00Z"},
        {"id": "doc_28", "title": "Status Report: Nova Cloud Console Multi-Tenant RBAC Rollout", "doc_type": "Status Report", "summary": "Delivery milestones for role-based access controls across enterprise accounts.", "content": "Chloe Dubois and Liam Chen verify that granular workspace permissions are now active for all enterprise tier customers using Nova Cloud Console (proj_cloud).", "author_id": "emp_chloe", "project_id": "proj_cloud", "system_id": "sys_auth", "created_at": "2026-07-25T10:00:00Z", "updated_at": "2026-07-30T14:00:00Z"},
        {"id": "doc_29", "title": "Design Specs: Isometric Company City Visual Language", "doc_type": "Design Spec", "summary": "Design tokens, palette values, and district layout coordinates for WorkCity.", "content": "Arjun Mehta and Chloe Dubois document the SVG coordinate mapping system, color gradients, and zero-flicker pointer hit-testing matrices used in WorkCity frontend.", "author_id": "emp_arjun", "project_id": "proj_portal", "system_id": "sys_search", "created_at": "2026-08-25T10:00:00Z", "updated_at": "2026-08-30T12:00:00Z"},
        {"id": "doc_30", "title": "Postmortem: INC-119 Notification Dispatcher Queue Congestion", "doc_type": "Postmortem", "summary": "Resolution of email dispatch delays during merchant monthly invoice cycle.", "content": "Tariq Mansoor and Oliver Hansen optimized parallel worker thread pools on Notification Dispatcher (sys_notifications), eliminating a 45-minute delivery backlog.", "author_id": "emp_tariq", "project_id": "proj_billing", "system_id": "sys_notifications", "created_at": "2026-08-02T10:00:00Z", "updated_at": "2026-08-02T16:00:00Z"}
    ]

    # 9. Incidents (20)
    incidents = [
        {"id": "inc_104", "title": "Payment Gateway Timeout & Settlement Spike", "severity": "P1", "status": "resolved", "root_cause": "Unindexed Redis transaction lock during bank partner failover caused connection pool exhaustion.", "summary": "Deployed Redis Sentinel failover script and increased worker concurrency pool from 50 to 200.", "system_id": "sys_payment", "project_id": "proj_payment", "resolver_id": "emp_maya", "document_id": "doc_02"},
        {"id": "inc_108", "title": "Core Database Lock Contention & Migration Freeze", "severity": "P1", "status": "resolved", "root_cause": "Exclusive table locks on customer orders table during ALTER TABLE schema migration froze transactional updates.", "summary": "Terminated blocking migration query; instituted mandatory 5s statement timeout. Directly delayed Project Atlas (DEC-202).", "system_id": "sys_core_db", "project_id": "proj_atlas", "resolver_id": "emp_carlos", "document_id": "doc_05"},
        {"id": "inc_102", "title": "Auth Gateway TLS Certificate Expiration", "severity": "P1", "status": "resolved", "root_cause": "Intermediate SSL certificate expired on primary auth ingress proxy.", "summary": "Rotated TLS secrets across cluster pods and updated automated Let's Encrypt renewal timers.", "system_id": "sys_auth", "project_id": "proj_cloud", "resolver_id": "emp_alex", "document_id": "doc_23"},
        {"id": "inc_105", "title": "Kafka Partition Lag Spike During Peak Billing Run", "severity": "P2", "status": "resolved", "root_cause": "Consumer group rebalance storm caused by slow invoice PDF rendering worker.", "summary": "Isolated PDF generation into dedicated asynchronous worker queue with separate partition assignment.", "system_id": "sys_event_bus", "project_id": "proj_payment", "resolver_id": "emp_tariq", "document_id": "doc_09"},
        {"id": "inc_107", "title": "Redis Cache Shard Eviction Storm", "severity": "P2", "status": "resolved", "root_cause": "Uncapped key allocation without expiration in customer session store.", "summary": "Configured 2-hour default TTL on session keys and scaled Redis shard memory allocation.", "system_id": "sys_cache", "project_id": "proj_payment", "resolver_id": "emp_kenji", "document_id": "doc_08"},
        {"id": "inc_109", "title": "Inventory Service gRPC Timeout on Flash Sale", "severity": "P2", "status": "resolved", "root_cause": "Database connection pool starvation during concurrent stock checks.", "summary": "Implemented circuit breaker pattern with cached read fallbacks during transient spikes.", "system_id": "sys_inventory", "project_id": "proj_inventory", "resolver_id": "emp_nina", "document_id": "doc_07"},
        {"id": "inc_114", "title": "Event Bus Broker Network Partition Across Availability Zones", "severity": "P1", "status": "resolved", "root_cause": "Inter-AZ packet loss caused ZooKeeper / KRaft leader election thrashing.", "summary": "Reset network routing table and adjusted election timeout thresholds to 10 seconds.", "system_id": "sys_event_bus", "project_id": "proj_payment", "resolver_id": "emp_dina", "document_id": "doc_22"},
        {"id": "inc_119", "title": "Notification Dispatcher Email Delivery Backlog", "severity": "P3", "status": "resolved", "root_cause": "Upstream SMTP rate limit reached during monthly customer invoice generation.", "summary": "Enabled multi-tenant SMTP pool and batch queuing algorithm to smooth egress spikes.", "system_id": "sys_notifications", "project_id": "proj_billing", "resolver_id": "emp_tariq", "document_id": "doc_30"},
        {"id": "inc_110", "title": "API Gateway Memory Leak in Lua Auth Filter", "severity": "P2", "status": "resolved", "root_cause": "Global variable table leak in custom Lua token verification hook.", "summary": "Rewrote token verification plugin in Rust Wasm filter with zero heap leakage.", "system_id": "sys_api_gateway", "project_id": "proj_portal", "resolver_id": "emp_victor", "document_id": "doc_16"},
        {"id": "inc_111", "title": "Billing Engine Proration Rounding Discrepancy", "severity": "P3", "status": "resolved", "root_cause": "Floating-point calculation during leap year month boundaries.", "summary": "Migrated billing calculation math to decimal arbitrary-precision integer micro-cents.", "system_id": "sys_billing_svc", "project_id": "proj_billing", "resolver_id": "emp_oliver", "document_id": "doc_24"},
        {"id": "inc_112", "title": "Core Database Connection Pooler Saturation", "severity": "P1", "status": "resolved", "root_cause": "PgBouncer max_client_conn exhausted during unindexed reporting batch query.", "summary": "Terminated runaway analytics query and enforced separate PgBouncer pools for OLTP and OLAP.", "system_id": "sys_core_db", "project_id": "proj_atlas", "resolver_id": "emp_ben", "document_id": "doc_27"},
        {"id": "inc_113", "title": "Shared Cache Cluster Master Node OOM Crash", "severity": "P1", "status": "resolved", "root_cause": "Large bulk key scan in debug script consumed all available node RAM.", "summary": "Promoted hot standby replica to master and disabled dangerous KEYS commands via ACL.", "system_id": "sys_cache", "project_id": "proj_inventory", "resolver_id": "emp_kenji", "document_id": "doc_08"},
        {"id": "inc_115", "title": "Edge API Gateway Wasm Crash on Malformed Headers", "severity": "P2", "status": "resolved", "root_cause": "Unchecked UTF-8 null byte in client User-Agent string panic in Wasm runtime.", "summary": "Added defensive byte sanitization pass prior to header parsing in Envoy proxy.", "system_id": "sys_api_gateway", "project_id": "proj_portal", "resolver_id": "emp_victor", "document_id": "doc_16"},
        {"id": "inc_116", "title": "Immutable Ledger Merkle Tree Verification Failure", "severity": "P1", "status": "resolved", "root_cause": "Clock drift between transaction sequencer nodes caused block timestamp mismatch.", "summary": "Synchronized all sequencer hosts with chrony PTP atomic clock master.", "system_id": "sys_ledger", "project_id": "proj_ledger", "resolver_id": "emp_samuel", "document_id": "doc_18"},
        {"id": "inc_117", "title": "Analytics Data Warehouse dbt Daily Build Timeout", "severity": "P3", "status": "resolved", "root_cause": "Unpartitioned staging table scanned 400M historical telemetry rows.", "summary": "Added daily date clustering keys to telemetry raw tables in ClickHouse.", "system_id": "sys_analytics_dw", "project_id": "proj_analytics", "resolver_id": "emp_jacob", "document_id": "doc_14"},
        {"id": "inc_118", "title": "Config Hub Dynamic Watch Channel Dropped", "severity": "P2", "status": "resolved", "root_cause": "etcd compact history wiped revision before slow client caught up.", "summary": "Increased auto-compaction retention window from 1000 to 50000 revisions.", "system_id": "sys_config", "project_id": "proj_cloud", "resolver_id": "emp_lucas", "document_id": "doc_25"},
        {"id": "inc_120", "title": "Telemetry Pipeline ClickHouse Disk Volume Near Capacity", "severity": "P2", "status": "resolved", "root_cause": "Debug level tracing left enabled in Payment Platform production containers.", "summary": "Reverted log level to INFO and purged uncompressed raw trace tables older than 7 days.", "system_id": "sys_metrics", "project_id": "proj_analytics", "resolver_id": "emp_david", "document_id": "doc_14"},
        {"id": "inc_121", "title": "Customer Portal Session Dropped on Edge Node Failover", "severity": "P3", "status": "resolved", "root_cause": "Stickiness table lost during ingress controller rolling restart.", "summary": "Switched session storage entirely to stateless signed JWT tokens per DEC-201.", "system_id": "sys_auth", "project_id": "proj_cloud", "resolver_id": "emp_alex", "document_id": "doc_03"},
        {"id": "inc_122", "title": "Payment Settlement Double Ingestion in Bank Batch", "severity": "P1", "status": "resolved", "root_cause": "Partner bank network retry resent previous transaction file without incrementing batch id.", "summary": "Enforced DEC-205 idempotency check on bank settlement batch level, rejecting duplicate transactions.", "system_id": "sys_payment", "project_id": "proj_payment", "resolver_id": "emp_piyush", "document_id": "doc_01"},
        {"id": "inc_123", "title": "Search Engine FalkorDB Graph Index Desynchronization", "severity": "P2", "status": "resolved", "root_cause": "Webhook retry worker failed to re-index renamed project buildings.", "summary": "Ran full entity reconciliation sweep and updated CDC event listener error handling.", "system_id": "sys_search", "project_id": "proj_ai_ops", "resolver_id": "emp_kevin", "document_id": "doc_12"}
    ]

    # 10. Tickets (40) - Label Ticket
    tickets = []
    ticket_defs = [
        ("TCK-1001", "Implement Idempotency Key header on payment checkout endpoint", "closed", "P1", "emp_piyush", "proj_payment", "inc_104", "sys_payment"),
        ("TCK-1002", "Investigate Core Database lock timeouts during table partition cutover", "closed", "P1", "emp_carlos", "proj_atlas", "inc_108", "sys_core_db"),
        ("TCK-1003", "Rotate Auth Gateway TLS certificates and update cert-manager", "closed", "P1", "emp_alex", "proj_cloud", "inc_102", "sys_auth"),
        ("TCK-1004", "Tune Kafka partition concurrency to resolve lag spikes in billing run", "closed", "P2", "emp_sophia", "proj_payment", "inc_105", "sys_event_bus"),
        ("TCK-1005", "Set 2-hour TTL on customer session keys in Shared Cache Cluster", "closed", "P2", "emp_kenji", "proj_payment", "inc_107", "sys_cache"),
        ("TCK-1006", "Add circuit breaker fallback to Inventory gRPC service client", "closed", "P2", "emp_nina", "proj_inventory", "inc_109", "sys_inventory"),
        ("TCK-1007", "Investigate inter-AZ latency spikes affecting Event Bus broker quorum", "closed", "P1", "emp_dina", "proj_payment", "inc_114", "sys_event_bus"),
        ("TCK-1008", "Optimize Notification Dispatcher SMTP egress queue batching", "closed", "P3", "emp_tariq", "proj_billing", "inc_119", "sys_notifications"),
        ("TCK-1009", "Rewrite Lua auth verification filter in Rust Wasm for Edge Gateway", "closed", "P2", "emp_victor", "proj_portal", "inc_110", "sys_api_gateway"),
        ("TCK-1010", "Fix decimal precision calculation bug in subscription proration engine", "closed", "P3", "emp_oliver", "proj_billing", "inc_111", "sys_billing_svc"),
        ("TCK-1011", "Isolate reporting analytical queries to dedicated read replicas", "closed", "P1", "emp_ben", "proj_atlas", "inc_112", "sys_core_db"),
        ("TCK-1012", "Disable KEYS command across all Redis cluster nodes in production", "closed", "P1", "emp_kenji", "proj_inventory", "inc_113", "sys_cache"),
        ("TCK-1013", "Sanitize non-standard UTF-8 characters in client user-agent headers", "closed", "P2", "emp_victor", "proj_portal", "inc_115", "sys_api_gateway"),
        ("TCK-1014", "Configure chrony PTP atomic clock synchronization on sequencers", "closed", "P1", "emp_samuel", "proj_ledger", "inc_116", "sys_ledger"),
        ("TCK-1015", "Add partition clustering keys to ClickHouse telemetry staging tables", "closed", "P3", "emp_jacob", "proj_analytics", "inc_117", "sys_analytics_dw"),
        ("TCK-1016", "Increase etcd compaction history window to prevent dropped watch channels", "closed", "P2", "emp_lucas", "proj_cloud", "inc_118", "sys_config"),
        ("TCK-1017", "Reduce log levels from DEBUG to INFO across Payment containers", "closed", "P2", "emp_david", "proj_analytics", "inc_120", "sys_metrics"),
        ("TCK-1018", "Enforce asymmetric JWT bearer tokens on all internal API calls", "closed", "P3", "emp_alex", "proj_cloud", "inc_121", "sys_auth"),
        ("TCK-1019", "Reject duplicate bank batch settlements using idempotency hash table", "closed", "P1", "emp_piyush", "proj_payment", "inc_122", "sys_payment"),
        ("TCK-1020", "Implement automatic re-indexing trigger for renamed building nodes", "closed", "P2", "emp_kevin", "proj_ai_ops", "inc_123", "sys_search"),
        ("TCK-1021", "Draft non-blocking partition cutover plan using pg_repack (DEC-206)", "closed", "P1", "emp_carlos", "proj_atlas", None, "sys_core_db"),
        ("TCK-1022", "Configure dual-key idempotency headers on payment settlement endpoints", "closed", "P1", "emp_maya", "proj_payment", None, "sys_payment"),
        ("TCK-1023", "Conduct end-to-end load testing on Edge API Gateway Wasm filters", "resolved", "P2", "emp_isabella", "proj_portal", None, "sys_api_gateway"),
        ("TCK-1024", "Audit cryptographic balance verification on Double-Entry Ledger", "resolved", "P1", "emp_samuel", "proj_ledger", None, "sys_ledger"),
        ("TCK-1025", "Create FalkorDB Cypher query benchmarks for organizational brain", "resolved", "P2", "emp_omar", "proj_ai_ops", None, "sys_search"),
        ("TCK-1026", "Build customer migration checklist for Project Atlas Beta launch", "in_progress", "P1", "emp_liam", "proj_atlas", None, "sys_core_db"),
        ("TCK-1027", "Design isometric WorkCity UI icons for new cloud systems", "in_progress", "P2", "emp_chloe", "proj_portal", None, "sys_search"),
        ("TCK-1028", "Integrate WebAuthn FIDO2 biometric authentication in checkout flow", "in_progress", "P1", "emp_ananya", "proj_checkout", None, "sys_payment"),
        ("TCK-1029", "Deploy multi-cluster Kubernetes Cilium service mesh in EU region", "in_progress", "P2", "emp_lucas", "proj_observability", None, "sys_config"),
        ("TCK-1030", "Implement ClickHouse telemetry retention policy on cold S3 storage", "in_progress", "P3", "emp_paula", "proj_analytics", None, "sys_metrics"),
        ("TCK-1031", "Validate Protobuf schema compatibility for Inventory gRPC v2", "in_progress", "P2", "emp_nina", "proj_inventory", None, "sys_inventory"),
        ("TCK-1032", "Tune Redis connection pool limits for One-Click Checkout microservice", "in_progress", "P2", "emp_kenji", "proj_checkout", None, "sys_cache"),
        ("TCK-1033", "Conduct automated chaos engineering drills on Event Bus brokers", "open", "P1", "emp_dina", "proj_payment", None, "sys_event_bus"),
        ("TCK-1034", "Design mobile UI navigation for Executive WorkCity application", "open", "P3", "emp_grace", "proj_mobile", None, "sys_search"),
        ("TCK-1035", "Document OAuth2 OIDC token renewal refresh flows for third-party SDKs", "open", "P2", "emp_fiona", "proj_cloud", None, "sys_auth"),
        ("TCK-1036", "Benchmark LLM Cypher generation latency against local model endpoints", "open", "P2", "emp_quinn", "proj_ai_ops", None, "sys_search"),
        ("TCK-1037", "Configure multi-region PostgreSQL read replica in Singapore datacenter", "open", "P1", "emp_mikhail", "proj_atlas", None, "sys_core_db"),
        ("TCK-1038", "Create merchant settlement reconciliation telemetry dashboard", "open", "P3", "emp_nadia", "proj_billing", None, "sys_billing_svc"),
        ("TCK-1039", "Review customer escalation audit logs for failed webhook callbacks", "open", "P2", "emp_ramon", "proj_portal", None, "sys_notifications"),
        ("TCK-1040", "Automate weekly dependency vulnerability scanning in CI/CD pipeline", "open", "P1", "emp_samuel", "proj_observability", None, "sys_auth")
    ]

    for t_id, title, status, priority, assignee, proj, inc, sys_item in ticket_defs:
        tickets.append({
            "id": t_id,
            "title": title,
            "status": status,
            "priority": priority,
            "project_id": proj,
            "assignee_id": assignee,
            "incident_id": inc,
            "system_id": sys_item
        })

    # 11. ChatThreads (25) - Label ChatThread
    chat_threads = []
    chat_defs = [
        ("chat_01", "#payments-eng", ["emp_piyush", "emp_maya", "emp_ananya"], ["sys_payment", "inc_104"], ["Maya: Seeing elevated p99 latency on the settlement endpoint.", "Piyush: Investigating now. Looks like a Redis lock contention.", "Maya: Failover script deployed. nominal latency restored.", "Ananya: Verified all retry queues are draining."]),
        ("chat_02", "#atlas-launch", ["emp_liam", "emp_carlos", "emp_marcus"], ["proj_atlas", "sys_core_db", "dec_202"], ["Liam: Are we good for the Beta launch date?", "Carlos: Blocked. Schema ALTER acquired an exclusive table lock during order table migration.", "Marcus: We cannot risk customer outages. Delay the milestone.", "Liam: Logging DEC-202 to shift Beta by 6 weeks."]),
        ("chat_03", "#atlas-launch", ["emp_carlos", "emp_liam", "emp_ben"], ["proj_atlas", "sys_core_db", "dec_206"], ["Carlos: We tested pg_repack in staging with 5s statement timeouts. Zero locks.", "Liam: Excellent news. Let's draft DEC-206 to resume rollout.", "Ben: Replica synchronization confirmed healthy. Ready for weekend maintenance window."]),
        ("chat_04", "#auth-gateway", ["emp_alex", "emp_victor", "emp_marcus"], ["sys_auth", "dec_201", "dec_190"], ["Alex: Cookie sessions (DEC-190) are blocking multi-domain SSO for Nova Cloud Console.", "Marcus: Agreed. We need to standardize on OAuth2 and OIDC.", "Victor: Envoy Wasm auth filter is passing integration tests with RS256 JWTs.", "Alex: Publishing DEC-201 and updating RFC."]),
        ("chat_05", "#core-db-oncall", ["emp_carlos", "emp_ben", "emp_dina"], ["sys_core_db", "inc_108"], ["Carlos: Alert: Core Database lock contention spike on order table.", "Dina: Escalating to P1 war room.", "Carlos: Terminated blocking query. Active transactions responding again.", "Ben: Postmortem DOC-05 published."]),
        ("chat_06", "#infra-oncall", ["emp_kenji", "emp_tariq", "emp_dina"], ["sys_cache", "inc_107"], ["Kenji: Redis Shared Cache Cluster memory utilization at 96%.", "Dina: Cache eviction storm occurring.", "Kenji: Found un-expiring session keys. Set 2h TTL and expanded memory limits.", "Tariq: Cache hit ratio back to 99.2%."]),
        ("chat_07", "#event-bus-scaling", ["emp_sophia", "emp_tariq", "emp_dina"], ["sys_event_bus", "inc_114"], ["Sophia: AWS AZ packet loss caused Kafka broker partition split.", "Dina: Incident INC-114 opened. Enforcing minimum in-sync replicas.", "Tariq: KRaft leader re-elected. Zero message data loss."]),
        ("chat_08", "#aiops-research", ["emp_priya", "emp_omar", "emp_quinn"], ["proj_ai_ops", "sys_search", "dec_203"], ["Priya: Graph embeddings on FalkorDB are identifying incident blast radius in under 5ms.", "Omar: Cypher shortest-path traversals outperforming vector-only retrieval for causality.", "Quinn: FalkorDB selection (DEC-203) continues to prove optimal for our AI agent architecture."]),
        ("chat_09", "#security-ops", ["emp_alex", "emp_samuel", "emp_victor"], ["sys_auth", "dec_212"], ["Samuel: Mandatory zero-trust mTLS rollout is complete for 85% of cluster pods.", "Alex: Vault SPIRE certificate issuing latency is averaging 12ms.", "Victor: Enforcing dropped connections for non-mTLS traffic next Monday."]),
        ("chat_10", "#ledger-architecture", ["emp_samuel", "emp_piyush", "emp_marcus"], ["sys_ledger", "dec_211"], ["Marcus: Did the third-party audit of the Rust ledger pass?", "Samuel: Yes! SHA-256 Merkle chain verification passed with zero vulnerabilities.", "Piyush: Payment Platform double-entry reconciliation is plugging into it directly."]),
        ("chat_11", "#billing-ops", ["emp_rachel", "emp_oliver", "emp_nadia"], ["sys_billing_svc", "inc_111"], ["Rachel: Reviewing monthly invoice generation run.", "Oliver: Fixed the rounding precision bug on micro-cent prorations (INC-111).", "Nadia: Dashboard confirms all 45,000 enterprise invoices matched accurately."]),
        ("chat_12", "#api-edge", ["emp_victor", "emp_alex", "emp_isabella"], ["sys_api_gateway", "dec_209"], ["Victor: Envoy Edge Gateway rate-limiting plugin deployed to production.", "Isabella: Automated E2E load test handled 50,000 req/sec with zero dropped frames.", "Alex: Zero-trust token validation overhead is under 1.2ms."]),
        ("chat_13", "#telemetry-lake", ["emp_david", "emp_jacob", "emp_paula"], ["sys_metrics", "dec_207"], ["David: ClickHouse cluster ingestion rate hit 450,000 events/sec.", "Paula: Cloud infrastructure bill dropped by $14,000 this month thanks to DEC-207.", "Jacob: Daily dbt rollups are finishing in 6 minutes instead of 45."]),
        ("chat_14", "#inventory-sync", ["emp_nina", "emp_kenji", "emp_piyush"], ["sys_inventory", "inc_109"], ["Nina: gRPC catalog synchronization tuned for the upcoming flash sale.", "Kenji: Shared Cache Cluster pre-warming script tested.", "Piyush: Settlement hooks are maintaining idempotent stock reservations."]),
        ("chat_15", "#checkout-v3", ["emp_rachel", "emp_ananya", "emp_chloe"], ["proj_checkout", "dec_213"], ["Rachel: PRD for One-Click Checkout V3 is approved.", "Chloe: User experience prototypes show biometric WebAuthn prompt feels instantaneous.", "Ananya: Integrating bank tokenization adapter with Payment Platform."]),
        ("chat_16", "#dev-portal", ["emp_arjun", "emp_fiona", "emp_grace"], ["proj_portal", "sys_search"], ["Fiona: New developer SDK documentation is ready for publishing.", "Arjun: Interactive API testing sandbox is connected to the staging gateway.", "Grace: Design system tokens updated for dark-mode contrast compliance."]),
        ("chat_17", "#incident-review", ["emp_dina", "emp_maya", "emp_carlos"], ["inc_104", "inc_108", "dec_214"], ["Dina: Conducting quarterly review of P1 incident timelines.", "Maya: INC-104 highlighted need for automatic Sentinel failovers.", "Carlos: INC-108 established strict statement timeouts before schema alterations."]),
        ("chat_18", "#db-replication", ["emp_carlos", "emp_ben", "emp_mikhail"], ["sys_core_db", "dec_210"], ["Carlos: pglogical replication to Frankfurt read-replica is active.", "Mikhail: Measured cross-region query latency at 8.4ms.", "Ben: Singapore replication node scheduled for provisioning next sprint."]),
        ("chat_19", "#developer-tools", ["emp_zoe", "emp_arjun", "emp_kevin"], ["sys_search", "proj_portal"], ["Zoe: Internal query explorer now supports direct FalkorDB graph visualization.", "Kevin: Added fuzzy search indexing over all RFC and ADR documents.", "Arjun: Frontend rendering optimized with zero layout jitter."]),
        ("chat_20", "#observability", ["emp_sophia", "emp_david", "emp_lucas"], ["proj_observability", "sys_metrics"], ["Lucas: OpenTelemetry collector daemonsets deployed to all production Kubernetes nodes.", "Sophia: Kafka trace pipeline processing 100% of distributed trace spans.", "David: Dashboards updated with p95 and p99 service-level indicators."]),
        ("chat_21", "#config-hub", ["emp_lucas", "emp_elena", "emp_victor"], ["sys_config", "proj_cloud"], ["Lucas: etcd watch channel compaction tuned (INC-118).", "Elena: Can we safely toggle feature flags during live deployments?", "Lucas: Yes, sub-200ms propagation confirmed across all active pods."]),
        ("chat_22", "#exec-brain", ["emp_marcus", "emp_elena", "emp_emily"], ["proj_mobile", "proj_ai_ops"], ["Marcus: Executive mobile brain concept allows instant querying of company dependencies.", "Emily: Product managers want access to live project delay rationales directly from FalkorDB.", "Elena: Ensures full transparency across architectural decisions."]),
        ("chat_23", "#search-engine", ["emp_kevin", "emp_omar", "emp_priya"], ["sys_search", "inc_123"], ["Kevin: Re-indexing webhook pipeline patched for entity renames.", "Omar: Graph neighborhood expansion algorithm verified.", "Priya: Top-k ranking queries returning within 4ms on FalkorDB."]),
        ("chat_24", "#chaos-testing", ["emp_kenji", "emp_dina", "emp_lucas"], ["sys_cache", "sys_payment"], ["Kenji: Simulating random Redis node terminations in staging.", "Dina: Connection pooling held up without dropping transactional requests.", "Lucas: Automated Kubernetes pod restarts triggered seamlessly."]),
        ("chat_25", "#pci-compliance", ["emp_maya", "emp_alex", "emp_samuel"], ["sys_payment", "sys_auth"], ["Alex: Quarterly PCI-DSS penetration test results came back clean.", "Maya: Credit card numbers never touch internal databases; tokenized at gateway edge.", "Samuel: KMS envelope encryption verified across all settlement archives."])
    ]

    for idx, (c_id, channel, participants, mentions, msgs) in enumerate(chat_defs):
        chat_threads.append({
            "id": c_id,
            "channel": channel,
            "participants": participants,
            "mentions": mentions,
            "messages": msgs
        })

    # 12. Relationships (~450)
    relationships = []

    def add_rel(from_id: str, rel_type: str, to_id: str):
        relationships.append({"from": from_id, "type": rel_type, "to": to_id})

    # A. Employee BELONGS_TO Department
    for emp in employees:
        add_rel(emp["id"], "BELONGS_TO", emp["department_id"])

    # B. Project BELONGS_TO Department
    for proj in projects:
        add_rel(proj["id"], "BELONGS_TO", proj["department_id"])

    # C. REPORTS_TO tree (3 levels)
    # Level 1: Marcus (CTO), Elena (VP Eng), Emily (VP Prod)
    add_rel("emp_elena", "REPORTS_TO", "emp_marcus")
    add_rel("emp_emily", "REPORTS_TO", "emp_marcus")
    add_rel("emp_carlos", "REPORTS_TO", "emp_marcus")  # Staff Infra Lead
    add_rel("emp_priya", "REPORTS_TO", "emp_marcus")   # Lead Data Scientist

    # Level 2 managers reporting to Elena / Carlos / Emily / Priya
    # Engineering leads -> Elena
    add_rel("emp_maya", "REPORTS_TO", "emp_elena")
    add_rel("emp_sarah", "REPORTS_TO", "emp_elena")
    add_rel("emp_piyush", "REPORTS_TO", "emp_maya")
    add_rel("emp_nina", "REPORTS_TO", "emp_maya")
    add_rel("emp_arjun", "REPORTS_TO", "emp_sarah")
    add_rel("emp_zoe", "REPORTS_TO", "emp_sarah")
    add_rel("emp_victor", "REPORTS_TO", "emp_sarah")
    add_rel("emp_ananya", "REPORTS_TO", "emp_piyush")
    add_rel("emp_ben", "REPORTS_TO", "emp_carlos")
    add_rel("emp_isabella", "REPORTS_TO", "emp_sarah")
    add_rel("emp_kevin", "REPORTS_TO", "emp_maya")
    add_rel("emp_grace", "REPORTS_TO", "emp_arjun")
    add_rel("emp_nadia", "REPORTS_TO", "emp_arjun")
    add_rel("emp_oliver", "REPORTS_TO", "emp_piyush")

    # Operations -> Carlos & Dina
    add_rel("emp_dina", "REPORTS_TO", "emp_marcus")
    add_rel("emp_alex", "REPORTS_TO", "emp_carlos")
    add_rel("emp_sophia", "REPORTS_TO", "emp_carlos")
    add_rel("emp_kenji", "REPORTS_TO", "emp_carlos")
    add_rel("emp_tariq", "REPORTS_TO", "emp_dina")
    add_rel("emp_lucas", "REPORTS_TO", "emp_carlos")
    add_rel("emp_samuel", "REPORTS_TO", "emp_alex")
    add_rel("emp_mikhail", "REPORTS_TO", "emp_carlos")
    add_rel("emp_paula", "REPORTS_TO", "emp_dina")
    add_rel("emp_ramon", "REPORTS_TO", "emp_dina")

    # Product -> Emily
    add_rel("emp_liam", "REPORTS_TO", "emp_emily")
    add_rel("emp_rachel", "REPORTS_TO", "emp_emily")
    add_rel("emp_chloe", "REPORTS_TO", "emp_emily")
    add_rel("emp_fiona", "REPORTS_TO", "emp_emily")
    add_rel("emp_hassan", "REPORTS_TO", "emp_liam")
    add_rel("emp_laura", "REPORTS_TO", "emp_rachel")

    # Research -> Priya
    add_rel("emp_david", "REPORTS_TO", "emp_priya")
    add_rel("emp_omar", "REPORTS_TO", "emp_priya")
    add_rel("emp_leila", "REPORTS_TO", "emp_priya")
    add_rel("emp_jacob", "REPORTS_TO", "emp_david")
    add_rel("emp_quinn", "REPORTS_TO", "emp_priya")

    # D. WORKED_ON: Employee -> Project
    worked_on_map = [
        ("emp_maya", "proj_payment"), ("emp_piyush", "proj_payment"), ("emp_rachel", "proj_payment"), ("emp_sophia", "proj_payment"), ("emp_ananya", "proj_payment"),
        ("emp_liam", "proj_atlas"), ("emp_marcus", "proj_atlas"), ("emp_carlos", "proj_atlas"), ("emp_zoe", "proj_atlas"), ("emp_ben", "proj_atlas"),
        ("emp_arjun", "proj_cloud"), ("emp_chloe", "proj_cloud"), ("emp_alex", "proj_cloud"), ("emp_lucas", "proj_cloud"), ("emp_fiona", "proj_cloud"),
        ("emp_nina", "proj_inventory"), ("emp_kenji", "proj_inventory"), ("emp_samuel", "proj_inventory"),
        ("emp_priya", "proj_ai_ops"), ("emp_david", "proj_ai_ops"), ("emp_omar", "proj_ai_ops"), ("emp_quinn", "proj_ai_ops"),
        ("emp_arjun", "proj_portal"), ("emp_chloe", "proj_portal"), ("emp_rachel", "proj_portal"), ("emp_victor", "proj_portal"), ("emp_grace", "proj_portal"),
        ("emp_samuel", "proj_ledger"), ("emp_piyush", "proj_ledger"), ("emp_maya", "proj_ledger"), ("emp_ananya", "proj_ledger"),
        ("emp_david", "proj_analytics"), ("emp_jacob", "proj_analytics"), ("emp_paula", "proj_analytics"), ("emp_leila", "proj_analytics"),
        ("emp_rachel", "proj_checkout"), ("emp_ananya", "proj_checkout"), ("emp_chloe", "proj_checkout"), ("emp_kenji", "proj_checkout"),
        ("emp_lucas", "proj_observability"), ("emp_dina", "proj_observability"), ("emp_tariq", "proj_observability"), ("emp_alex", "proj_observability"),
        ("emp_oliver", "proj_billing"), ("emp_rachel", "proj_billing"), ("emp_nadia", "proj_billing"),
        ("emp_marcus", "proj_mobile"), ("emp_elena", "proj_mobile"), ("emp_grace", "proj_mobile"), ("emp_emily", "proj_mobile")
    ]
    for e_id, p_id in worked_on_map:
        add_rel(e_id, "WORKED_ON", p_id)

    # E. OWNS: Employee -> System
    owns_map = [
        ("emp_piyush", "sys_payment"),
        ("emp_alex", "sys_auth"),
        ("emp_carlos", "sys_core_db"),
        ("emp_sophia", "sys_event_bus"),
        ("emp_nina", "sys_inventory"),
        ("emp_david", "sys_metrics"),
        ("emp_kenji", "sys_cache"),
        ("emp_tariq", "sys_notifications"),
        ("emp_victor", "sys_api_gateway"),
        ("emp_oliver", "sys_billing_svc"),
        ("emp_samuel", "sys_ledger"),
        ("emp_jacob", "sys_analytics_dw"),
        ("emp_kevin", "sys_search"),
        ("emp_lucas", "sys_config")
    ]
    for e_id, s_id in owns_map:
        add_rel(e_id, "OWNS", s_id)

    # F. USES: Project -> System
    uses_map = [
        ("proj_payment", "sys_payment"), ("proj_payment", "sys_auth"), ("proj_payment", "sys_event_bus"), ("proj_payment", "sys_cache"), ("proj_payment", "sys_core_db"),
        ("proj_atlas", "sys_core_db"), ("proj_atlas", "sys_auth"), ("proj_atlas", "sys_config"),
        ("proj_cloud", "sys_auth"), ("proj_cloud", "sys_metrics"), ("proj_cloud", "sys_config"),
        ("proj_inventory", "sys_inventory"), ("proj_inventory", "sys_cache"), ("proj_inventory", "sys_event_bus"),
        ("proj_ai_ops", "sys_metrics"), ("proj_ai_ops", "sys_event_bus"), ("proj_ai_ops", "sys_search"),
        ("proj_portal", "sys_payment"), ("proj_portal", "sys_auth"), ("proj_portal", "sys_notifications"), ("proj_portal", "sys_api_gateway"),
        ("proj_ledger", "sys_ledger"), ("proj_ledger", "sys_payment"), ("proj_ledger", "sys_event_bus"),
        ("proj_analytics", "sys_analytics_dw"), ("proj_analytics", "sys_metrics"), ("proj_analytics", "sys_event_bus"),
        ("proj_checkout", "sys_payment"), ("proj_checkout", "sys_auth"), ("proj_checkout", "sys_cache"),
        ("proj_observability", "sys_metrics"), ("proj_observability", "sys_event_bus"), ("proj_observability", "sys_config"),
        ("proj_billing", "sys_billing_svc"), ("proj_billing", "sys_payment"), ("proj_billing", "sys_notifications"), ("proj_billing", "sys_ledger"),
        ("proj_mobile", "sys_api_gateway"), ("proj_mobile", "sys_auth"), ("proj_mobile", "sys_search")
    ]
    for p_id, s_id in uses_map:
        add_rel(p_id, "USES", s_id)

    # G. DEPENDS_ON: System -> System & Project -> System / Project
    depends_on_map = [
        ("proj_atlas", "sys_core_db"),
        ("proj_portal", "proj_payment"),
        ("proj_checkout", "proj_payment"),
        ("proj_billing", "proj_payment"),
        ("sys_payment", "sys_auth"),
        ("sys_payment", "sys_core_db"),
        ("sys_payment", "sys_event_bus"),
        ("sys_payment", "sys_cache"),
        ("sys_inventory", "sys_cache"),
        ("sys_inventory", "sys_event_bus"),
        ("sys_billing_svc", "sys_payment"),
        ("sys_billing_svc", "sys_ledger"),
        ("sys_ledger", "sys_core_db"),
        ("sys_api_gateway", "sys_auth"),
        ("sys_metrics", "sys_event_bus"),
        ("sys_analytics_dw", "sys_event_bus"),
        ("sys_search", "sys_event_bus")
    ]
    for src, dst in depends_on_map:
        add_rel(src, "DEPENDS_ON", dst)

    # H. Incidents: AFFECTED, RESOLVED_BY, DOCUMENTED_IN
    for inc in incidents:
        if inc.get("system_id"):
            add_rel(inc["id"], "AFFECTED", inc["system_id"])
        if inc.get("project_id"):
            add_rel(inc["id"], "AFFECTED", inc["project_id"])
        if inc.get("resolver_id"):
            add_rel(inc["id"], "RESOLVED_BY", inc["resolver_id"])
        if inc.get("document_id"):
            add_rel(inc["id"], "DOCUMENTED_IN", inc["document_id"])

    # I. Decisions: MADE, DOCUMENTED_IN, SUPERSEDES
    for dec in decisions:
        if dec.get("maker_id"):
            add_rel(dec["id"], "MADE", dec["maker_id"])
        if dec.get("document_id"):
            add_rel(dec["id"], "DOCUMENTED_IN", dec["document_id"])

    # SUPERSEDES relationships
    add_rel("dec_206", "SUPERSEDES", "dec_202")
    add_rel("dec_201", "SUPERSEDES", "dec_190")

    # J. Documents: AUTHORED
    for doc in documents:
        if doc.get("author_id"):
            add_rel(doc["author_id"], "AUTHORED", doc["id"])

    # K. Employee HAS_SKILL
    skill_assignments = [
        ("emp_maya", ["skill_dist_sys", "skill_payment", "skill_sys_arch"]),
        ("emp_piyush", ["skill_dist_sys", "skill_payment", "skill_redis"]),
        ("emp_carlos", ["skill_k8s", "skill_cloud_infra", "skill_dist_sys"]),
        ("emp_priya", ["skill_ml", "skill_graph_db", "skill_data_pipeline"]),
        ("emp_alex", ["skill_oauth", "skill_security"]),
        ("emp_sophia", ["skill_cicd", "skill_cloud_infra"]),
        ("emp_arjun", ["skill_react", "skill_graphql"]),
        ("emp_marcus", ["skill_sys_arch", "skill_graph_db", "skill_dist_sys"]),
        ("emp_nina", ["skill_dist_sys", "skill_python"]),
        ("emp_kenji", ["skill_redis", "skill_cloud_infra"]),
        ("emp_chloe", ["skill_react", "skill_product_strategy"]),
        ("emp_rachel", ["skill_payment", "skill_product_strategy"]),
        ("emp_david", ["skill_data_pipeline", "skill_cloud_infra"]),
        ("emp_tariq", ["skill_cloud_infra", "skill_cicd"]),
        ("emp_emily", ["skill_product_strategy", "skill_sys_arch"]),
        ("emp_omar", ["skill_ml", "skill_graph_db"]),
        ("emp_zoe", ["skill_react", "skill_python"]),
        ("emp_sarah", ["skill_sys_arch", "skill_dist_sys"]),
        ("emp_lucas", ["skill_k8s", "skill_cloud_infra"]),
        ("emp_dina", ["skill_cloud_infra", "skill_dist_sys"]),
        ("emp_ananya", ["skill_payment", "skill_python"]),
        ("emp_ben", ["skill_dist_sys", "skill_cloud_infra"]),
        ("emp_fiona", ["skill_product_strategy", "skill_graphql"]),
        ("emp_samuel", ["skill_security", "skill_oauth"]),
        ("emp_leila", ["skill_ml", "skill_data_pipeline"]),
        ("emp_victor", ["skill_security", "skill_dist_sys"]),
        ("emp_grace", ["skill_react", "skill_graphql"]),
        ("emp_hassan", ["skill_product_strategy", "skill_cicd"]),
        ("emp_isabella", ["skill_dist_sys", "skill_cicd"]),
        ("emp_jacob", ["skill_data_pipeline", "skill_cloud_infra"]),
        ("emp_kevin", ["skill_graph_db", "skill_python"]),
        ("emp_laura", ["skill_product_strategy"]),
        ("emp_mikhail", ["skill_cloud_infra", "skill_k8s"]),
        ("emp_nadia", ["skill_react", "skill_graphql"]),
        ("emp_oliver", ["skill_payment", "skill_python"]),
        ("emp_paula", ["skill_cloud_infra", "skill_data_pipeline"]),
        ("emp_quinn", ["skill_ml", "skill_graph_db", "skill_python"]),
        ("emp_ramon", ["skill_cloud_infra", "skill_dist_sys"])
    ]
    for e_id, sk_list in skill_assignments:
        for sk_id in sk_list:
            add_rel(e_id, "HAS_SKILL", sk_id)

    # L. COLLABORATES_WITH
    collabs = [
        ("emp_maya", "emp_piyush"), ("emp_maya", "emp_rachel"), ("emp_maya", "emp_carlos"),
        ("emp_liam", "emp_carlos"), ("emp_liam", "emp_marcus"), ("emp_liam", "emp_ben"),
        ("emp_arjun", "emp_chloe"), ("emp_arjun", "emp_grace"), ("emp_arjun", "emp_nadia"),
        ("emp_priya", "emp_david"), ("emp_priya", "emp_omar"), ("emp_priya", "emp_quinn"),
        ("emp_alex", "emp_victor"), ("emp_alex", "emp_samuel"),
        ("emp_sophia", "emp_tariq"), ("emp_sophia", "emp_dina"),
        ("emp_nina", "emp_kenji"), ("emp_nina", "emp_ananya"),
        ("emp_rachel", "emp_oliver"), ("emp_rachel", "emp_ananya")
    ]
    for a, b in collabs:
        add_rel(a, "COLLABORATES_WITH", b)
        add_rel(b, "COLLABORATES_WITH", a)

    # M. Tickets: ASSIGNED_TO, BELONGS_TO_PROJECT, RELATES_TO
    for tck in tickets:
        add_rel(tck["id"], "ASSIGNED_TO", tck["assignee_id"])
        add_rel(tck["id"], "BELONGS_TO_PROJECT", tck["project_id"])
        if tck.get("incident_id"):
            add_rel(tck["id"], "RELATES_TO", tck["incident_id"])
        if tck.get("system_id"):
            add_rel(tck["id"], "RELATES_TO", tck["system_id"])

    # N. ChatThreads: PARTICIPATED_IN, MENTIONS
    for chat in chat_threads:
        for p_id in chat["participants"]:
            add_rel(p_id, "PARTICIPATED_IN", chat["id"])
        for m_id in chat["mentions"]:
            add_rel(chat["id"], "MENTIONS", m_id)

    # 13. Validation Step: zero dangling references, zero duplicate IDs
    all_entity_ids: Set[str] = set()
    id_categories = [
        ("departments", departments),
        ("skills", skills),
        ("employees", employees),
        ("systems", systems),
        ("projects", projects),
        ("decisions", decisions),
        ("documents", documents),
        ("incidents", incidents),
        ("tickets", tickets),
        ("chat_threads", chat_threads)
    ]

    for cat_name, items in id_categories:
        for it in items:
            it_id = it["id"]
            if it_id in all_entity_ids:
                raise ValueError(f"Duplicate entity ID detected: {it_id} in {cat_name}")
            all_entity_ids.add(it_id)

    # Verify relationships
    seen_rel_keys = set()
    unique_rels = []
    for rel in relationships:
        src = rel["from"]
        dst = rel["to"]
        rtype = rel["type"]
        if src not in all_entity_ids:
            raise ValueError(f"Dangling reference 'from': {src} in relationship {rel}")
        if dst not in all_entity_ids:
            raise ValueError(f"Dangling reference 'to': {dst} in relationship {rel}")
        rel_key = (src, rtype, dst)
        if rel_key not in seen_rel_keys:
            seen_rel_keys.add(rel_key)
            unique_rels.append(rel)

    payload = {
        "company": company,
        "departments": departments,
        "skills": skills,
        "employees": employees,
        "systems": systems,
        "projects": projects,
        "decisions": decisions,
        "documents": documents,
        "incidents": incidents,
        "tickets": tickets,
        "chat_threads": chat_threads,
        "relationships": unique_rels
    }

    return payload

def write_seed_data(output_path: str = "data/seed_data.json"):
    data = build_seed_data()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"Successfully generated {output_path}:")
    print(f"  - Departments: {len(data['departments'])}")
    print(f"  - Employees: {len(data['employees'])}")
    print(f"  - Skills: {len(data['skills'])}")
    print(f"  - Projects: {len(data['projects'])}")
    print(f"  - Systems: {len(data['systems'])}")
    print(f"  - Decisions: {len(data['decisions'])}")
    print(f"  - Documents: {len(data['documents'])}")
    print(f"  - Incidents: {len(data['incidents'])}")
    print(f"  - Tickets: {len(data['tickets'])}")
    print(f"  - ChatThreads: {len(data['chat_threads'])}")
    print(f"  - Relationships: {len(data['relationships'])}")

if __name__ == "__main__":
    write_seed_data()
