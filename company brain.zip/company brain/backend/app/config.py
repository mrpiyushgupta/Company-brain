import os
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseModel):
    FALKORDB_HOST: str = os.getenv("FALKORDB_HOST", "127.0.0.1")
    FALKORDB_PORT: int = int(os.getenv("FALKORDB_PORT", "6379"))
    FALKORDB_PASSWORD: str | None = os.getenv("FALKORDB_PASSWORD", None)
    GRAPH_NAME: str = os.getenv("GRAPH_NAME", "workcity_novaworks")
    
    # LLM Settings (Optional helper)
    LLM_BASE_URL: str | None = os.getenv("LLM_BASE_URL", None)
    LLM_MODEL: str | None = os.getenv("LLM_MODEL", None)
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "local")
    
    # Data directory
    BASE_DIR: str = next(
        (c for c in (
            os.getenv("BASE_DIR", ""),
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),                    # /app in Docker
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),   # repo root locally
        ) if c and os.path.exists(os.path.join(c, "data", "seed_data.json"))),
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    )
    DATA_FILE: str = os.path.join(BASE_DIR, "data", "seed_data.json")

settings = Settings()
