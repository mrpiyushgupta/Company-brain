"""
Stand-alone seeding script for WorkCity.
Usage: python -m app.seed
"""

import sys
import logging
from app.services.graph_service import graph_service
from app.graph.falkor_client import falkor_client
from app.config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

def main():
    logger.info("Starting NovaWorks graph seeding...")
    res = graph_service.seed_data(force=True)
    logger.info(f"Seeding completed: {res['message']}")
    
    # Print node counts per label
    logger.info("=== Node Counts per Label ===")
    labels = ["Department", "Skill", "Employee", "Project", "System", "Task", "Document", "Decision", "Incident", "Ticket", "ChatThread", "Session"]
    for label in labels:
        try:
            r = falkor_client.query(f"MATCH (n:{label}) RETURN count(n)")
            cnt = r.result_set[0][0] if r.result_set else 0
            logger.info(f"  {label:15}: {cnt}")
        except Exception as e:
            logger.warning(f"  {label:15}: Error {e}")

    # Print total edge count
    try:
        r_edges = falkor_client.query("MATCH ()-[r]->() RETURN count(r)")
        total_edges = r_edges.result_set[0][0] if r_edges.result_set else 0
        logger.info(f"=== Total Relationships: {total_edges} ===")
    except Exception as e:
        logger.warning(f"Error counting relationships: {e}")

if __name__ == "__main__":
    main()
