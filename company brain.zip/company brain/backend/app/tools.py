"""
Graph tools for WorkCity AI Assistant.
Every tool executes parameterized Cypher queries on FalkorDB and returns:
{"rows": [...], "cypher": "<query used>", "args": {...}}
"""

import re
import json
import logging
from typing import Dict, Any, List, Optional
from app.graph.falkor_client import falkor_client
from app.config import settings

logger = logging.getLogger(__name__)

WHITELISTED_LABELS = {
    "Employee", "Department", "Project", "System", "Document",
    "Decision", "Incident", "Skill", "Ticket", "ChatThread"
}

WHITELISTED_REL_TYPES = {
    "BELONGS_TO", "REPORTS_TO", "WORKED_ON", "OWNS", "HAS_SKILL",
    "USES", "DEPENDS_ON", "AFFECTED", "RESOLVED_BY", "DOCUMENTED_IN",
    "AUTHORED", "MADE", "COLLABORATES_WITH", "ASSIGNED_TO",
    "BELONGS_TO_PROJECT", "RELATES_TO", "PARTICIPATED_IN", "MENTIONS",
    "SUPERSEDES"
}

def find_entity(text: str) -> Dict[str, Any]:
    """Match entities by id, name or title across all labels (case-insensitive CONTAINS). Returns top 5."""
    cypher = """
        MATCH (n)
        WHERE (n.id IS NOT NULL AND toLower(n.id) CONTAINS toLower($text))
           OR (n.name IS NOT NULL AND toLower(n.name) CONTAINS toLower($text))
           OR (n.title IS NOT NULL AND toLower(n.title) CONTAINS toLower($text))
        RETURN labels(n)[0] AS label, n.id AS id, coalesce(n.name, n.title, n.id) AS name, properties(n) AS properties
        LIMIT 5
    """
    args = {"text": text.strip()}
    res = falkor_client.query(cypher, args)
    rows = []
    if res.result_set:
        for r in res.result_set:
            rows.append({
                "label": r[0] if r[0] else "Entity",
                "id": r[1],
                "name": r[2],
                "properties": r[3] if len(r) > 3 and isinstance(r[3], dict) else {}
            })
    return {"rows": rows, "cypher": cypher.strip(), "args": args}

def neighbors(id: str, hops: int = 1) -> Dict[str, Any]:
    """Retrieve 1-hop connected neighbors for entity id."""
    cypher = """
        MATCH (c {id: $id})-[r]-(n)
        RETURN c.id AS center_id, type(r) AS rel_type, labels(n)[0] AS n_label, n.id AS n_id, coalesce(n.name, n.title, n.id) AS n_name
        LIMIT 25
    """
    args = {"id": id.strip()}
    res = falkor_client.query(cypher, args)
    rows = []
    if res.result_set:
        for r in res.result_set:
            rows.append({
                "center_id": r[0],
                "rel_type": r[1],
                "target_label": r[2] if r[2] else "Entity",
                "target_id": r[3],
                "target_name": r[4]
            })
    return {"rows": rows, "cypher": cypher.strip(), "args": args}

def shortest_path(a: str, b: str, max_hops: int = 5) -> Dict[str, Any]:
    """Find shortest path between two entities using FalkorDB shortestPath."""
    safe_hops = max(1, min(6, int(max_hops)))
    # Resolve source and target if provided as names
    cypher = f"""
        MATCH (s), (t)
        WHERE (s.id = $a OR toLower(s.name) CONTAINS toLower($a) OR toLower(s.id) CONTAINS toLower($a))
          AND (t.id = $b OR toLower(t.name) CONTAINS toLower($b) OR toLower(t.id) CONTAINS toLower($b))
          AND s <> t
        RETURN shortestPath((s)-[*..{safe_hops}]-(t))
        LIMIT 1
    """
    args = {"a": a.strip(), "b": b.strip()}
    res = falkor_client.query(cypher, args)
    rows = []
    if res.result_set and res.result_set[0] and res.result_set[0][0]:
        path = res.result_set[0][0]
        path_nodes = path.nodes() if callable(path.nodes) else path.nodes
        path_edges = path.edges() if callable(path.edges) else path.edges
        
        node_chain = []
        for n in path_nodes:
            nid = n.properties.get("id")
            nlabel = n.properties.get("name") or n.properties.get("title") or nid
            ntype = n.labels[0] if n.labels else "Entity"
            node_chain.append({"id": nid, "name": nlabel, "type": ntype})

        edge_chain = []
        for i, e in enumerate(path_edges):
            u = path_nodes[i]
            v = path_nodes[i+1]
            direction = "->" if (e.src_node == u.id and e.dest_node == v.id) else "<-"
            edge_chain.append({
                "from": u.properties.get("id"),
                "to": v.properties.get("id"),
                "type": e.relation,
                "direction": direction
            })

        rows.append({
            "nodes": node_chain,
            "edges": edge_chain,
            "length": len(edge_chain),
            "summary": " -> ".join([f"{n['name']} ({n['type']})" for n in node_chain])
        })

    return {"rows": rows, "cypher": cypher.strip(), "args": args}

def who_knows(target_id: str) -> Dict[str, Any]:
    """
    Rank employees by weighted paths to target system or project:
    OWNS=5, RESOLVED_BY (incident affecting it)=4, AUTHORED (doc about it)=3,
    WORKED_ON (project using it)=2, PARTICIPATED_IN chat mentioning it=1.
    """
    tid = target_id.strip()
    cypher = """
        MATCH (target)
        WHERE target.id = $tid OR toLower(target.name) CONTAINS toLower($tid) OR toLower(target.id) CONTAINS toLower($tid)
        OPTIONAL MATCH (target)<-[:OWNS]-(e_owner:Employee)
        OPTIONAL MATCH (inc:Incident)-[:AFFECTED]->(target), (inc)-[:RESOLVED_BY]->(e_res:Employee)
        OPTIONAL MATCH (doc:Document)-[:ABOUT|APPLIES_TO]->(target), (e_auth:Employee)-[:AUTHORED]->(doc)
        OPTIONAL MATCH (target)<-[:USES]-(p:Project)<-[:WORKED_ON]-(e_worker:Employee)
        OPTIONAL MATCH (chat:ChatThread)-[:MENTIONS]->(target), (e_chat:Employee)-[:PARTICIPATED_IN]->(chat)
        RETURN target.id AS target_id, coalesce(target.name, target.title) AS target_name,
               e_owner.id, e_owner.name, e_owner.title,
               e_res.id, e_res.name, e_res.title, inc.id, inc.title,
               e_auth.id, e_auth.name, e_auth.title, doc.id, doc.title,
               e_worker.id, e_worker.name, e_worker.title, p.name,
               e_chat.id, e_chat.name, e_chat.title, chat.id
        LIMIT 50
    """
    args = {"tid": tid}
    res = falkor_client.query(cypher, args)

    scores: Dict[str, Dict[str, Any]] = {}

    def add_contrib(eid, name, title, pts, path_desc):
        if not eid:
            return
        if eid not in scores:
            scores[eid] = {
                "employee_id": eid,
                "employee_name": name,
                "title": title,
                "score": 0,
                "breakdown": []
            }
        scores[eid]["score"] += pts
        if path_desc not in scores[eid]["breakdown"]:
            scores[eid]["breakdown"].append(f"{path_desc} (+{pts} pts)")

    if res.result_set:
        for r in res.result_set:
            # OWNS = 5
            if r[2]:
                add_contrib(r[2], r[3], r[4], 5, f"Directly OWNS {r[1]}")
            # RESOLVED_BY = 4
            if r[5]:
                add_contrib(r[5], r[6], r[7], 4, f"RESOLVED {r[8]} ({r[9]}) affecting {r[1]}")
            # AUTHORED = 3
            if r[10]:
                add_contrib(r[10], r[11], r[12], 3, f"AUTHORED {r[13]} ({r[14]}) about {r[1]}")
            # WORKED_ON = 2
            if r[15]:
                add_contrib(r[15], r[16], r[17], 2, f"WORKED_ON project {r[18]} using {r[1]}")
            # PARTICIPATED_IN = 1
            if r[19]:
                add_contrib(r[19], r[20], r[21], 1, f"PARTICIPATED_IN discussion {r[22]} mentioning {r[1]}")

    ranked = sorted(scores.values(), key=lambda x: x["score"], reverse=True)
    return {"rows": ranked, "cypher": cypher.strip(), "args": args}

def decision_trace(id_or_text: str) -> Dict[str, Any]:
    """
    decision -> maker -> documents -> affected project/system;
    follow SUPERSEDES both ways and report which decision is current.
    """
    cypher = """
        MATCH (dec:Decision)
        WHERE dec.id = $term OR toLower(dec.title) CONTAINS toLower($term) OR toLower(dec.rationale) CONTAINS toLower($term) OR toLower(dec.id) CONTAINS toLower($term)
        OPTIONAL MATCH (dec)-[:MADE]->(maker:Employee)
        OPTIONAL MATCH (dec)-[:DOCUMENTED_IN]->(doc:Document)
        OPTIONAL MATCH (doc)-[:ABOUT]->(proj:Project)
        OPTIONAL MATCH (doc)-[:APPLIES_TO]->(sys:System)
        OPTIONAL MATCH (newer:Decision)-[:SUPERSEDES]->(dec)
        OPTIONAL MATCH (dec)-[:SUPERSEDES]->(older:Decision)
        RETURN dec.id, dec.title, dec.status, dec.decided_at, dec.rationale,
               maker.id, maker.name, maker.title,
               doc.id, doc.title,
               proj.id, proj.name,
               sys.id, sys.name,
               newer.id, newer.title, newer.status,
               older.id, older.title
        LIMIT 5
    """
    args = {"term": id_or_text.strip()}
    res = falkor_client.query(cypher, args)
    rows = []
    if res.result_set:
        for r in res.result_set:
            is_superseded = bool(r[14])
            current_status = f"Superseded by {r[14]} ({r[15]})" if is_superseded else (r[2] or "Current")
            rows.append({
                "decision_id": r[0],
                "title": r[1],
                "status": r[2],
                "is_current": not is_superseded,
                "current_status": current_status,
                "decided_at": r[3],
                "rationale": r[4],
                "maker": {"id": r[5], "name": r[6], "title": r[7]} if r[5] else None,
                "document": {"id": r[8], "title": r[9]} if r[8] else None,
                "affected_project": {"id": r[10], "name": r[11]} if r[10] else None,
                "affected_system": {"id": r[12], "name": r[13]} if r[12] else None,
                "superseded_by": {"id": r[14], "title": r[15], "status": r[16]} if r[14] else None,
                "supersedes": {"id": r[17], "title": r[18]} if r[17] else None
            })
    return {"rows": rows, "cypher": cypher.strip(), "args": args}

def blast_radius(system_id: str) -> Dict[str, Any]:
    """Find projects and systems depending on it (up to 2 hops), plus related incidents and tickets."""
    cypher = """
        MATCH (target:System)
        WHERE target.id = $sid OR toLower(target.id) CONTAINS toLower($sid) OR toLower(target.name) CONTAINS toLower($sid)
        OPTIONAL MATCH (proj:Project)-[:USES]->(target)
        OPTIONAL MATCH (downstream:System)-[:DEPENDS_ON]->(target)
        OPTIONAL MATCH (second_hop:Project)-[:USES]->(downstream)
        OPTIONAL MATCH (inc:Incident)-[:AFFECTED]->(target)
        OPTIONAL MATCH (tck:Ticket)-[:RELATES_TO]->(target)
        RETURN target.id, target.name, target.tier, target.health_status,
               collect(DISTINCT proj.name) AS direct_projects,
               collect(DISTINCT downstream.name) AS dependent_systems,
               collect(DISTINCT second_hop.name) AS indirect_projects,
               collect(DISTINCT inc.title) AS related_incidents,
               collect(DISTINCT tck.title) AS related_tickets
    """
    args = {"sid": system_id.strip()}
    res = falkor_client.query(cypher, args)
    rows = []
    if res.result_set:
        r = res.result_set[0]
        if r[0]: # Ensure target matched
            rows.append({
                "system_id": r[0],
                "system_name": r[1],
                "tier": r[2],
                "health_status": r[3],
                "direct_projects": [p for p in r[4] if p],
                "dependent_systems": [s for s in r[5] if s],
                "indirect_projects": [p for p in r[6] if p],
                "related_incidents": [i for i in r[7] if i],
                "related_tickets": [t for t in r[8] if t]
            })
    return {"rows": rows, "cypher": cypher.strip(), "args": args}

def central_nodes(label: str = "Employee", rel_type: str = "COLLABORATES_WITH") -> Dict[str, Any]:
    """PageRank using FalkorDB's documented algo.pageRank procedure; return top 5 with score."""
    safe_label = label if label in WHITELISTED_LABELS else "Employee"
    safe_rel = rel_type if rel_type in WHITELISTED_REL_TYPES else "COLLABORATES_WITH"
    cypher = f"CALL algo.pageRank('{safe_label}', '{safe_rel}')"
    args = {"label": safe_label, "rel_type": safe_rel}
    try:
        res = falkor_client.query(cypher)
        rows = []
        if res.result_set:
            # Sort by rank score descending and take top 5
            sorted_ranks = sorted(res.result_set, key=lambda x: x[1], reverse=True)[:5]
            for node, score in sorted_ranks:
                nid = node.properties.get("id")
                nname = node.properties.get("name") or node.properties.get("title") or nid
                rows.append({
                    "id": nid,
                    "name": nname,
                    "label": safe_label,
                    "score": round(float(score), 4)
                })
        return {"rows": rows, "cypher": cypher, "args": args}
    except Exception as e:
        logger.error(f"algo.pageRank error: {e}")
        # Fallback to in-degree count if algo fails
        cypher_fb = f"""
            MATCH (n:{safe_label})<-[r:{safe_rel}]-()
            RETURN n.id, coalesce(n.name, n.title, n.id), count(r) AS degree
            ORDER BY degree DESC
            LIMIT 5
        """
        res_fb = falkor_client.query(cypher_fb)
        rows_fb = [{"id": r[0], "name": r[1], "label": safe_label, "score": float(r[2])} for r in res_fb.result_set]
        return {"rows": rows_fb, "cypher": cypher_fb.strip(), "args": args}

def search_documents(text: str) -> Dict[str, Any]:
    """Match title, summary, content for Document, Ticket, and ChatThread; return ~160 char snippets."""
    clean_text = text.strip()
    cypher = """
        MATCH (d:Document)
        WHERE toLower(d.title) CONTAINS toLower($text) OR toLower(d.summary) CONTAINS toLower($text) OR toLower(d.content) CONTAINS toLower($text)
        RETURN 'Document' AS type, d.id AS id, d.title AS title, d.content AS content, coalesce(d.updated_at, d.created_at) AS date
        UNION ALL
        MATCH (t:Ticket)
        WHERE toLower(t.title) CONTAINS toLower($text) OR toLower(t.id) CONTAINS toLower($text)
        RETURN 'Ticket' AS type, t.id AS id, t.title AS title, t.title AS content, '2026-08-01' AS date
        UNION ALL
        MATCH (c:ChatThread)
        WHERE toLower(c.channel) CONTAINS toLower($text) OR toLower(c.messages) CONTAINS toLower($text)
        RETURN 'ChatThread' AS type, c.id AS id, c.channel AS title, c.messages AS content, '2026-08-01' AS date
        LIMIT 10
    """
    args = {"text": clean_text}
    res = falkor_client.query(cypher, args)
    rows = []
    if res.result_set:
        for r in res.result_set:
            raw_content = r[3] or ""
            idx = raw_content.lower().find(clean_text.lower())
            if idx >= 0:
                start = max(0, idx - 60)
                end = min(len(raw_content), idx + 100)
                snippet = ("..." if start > 0 else "") + raw_content[start:end].strip() + ("..." if end < len(raw_content) else "")
            else:
                snippet = raw_content[:160].strip() + "..." if len(raw_content) > 160 else raw_content

            rows.append({
                "type": r[0],
                "id": r[1],
                "title": r[2],
                "snippet": snippet,
                "date": r[4]
            })
    return {"rows": rows, "cypher": cypher.strip(), "args": args}

def recent_changes(entity_id_or_none: Optional[str] = None, days: int = 30, limit: int = 10) -> Dict[str, Any]:
    """Retrieve recent tickets, incidents, decisions, and documents (optionally related to an entity)."""
    eid = entity_id_or_none.strip() if entity_id_or_none else None
    if eid:
        cypher = """
            MATCH (n {id: $eid})-[r]-(item)
            WHERE item:Ticket OR item:Incident OR item:Decision OR item:Document
            RETURN labels(item)[0] AS type, item.id AS id, coalesce(item.title, item.name, item.id) AS title,
                   coalesce(item.created_at, item.decided_at, item.updated_at, '2026-08-01') AS date,
                   coalesce(item.summary, item.rationale, item.status, '') AS summary
            ORDER BY date DESC
            LIMIT $limit
        """
        args = {"eid": eid, "limit": limit}
    else:
        cypher = """
            MATCH (item)
            WHERE (item:Ticket OR item:Incident OR item:Decision OR item:Document)
              AND (item.created_at IS NOT NULL OR item.decided_at IS NOT NULL OR item.updated_at IS NOT NULL)
            RETURN labels(item)[0] AS type, item.id AS id, coalesce(item.title, item.name, item.id) AS title,
                   coalesce(item.created_at, item.decided_at, item.updated_at) AS date,
                   coalesce(item.summary, item.rationale, item.status, '') AS summary
            ORDER BY date DESC
            LIMIT $limit
        """
        args = {"limit": limit}

    res = falkor_client.query(cypher, args)
    rows = []
    if res.result_set:
        for r in res.result_set:
            rows.append({
                "type": r[0],
                "id": r[1],
                "title": r[2],
                "date": r[3],
                "summary": r[4]
            })
    return {"rows": rows, "cypher": cypher.strip(), "args": args}

TOOL_CATALOG = [
    {"name": "find_entity", "args": {"text": "string"}, "description": "Search entities by name, ID, or title across all graph labels."},
    {"name": "neighbors", "args": {"id": "string", "hops": "int"}, "description": "Get direct connected neighbors and relationship types for an entity."},
    {"name": "shortest_path", "args": {"a": "string", "b": "string", "max_hops": "int"}, "description": "Find shortest multi-hop relationship path between two entities."},
    {"name": "who_knows", "args": {"target_id": "string"}, "description": "Rank and score employees with expertise on a system or project."},
    {"name": "decision_trace", "args": {"id_or_text": "string"}, "description": "Trace decision provenance, maker, documents, and whether it was superseded."},
    {"name": "blast_radius", "args": {"system_id": "string"}, "description": "Find all upstream and downstream dependencies that break if a system fails."},
    {"name": "central_nodes", "args": {"label": "string", "rel_type": "string"}, "description": "Run PageRank algorithm to find most connected or central employees/nodes."},
    {"name": "search_documents", "args": {"text": "string"}, "description": "Search text content across RFCs, ADRs, postmortems, tickets, and chat threads."},
    {"name": "recent_changes", "args": {"limit": "int"}, "description": "Retrieve most recent architectural decisions and technical documentation."}
]

TOOL_FUNCTIONS = {
    "find_entity": find_entity,
    "neighbors": neighbors,
    "shortest_path": shortest_path,
    "who_knows": who_knows,
    "decision_trace": decision_trace,
    "blast_radius": blast_radius,
    "central_nodes": central_nodes,
    "search_documents": search_documents,
    "recent_changes": recent_changes
}
