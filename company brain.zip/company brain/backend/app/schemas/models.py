from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class EntityRef(BaseModel):
    id: str
    name: str
    type: str
    subtitle: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None

class DepartmentModel(BaseModel):
    id: str
    name: str
    district: str
    description: str
    color: str

class SkillModel(BaseModel):
    id: str
    name: str
    category: str

class EmployeeSummary(BaseModel):
    id: str
    name: str
    title: str
    role: str
    department_id: str
    department_name: Optional[str] = None
    email: str
    avatar: str

class EmployeeProfile(BaseModel):
    id: str
    name: str
    title: str
    role: str
    department_id: str
    department_name: Optional[str] = None
    email: str
    avatar: str
    bio: str
    manager: Optional[EntityRef] = None
    direct_reports: List[EntityRef] = []
    skills: List[SkillModel] = []
    projects: List[EntityRef] = []
    tasks: List[EntityRef] = []
    systems_owned: List[EntityRef] = []
    incidents_resolved: List[EntityRef] = []
    documents_authored: List[EntityRef] = []
    collaborators: List[EntityRef] = []
    connections: List[str] = []

class ProjectBuilding(BaseModel):
    id: str
    name: str
    department_id: str
    department_name: Optional[str] = None
    status: str
    priority: str
    district_x: int
    district_y: int
    team_count: int = 0
    description: str
    risks: Optional[str] = None

class ProjectDetail(BaseModel):
    id: str
    name: str
    department_id: str
    department_name: Optional[str] = None
    status: str
    priority: str
    district_x: int
    district_y: int
    description: str
    risks: Optional[str] = None
    team_members: List[EntityRef] = []
    systems_used: List[EntityRef] = []
    dependencies: List[EntityRef] = []
    tasks: List[EntityRef] = []
    decisions: List[EntityRef] = []
    documents: List[EntityRef] = []
    incidents: List[EntityRef] = []

class SystemModel(BaseModel):
    id: str
    name: str
    tier: str
    technology: str
    description: str
    health_status: str
    owners: List[EntityRef] = []
    used_by_projects: List[EntityRef] = []
    incidents: List[EntityRef] = []

class DocumentModel(BaseModel):
    id: str
    title: str
    doc_type: str
    summary: str
    content: str
    url: Optional[str] = None
    author: Optional[EntityRef] = None
    project: Optional[EntityRef] = None
    system: Optional[EntityRef] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

class DecisionModel(BaseModel):
    id: str
    title: str
    status: str
    decided_at: str
    rationale: str
    maker: Optional[EntityRef] = None
    project: Optional[EntityRef] = None
    document: Optional[EntityRef] = None
    superseded_by: Optional[EntityRef] = None
    supersedes: Optional[EntityRef] = None

class IncidentModel(BaseModel):
    id: str
    title: str
    severity: str
    status: str
    root_cause: str
    summary: str
    system: Optional[EntityRef] = None
    project: Optional[EntityRef] = None
    resolver: Optional[EntityRef] = None
    document: Optional[EntityRef] = None

class TicketModel(BaseModel):
    id: str
    title: str
    status: str
    priority: str
    project_id: str
    assignee_id: Optional[str] = None
    incident_id: Optional[str] = None
    system_id: Optional[str] = None

class ChatThreadModel(BaseModel):
    id: str
    channel: str
    participants: List[str] = []
    mentions: List[str] = []
    messages: List[str] = []

class CityResponse(BaseModel):
    company_name: str
    departments: List[DepartmentModel]
    projects: List[ProjectBuilding]
    employees: List[EmployeeSummary]
    systems: List[SystemModel]
    stats: Dict[str, int]

class GraphNode(BaseModel):
    id: str
    label: str
    type: str
    properties: Dict[str, Any] = {}

class GraphEdge(BaseModel):
    id: str
    source: str
    target: str
    type: str
    label: str
    properties: Dict[str, Any] = {}

class GraphNeighborhood(BaseModel):
    center_id: str
    nodes: List[GraphNode]
    edges: List[GraphEdge]

class PathQueryRequest(BaseModel):
    source_id: str
    target_id: str
    max_hops: int = 4

class PathQueryResponse(BaseModel):
    found: bool
    nodes: List[GraphNode] = []
    edges: List[GraphEdge] = []
    explanation: str

class AssistantQueryRequest(BaseModel):
    question: str
    context_entity_id: Optional[str] = None
    session_id: Optional[str] = None

class AssistantQueryResponse(BaseModel):
    question: str
    answer: str
    intent: str
    agent: str = "deterministic" # "deterministic" or "llm"
    tools_called: List[Dict[str, Any]] = []
    cypher_executed: List[str] = []
    graph_path: List[Dict[str, Any]] = []
    evidence_path: List[str] = []
    supporting_entities: List[EntityRef] = []
    source_records: List[Dict[str, Any]] = [] # {id, type, title, snippet, date}
    tool_trace: List[Dict[str, Any]] = [] # [{tool, args, row_count}]
    highlighted_entity_ids: List[str] = []
    limitations: Optional[str] = None
    session_id: Optional[str] = None

class HealthResponse(BaseModel):
    status: str
    falkordb_connected: bool
    graph_name: str
    node_count: int
    edge_count: int
    error: Optional[str] = None

class IngestJsonRequest(BaseModel):
    nodes: Optional[List[Dict[str, Any]]] = None
    relationships: Optional[List[Dict[str, Any]]] = None
    departments: Optional[List[Dict[str, Any]]] = None
    employees: Optional[List[Dict[str, Any]]] = None
    projects: Optional[List[Dict[str, Any]]] = None
    systems: Optional[List[Dict[str, Any]]] = None
    tasks: Optional[List[Dict[str, Any]]] = None
    documents: Optional[List[Dict[str, Any]]] = None
    decisions: Optional[List[Dict[str, Any]]] = None
    incidents: Optional[List[Dict[str, Any]]] = None
    tickets: Optional[List[Dict[str, Any]]] = None
    chat_threads: Optional[List[Dict[str, Any]]] = None

class IngestDocRequest(BaseModel):
    id: Optional[str] = None
    title: str
    doc_type: str = "Document"
    summary: str
    content: str
    author_id: Optional[str] = None
    project_id: Optional[str] = None
    system_id: Optional[str] = None
    url: Optional[str] = None

class IngestDocResponse(BaseModel):
    id: str
    title: str
    new_edges: List[Dict[str, str]] = []

class SessionTurn(BaseModel):
    question: str
    answer: str
    timestamp: Optional[str] = None
    cited_entity_ids: List[str] = []
    focus_id: Optional[str] = None

class SessionDetail(BaseModel):
    session_id: str
    turn_count: int
    turns: List[SessionTurn] = []
