import json
import logging
import os
import re
import glob
import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
from app.graph.falkor_client import falkor_client
from app.config import settings
from app.schemas.models import (
    CityResponse, DepartmentModel, EmployeeSummary, EmployeeProfile,
    ProjectBuilding, ProjectDetail, SystemModel, DocumentModel,
    DecisionModel, IncidentModel, TicketModel, ChatThreadModel, SkillModel,
    GraphNode, GraphEdge, GraphNeighborhood, PathQueryResponse,
    HealthResponse, EntityRef, IngestDocResponse, SessionTurn, SessionDetail
)

logger = logging.getLogger(__name__)

ALLOWED_REL_TYPES = {
    "BELONGS_TO", "REPORTS_TO", "WORKED_ON", "OWNS", "HAS_SKILL",
    "USES", "DEPENDS_ON", "AFFECTED", "RESOLVED_BY", "DOCUMENTED_IN",
    "AUTHORED", "MADE", "COLLABORATES_WITH", "ASSIGNED_TO",
    "BELONGS_TO_PROJECT", "RELATES_TO", "PARTICIPATED_IN", "MENTIONS",
    "SUPERSEDES", "CITED", "ASKED", "ANSWERED_WITH", "ABOUT"
}

def derive_label(entity_id: str) -> str:
    """Derive entity label from ID prefix or return Entity fallback."""
    eid = entity_id.lower()
    if eid.startswith("dept_"):
        return "Department"
    elif eid.startswith("emp_"):
        return "Employee"
    elif eid.startswith("proj_"):
        return "Project"
    elif eid.startswith("sys_"):
        return "System"
    elif eid.startswith("task_"):
        return "Task"
    elif eid.startswith("doc_"):
        return "Document"
    elif eid.startswith("dec_"):
        return "Decision"
    elif eid.startswith("inc_"):
        return "Incident"
    elif eid.startswith("skill_"):
        return "Skill"
    elif eid.startswith("tck_") or eid.startswith("tck-"):
        return "Ticket"
    elif eid.startswith("chat_"):
        return "ChatThread"
    elif eid.startswith("session_"):
        return "Session"
    elif eid.startswith("q_"):
        return "Question"
    elif eid.startswith("ans_"):
        return "Answer"
    return "Entity"

class GraphService:
    def __init__(self):
        self.client = falkor_client

    def initialize_schema(self, graph_name: Optional[str] = None):
        """Create indices on primary entity IDs for optimal query performance."""
        g_name = graph_name or settings.GRAPH_NAME
        labels = [
            "Department", "Skill", "Employee", "Project", "System", "Task",
            "Document", "Decision", "Incident", "Ticket", "ChatThread",
            "Session", "Question", "Answer"
        ]
        for label in labels:
            try:
                self.client.query(f"CREATE INDEX FOR (n:{label}) ON (n.id)", graph_name=g_name)
            except Exception as e:
                logger.debug(f"Index check for {label} on {g_name}: {e}")

    def seed_data(self, force: bool = False, graph_name: Optional[str] = None) -> Dict[str, Any]:
        """Idempotently seed the NovaWorks graph data using MERGE."""
        g_name = graph_name or settings.GRAPH_NAME
        self.initialize_schema(g_name)

        if not os.path.exists(settings.DATA_FILE):
            from app.seed_generator import write_seed_data
            write_seed_data(settings.DATA_FILE)

        with open(settings.DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 1. Departments
        for dept in data.get("departments", []):
            self.client.query(
                "MERGE (d:Department {id: $id}) "
                "SET d.name = $name, d.district = $district, d.description = $description, d.color = $color",
                dept,
                graph_name=g_name
            )

        # 2. Skills
        for skill in data.get("skills", []):
            self.client.query(
                "MERGE (s:Skill {id: $id}) SET s.name = $name, s.category = $category",
                skill,
                graph_name=g_name
            )

        # 3. Employees
        for emp in data.get("employees", []):
            self.client.query(
                "MERGE (e:Employee {id: $id}) "
                "SET e.name = $name, e.title = $title, e.role = $role, e.department_id = $department_id, "
                "    e.email = $email, e.avatar = $avatar, e.bio = $bio",
                emp,
                graph_name=g_name
            )

        # 4. Projects
        for proj in data.get("projects", []):
            self.client.query(
                "MERGE (p:Project {id: $id}) "
                "SET p.name = $name, p.department_id = $department_id, p.status = $status, "
                "    p.priority = $priority, p.district_x = $district_x, p.district_y = $district_y, "
                "    p.description = $description, p.risks = $risks",
                proj,
                graph_name=g_name
            )

        # 5. Systems
        for sys_item in data.get("systems", []):
            self.client.query(
                "MERGE (s:System {id: $id}) "
                "SET s.name = $name, s.tier = $tier, s.technology = $technology, "
                "    s.description = $description, s.health_status = $health_status",
                sys_item,
                graph_name=g_name
            )

        # 6. Tasks
        for task in data.get("tasks", []):
            self.client.query(
                "MERGE (t:Task {id: $id}) "
                "SET t.title = $title, t.status = $status, t.priority = $priority, "
                "    t.project_id = $project_id, t.assignee_id = $assignee_id",
                task,
                graph_name=g_name
            )

        # 7. Documents
        for doc in data.get("documents", []):
            self.client.query(
                "MERGE (d:Document {id: $id}) "
                "SET d.title = $title, d.doc_type = $doc_type, d.summary = $summary, "
                "    d.content = $content, d.url = $url, d.author_id = $author_id, "
                "    d.project_id = $project_id, d.system_id = $system_id, "
                "    d.created_at = $created_at, d.updated_at = $updated_at",
                {
                    "id": doc["id"],
                    "title": doc.get("title", ""),
                    "doc_type": doc.get("doc_type", "Document"),
                    "summary": doc.get("summary", ""),
                    "content": doc.get("content", ""),
                    "url": doc.get("url"),
                    "author_id": doc.get("author_id"),
                    "project_id": doc.get("project_id"),
                    "system_id": doc.get("system_id"),
                    "created_at": doc.get("created_at", "2026-06-01T10:00:00Z"),
                    "updated_at": doc.get("updated_at", "2026-06-01T10:00:00Z")
                },
                graph_name=g_name
            )

        # 8. Decisions
        for dec in data.get("decisions", []):
            self.client.query(
                "MERGE (d:Decision {id: $id}) "
                "SET d.title = $title, d.status = $status, d.decided_at = $decided_at, "
                "    d.created_at = $created_at, d.rationale = $rationale, d.maker_id = $maker_id, "
                "    d.project_id = $project_id, d.document_id = $document_id",
                {
                    "id": dec["id"],
                    "title": dec.get("title", ""),
                    "status": dec.get("status", "Approved"),
                    "decided_at": dec.get("decided_at", "2026-06-01T10:00:00Z"),
                    "created_at": dec.get("created_at", dec.get("decided_at", "2026-06-01T10:00:00Z")),
                    "rationale": dec.get("rationale", ""),
                    "maker_id": dec.get("maker_id"),
                    "project_id": dec.get("project_id"),
                    "document_id": dec.get("document_id")
                },
                graph_name=g_name
            )

        # 9. Incidents
        for inc in data.get("incidents", []):
            self.client.query(
                "MERGE (i:Incident {id: $id}) "
                "SET i.title = $title, i.severity = $severity, i.status = $status, "
                "    i.root_cause = $root_cause, i.summary = $summary, i.system_id = $system_id, "
                "    i.project_id = $project_id, i.resolver_id = $resolver_id, i.document_id = $document_id",
                inc,
                graph_name=g_name
            )

        # 10. Tickets
        for tck in data.get("tickets", []):
            self.client.query(
                "MERGE (t:Ticket {id: $id}) "
                "SET t.title = $title, t.status = $status, t.priority = $priority, "
                "    t.project_id = $project_id, t.assignee_id = $assignee_id, "
                "    t.incident_id = $incident_id, t.system_id = $system_id",
                tck,
                graph_name=g_name
            )

        # 11. ChatThreads
        for chat in data.get("chat_threads", []):
            self.client.query(
                "MERGE (c:ChatThread {id: $id}) "
                "SET c.channel = $channel, c.messages = $messages",
                {
                    "id": chat["id"],
                    "channel": chat.get("channel", "#general"),
                    "messages": json.dumps(chat.get("messages", []))
                },
                graph_name=g_name
            )

        # 12. Relationships with LABELED matches
        for rel in data.get("relationships", []):
            from_id = rel["from"]
            to_id = rel["to"]
            rel_type = rel["type"]
            if rel_type not in ALLOWED_REL_TYPES:
                continue

            from_label = derive_label(from_id)
            to_label = derive_label(to_id)

            if from_label != "Entity" and to_label != "Entity":
                cypher = (
                    f"MATCH (a:{from_label} {{id: $from_id}}), (b:{to_label} {{id: $to_id}}) "
                    f"MERGE (a)-[r:{rel_type}]->(b)"
                )
            else:
                cypher = (
                    f"MATCH (a {{id: $from_id}}), (b {{id: $to_id}}) "
                    f"MERGE (a)-[r:{rel_type}]->(b)"
                )
            self.client.query(cypher, {"from_id": from_id, "to_id": to_id}, graph_name=g_name)

        # 13. Seed markdown files from data/documents/*.md (Phase 4 requirement)
        doc_dir = os.path.join(settings.BASE_DIR, "data", "documents")
        if os.path.exists(doc_dir):
            for md_file in glob.glob(os.path.join(doc_dir, "*.md")):
                try:
                    self._ingest_markdown_file(md_file, graph_name=g_name)
                except Exception as ex:
                    logger.warning(f"Error ingesting seed document {md_file}: {ex}")

        health = self.get_health(graph_name=g_name)
        return {
            "status": "seeded",
            "message": f"Graph '{g_name}' dataset loaded successfully.",
            "node_count": health.node_count,
            "edge_count": health.edge_count
        }

    def _ingest_markdown_file(self, filepath: str, graph_name: Optional[str] = None):
        """Parse and ingest a local markdown file, linking mentions."""
        basename = os.path.basename(filepath)
        doc_id = "doc_" + re.sub(r'[^a-z0-9]', '_', os.path.splitext(basename)[0].lower())
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()

        title = basename.replace(".md", "").replace("-", " ").title()
        lines = [line.strip() for line in content.split("\n") if line.strip()]
        for line in lines:
            if line.startswith("# "):
                title = line[2:].strip()
                break

        summary = lines[1] if len(lines) > 1 else content[:140]
        self.ingest_document({
            "id": doc_id,
            "title": title,
            "doc_type": "Document",
            "summary": summary,
            "content": content
        }, graph_name=graph_name)

    def get_health(self, graph_name: Optional[str] = None) -> HealthResponse:
        """Check FalkorDB health, connectivity, node count, and edge count."""
        g_name = graph_name or settings.GRAPH_NAME
        try:
            res_nodes = self.client.query("MATCH (n) RETURN count(n)", graph_name=g_name)
            node_count = res_nodes.result_set[0][0] if res_nodes.result_set else 0

            res_edges = self.client.query("MATCH ()-[r]->() RETURN count(r)", graph_name=g_name)
            edge_count = res_edges.result_set[0][0] if res_edges.result_set else 0

            return HealthResponse(
                status="healthy",
                falkordb_connected=True,
                graph_name=g_name,
                node_count=node_count,
                edge_count=edge_count
            )
        except Exception as e:
            return HealthResponse(
                status="unhealthy",
                falkordb_connected=False,
                graph_name=g_name,
                node_count=0,
                edge_count=0,
                error=str(e)
            )

    def get_city_data(self) -> CityResponse:
        """Retrieve complete city layout data including districts, projects, employees, and systems."""
        g_name = settings.GRAPH_NAME

        # Departments
        res_dept = self.client.query(
            "MATCH (d:Department) RETURN d.id, d.name, d.district, d.description, d.color ORDER BY d.id ASC",
            graph_name=g_name
        )
        departments = [
            DepartmentModel(id=r[0], name=r[1], district=r[2], description=r[3], color=r[4])
            for r in res_dept.result_set
        ]

        # Projects
        res_proj = self.client.query("""
            MATCH (p:Project)
            OPTIONAL MATCH (p)-[:BELONGS_TO]->(d:Department)
            OPTIONAL MATCH (e:Employee)-[:WORKED_ON]->(p)
            RETURN p.id, p.name, p.department_id, d.name, p.status, p.priority, 
                   p.district_x, p.district_y, p.description, p.risks, count(e)
            ORDER BY p.name ASC
        """, graph_name=g_name)
        projects = [
            ProjectBuilding(
                id=r[0], name=r[1], department_id=r[2] or "", department_name=r[3],
                status=r[4] or "active", priority=r[5] or "medium", district_x=r[6] or 100, district_y=r[7] or 100,
                description=r[8] or "", risks=r[9], team_count=r[10] or 0
            )
            for r in res_proj.result_set
        ]

        # Employees
        res_emp = self.client.query("""
            MATCH (e:Employee)
            OPTIONAL MATCH (e)-[:BELONGS_TO]->(d:Department)
            RETURN e.id, e.name, e.title, e.role, e.department_id, d.name, e.email, e.avatar
            ORDER BY e.name ASC
        """, graph_name=g_name)
        employees = [
            EmployeeSummary(
                id=r[0], name=r[1], title=r[2], role=r[3], department_id=r[4] or "",
                department_name=r[5], email=r[6] or "", avatar=r[7] or ""
            )
            for r in res_emp.result_set
        ]

        # Systems
        res_sys = self.client.query(
            "MATCH (s:System) RETURN s.id, s.name, s.tier, s.technology, s.description, s.health_status ORDER BY s.name ASC",
            graph_name=g_name
        )
        systems = [
            SystemModel(id=r[0], name=r[1], tier=r[2], technology=r[3], description=r[4], health_status=r[5])
            for r in res_sys.result_set
        ]

        stats = {
            "departments": len(departments),
            "projects": len(projects),
            "employees": len(employees),
            "systems": len(systems)
        }

        return CityResponse(
            company_name="NovaWorks",
            departments=departments,
            projects=projects,
            employees=employees,
            systems=systems,
            stats=stats
        )

    def get_employees(self, query: Optional[str] = None, department_id: Optional[str] = None) -> List[EmployeeSummary]:
        """Search and filter employees. WHERE applied to MATCH before OPTIONAL MATCH."""
        g_name = settings.GRAPH_NAME
        cypher = """
            MATCH (e:Employee)
            WHERE ($query IS NULL OR toLower(e.name) CONTAINS toLower($query) OR toLower(e.title) CONTAINS toLower($query) OR toLower(e.role) CONTAINS toLower($query))
              AND ($dept_id IS NULL OR e.department_id = $dept_id)
            OPTIONAL MATCH (e)-[:BELONGS_TO]->(d:Department)
            RETURN e.id, e.name, e.title, e.role, e.department_id, d.name, e.email, e.avatar
            ORDER BY e.name ASC
        """
        res = self.client.query(cypher, {"query": query, "dept_id": department_id}, graph_name=g_name)
        return [
            EmployeeSummary(
                id=r[0], name=r[1], title=r[2], role=r[3], department_id=r[4] or "",
                department_name=r[5], email=r[6] or "", avatar=r[7] or ""
            )
            for r in res.result_set
        ]

    def get_employee_profile(self, employee_id: str) -> Optional[EmployeeProfile]:
        """Deep graph traversal for employee profile."""
        g_name = settings.GRAPH_NAME
        res_emp = self.client.query("""
            MATCH (e:Employee {id: $id})
            OPTIONAL MATCH (e)-[:BELONGS_TO]->(d:Department)
            RETURN e.id, e.name, e.title, e.role, e.department_id, d.name, e.email, e.avatar, e.bio
        """, {"id": employee_id}, graph_name=g_name)

        if not res_emp.result_set:
            return None
        r = res_emp.result_set[0]

        # Manager (REPORTS_TO)
        res_mgr = self.client.query("""
            MATCH (e:Employee {id: $id})-[:REPORTS_TO]->(m:Employee)
            RETURN m.id, m.name, m.title
        """, {"id": employee_id}, graph_name=g_name)
        manager = EntityRef(id=res_mgr.result_set[0][0], name=res_mgr.result_set[0][1], type="Employee", subtitle=res_mgr.result_set[0][2]) if res_mgr.result_set else None

        # Direct Reports
        res_reps = self.client.query("""
            MATCH (rep:Employee)-[:REPORTS_TO]->(e:Employee {id: $id})
            RETURN rep.id, rep.name, rep.title
        """, {"id": employee_id}, graph_name=g_name)
        direct_reports = [EntityRef(id=row[0], name=row[1], type="Employee", subtitle=row[2]) for row in res_reps.result_set]

        # Skills
        res_skills = self.client.query("""
            MATCH (e:Employee {id: $id})-[:HAS_SKILL]->(s:Skill)
            RETURN s.id, s.name, s.category
        """, {"id": employee_id}, graph_name=g_name)
        skills = [SkillModel(id=row[0], name=row[1], category=row[2]) for row in res_skills.result_set]

        # Projects
        res_projs = self.client.query("""
            MATCH (e:Employee {id: $id})-[:WORKED_ON]->(p:Project)
            RETURN p.id, p.name, p.status, p.priority
        """, {"id": employee_id}, graph_name=g_name)
        projects = [EntityRef(id=row[0], name=row[1], type="Project", subtitle=f"{row[2]} ({row[3]})") for row in res_projs.result_set]

        # Tasks / Tickets
        res_tasks = self.client.query("""
            MATCH (t:Ticket)-[:ASSIGNED_TO]->(e:Employee {id: $id})
            RETURN t.id, t.title, t.status, t.priority
        """, {"id": employee_id}, graph_name=g_name)
        tasks = [EntityRef(id=row[0], name=row[1], type="Ticket", subtitle=f"{row[2]} ({row[3]})") for row in res_tasks.result_set]

        # Systems Owned
        res_sys = self.client.query("""
            MATCH (e:Employee {id: $id})-[:OWNS]->(s:System)
            RETURN s.id, s.name, s.tier, s.health_status
        """, {"id": employee_id}, graph_name=g_name)
        systems_owned = [EntityRef(id=row[0], name=row[1], type="System", subtitle=f"{row[2]} ({row[3]})") for row in res_sys.result_set]

        # Incidents Resolved
        res_inc = self.client.query("""
            MATCH (inc:Incident)-[:RESOLVED_BY]->(e:Employee {id: $id})
            RETURN inc.id, inc.title, inc.severity
        """, {"id": employee_id}, graph_name=g_name)
        incidents_resolved = [EntityRef(id=row[0], name=row[1], type="Incident", subtitle=row[2]) for row in res_inc.result_set]

        # Documents Authored
        res_docs = self.client.query("""
            MATCH (e:Employee {id: $id})-[:AUTHORED]->(d:Document)
            RETURN d.id, d.title, d.doc_type
        """, {"id": employee_id}, graph_name=g_name)
        documents_authored = [EntityRef(id=row[0], name=row[1], type="Document", subtitle=row[2]) for row in res_docs.result_set]

        # Collaborators
        res_collabs = self.client.query("""
            MATCH (e:Employee {id: $id})-[:COLLABORATES_WITH]->(c:Employee)
            RETURN c.id, c.name, c.title
        """, {"id": employee_id}, graph_name=g_name)
        collaborators = [EntityRef(id=row[0], name=row[1], type="Employee", subtitle=row[2]) for row in res_collabs.result_set]

        # Evidence Connections
        connections = []
        res_paths = self.client.query("""
            MATCH (e:Employee {id: $id})-[:WORKED_ON]->(p:Project)-[:USES]->(s:System)
            RETURN p.name, s.name
        """, {"id": employee_id}, graph_name=g_name)
        for cp in res_paths.result_set:
            connections.append(f"{r[1]} → WORKED_ON → {cp[0]} → USES → {cp[1]}")

        res_inc_paths = self.client.query("""
            MATCH (inc:Incident)-[:RESOLVED_BY]->(e:Employee {id: $id})
            MATCH (inc)-[:AFFECTED]->(target)
            RETURN inc.title, target.name
        """, {"id": employee_id}, graph_name=g_name)
        for ip in res_inc_paths.result_set:
            connections.append(f"{r[1]} → RESOLVED → {ip[0]} → AFFECTED → {ip[1]}")

        return EmployeeProfile(
            id=r[0], name=r[1], title=r[2], role=r[3], department_id=r[4] or "",
            department_name=r[5], email=r[6] or "", avatar=r[7] or "", bio=r[8] or "No bio provided.",
            manager=manager, direct_reports=direct_reports, skills=skills,
            projects=projects, tasks=tasks, systems_owned=systems_owned,
            incidents_resolved=incidents_resolved, documents_authored=documents_authored,
            collaborators=collaborators, connections=connections
        )

    def get_projects(self, query: Optional[str] = None, department_id: Optional[str] = None, status: Optional[str] = None) -> List[ProjectBuilding]:
        """Search and filter projects. WHERE applied to MATCH before OPTIONAL MATCH."""
        g_name = settings.GRAPH_NAME
        cypher = """
            MATCH (p:Project)
            WHERE ($query IS NULL OR toLower(p.name) CONTAINS toLower($query) OR toLower(p.description) CONTAINS toLower($query))
              AND ($dept_id IS NULL OR p.department_id = $dept_id)
              AND ($status IS NULL OR p.status = $status)
            OPTIONAL MATCH (p)-[:BELONGS_TO]->(d:Department)
            OPTIONAL MATCH (e:Employee)-[:WORKED_ON]->(p)
            RETURN p.id, p.name, p.department_id, d.name, p.status, p.priority, 
                   p.district_x, p.district_y, p.description, p.risks, count(e)
            ORDER BY p.name ASC
        """
        res = self.client.query(cypher, {"query": query, "dept_id": department_id, "status": status}, graph_name=g_name)
        return [
            ProjectBuilding(
                id=r[0], name=r[1], department_id=r[2] or "", department_name=r[3],
                status=r[4] or "active", priority=r[5] or "medium", district_x=r[6] or 100, district_y=r[7] or 100,
                description=r[8] or "", risks=r[9], team_count=r[10] or 0
            )
            for r in res.result_set
        ]

    def get_project_detail(self, project_id: str) -> Optional[ProjectDetail]:
        """Retrieve complete project details with graph relationships."""
        g_name = settings.GRAPH_NAME
        res_proj = self.client.query("""
            MATCH (p:Project {id: $id})
            OPTIONAL MATCH (p)-[:BELONGS_TO]->(d:Department)
            RETURN p.id, p.name, p.department_id, d.name, p.status, p.priority, 
                   p.district_x, p.district_y, p.description, p.risks
        """, {"id": project_id}, graph_name=g_name)

        if not res_proj.result_set:
            return None
        r = res_proj.result_set[0]

        # Team members
        res_team = self.client.query("""
            MATCH (e:Employee)-[:WORKED_ON]->(p:Project {id: $id})
            RETURN e.id, e.name, e.title, e.role
        """, {"id": project_id}, graph_name=g_name)
        team_members = [EntityRef(id=t[0], name=t[1], type="Employee", subtitle=f"{t[2]} ({t[3]})") for t in res_team.result_set]

        # Systems Used
        res_sys = self.client.query("""
            MATCH (p:Project {id: $id})-[:USES]->(s:System)
            RETURN s.id, s.name, s.tier, s.health_status
        """, {"id": project_id}, graph_name=g_name)
        systems_used = [EntityRef(id=s[0], name=s[1], type="System", subtitle=f"{s[2]} | Health: {s[3]}") for s in res_sys.result_set]

        # Dependencies
        res_dep = self.client.query("""
            MATCH (p:Project {id: $id})-[:DEPENDS_ON]->(target)
            RETURN target.id, target.name, labels(target)[0]
        """, {"id": project_id}, graph_name=g_name)
        dependencies = [EntityRef(id=d[0], name=d[1], type=d[2]) for d in res_dep.result_set]

        # Tasks / Tickets
        res_tasks = self.client.query("""
            MATCH (t:Ticket)-[:BELONGS_TO_PROJECT]->(p:Project {id: $id})
            RETURN t.id, t.title, t.status, t.priority
        """, {"id": project_id}, graph_name=g_name)
        tasks = [EntityRef(id=t[0], name=t[1], type="Ticket", subtitle=f"{t[2]} | {t[3]}") for t in res_tasks.result_set]

        # Decisions
        res_dec = self.client.query("""
            MATCH (d:Decision {project_id: $id})
            RETURN d.id, d.title, d.status, d.rationale
        """, {"id": project_id}, graph_name=g_name)
        decisions = [EntityRef(id=d[0], name=d[1], type="Decision", subtitle=d[2], extra={"rationale": d[3]}) for d in res_dec.result_set]

        # Documents
        res_docs = self.client.query("""
            MATCH (d:Document {project_id: $id})
            RETURN d.id, d.title, d.doc_type, d.summary
        """, {"id": project_id}, graph_name=g_name)
        documents = [EntityRef(id=d[0], name=d[1], type="Document", subtitle=d[2], extra={"summary": d[3]}) for d in res_docs.result_set]

        # Incidents
        res_inc = self.client.query("""
            MATCH (i:Incident)-[:AFFECTED]->(p:Project {id: $id})
            RETURN i.id, i.title, i.severity, i.status
        """, {"id": project_id}, graph_name=g_name)
        incidents = [EntityRef(id=i[0], name=i[1], type="Incident", subtitle=f"{i[2]} | {i[3]}") for i in res_inc.result_set]

        return ProjectDetail(
            id=r[0], name=r[1], department_id=r[2] or "", department_name=r[3],
            status=r[4] or "active", priority=r[5] or "medium", district_x=r[6] or 100, district_y=r[7] or 100,
            description=r[8] or "", risks=r[9], team_members=team_members,
            systems_used=systems_used, dependencies=dependencies, tasks=tasks,
            decisions=decisions, documents=documents, incidents=incidents
        )

    def get_systems(self) -> List[SystemModel]:
        g_name = settings.GRAPH_NAME
        res = self.client.query("MATCH (s:System) RETURN s.id, s.name, s.tier, s.technology, s.description, s.health_status ORDER BY s.name ASC", graph_name=g_name)
        return [
            SystemModel(id=r[0], name=r[1], tier=r[2], technology=r[3], description=r[4], health_status=r[5])
            for r in res.result_set
        ]

    def get_system_detail(self, system_id: str) -> Optional[SystemModel]:
        g_name = settings.GRAPH_NAME
        res = self.client.query("""
            MATCH (s:System {id: $id})
            RETURN s.id, s.name, s.tier, s.technology, s.description, s.health_status
        """, {"id": system_id}, graph_name=g_name)

        if not res.result_set:
            return None
        r = res.result_set[0]

        # Owners
        res_owners = self.client.query("MATCH (e:Employee)-[:OWNS]->(s:System {id: $id}) RETURN e.id, e.name, e.title", {"id": system_id}, graph_name=g_name)
        owners = [EntityRef(id=o[0], name=o[1], type="Employee", subtitle=o[2]) for o in res_owners.result_set]

        # Used By Projects
        res_projs = self.client.query("MATCH (p:Project)-[:USES]->(s:System {id: $id}) RETURN p.id, p.name, p.status", {"id": system_id}, graph_name=g_name)
        used_by = [EntityRef(id=p[0], name=p[1], type="Project", subtitle=p[2]) for p in res_projs.result_set]

        # Incidents
        res_inc = self.client.query("MATCH (i:Incident)-[:AFFECTED]->(s:System {id: $id}) RETURN i.id, i.title, i.severity", {"id": system_id}, graph_name=g_name)
        incidents = [EntityRef(id=i[0], name=i[1], type="Incident", subtitle=i[2]) for i in res_inc.result_set]

        return SystemModel(
            id=r[0], name=r[1], tier=r[2], technology=r[3], description=r[4],
            health_status=r[5], owners=owners, used_by_projects=used_by, incidents=incidents
        )

    def get_documents(self) -> List[DocumentModel]:
        g_name = settings.GRAPH_NAME
        res = self.client.query("""
            MATCH (d:Document)
            OPTIONAL MATCH (e:Employee)-[:AUTHORED]->(d)
            OPTIONAL MATCH (d)-[:ABOUT]->(p:Project)
            OPTIONAL MATCH (d)-[:APPLIES_TO]->(s:System)
            RETURN d.id, d.title, d.doc_type, d.summary, d.content, d.url, 
                   e.id, e.name, p.id, p.name, s.id, s.name, d.created_at, d.updated_at
            ORDER BY d.id ASC
        """, graph_name=g_name)
        docs = []
        for r in res.result_set:
            author = EntityRef(id=r[6], name=r[7], type="Employee") if r[6] else None
            proj = EntityRef(id=r[8], name=r[9], type="Project") if r[8] else None
            sys_ref = EntityRef(id=r[10], name=r[11], type="System") if r[10] else None
            docs.append(DocumentModel(
                id=r[0], title=r[1], doc_type=r[2], summary=r[3], content=r[4], url=r[5],
                author=author, project=proj, system=sys_ref, created_at=r[12], updated_at=r[13]
            ))
        return docs

    def get_decisions(self) -> List[DecisionModel]:
        g_name = settings.GRAPH_NAME
        res = self.client.query("""
            MATCH (dec:Decision)
            OPTIONAL MATCH (dec)-[:MADE]->(m:Employee)
            OPTIONAL MATCH (dec)-[:DOCUMENTED_IN]->(doc:Document)
            OPTIONAL MATCH (newer:Decision)-[:SUPERSEDES]->(dec)
            OPTIONAL MATCH (dec)-[:SUPERSEDES]->(older:Decision)
            RETURN dec.id, dec.title, dec.status, dec.decided_at, dec.rationale,
                   m.id, m.name, doc.id, doc.title,
                   newer.id, newer.title, older.id, older.title
            ORDER BY dec.id ASC
        """, graph_name=g_name)
        decs = []
        for r in res.result_set:
            maker = EntityRef(id=r[5], name=r[6], type="Employee") if r[5] else None
            doc = EntityRef(id=r[7], name=r[8], type="Document") if r[7] else None
            newer_ref = EntityRef(id=r[9], name=r[10], type="Decision") if r[9] else None
            older_ref = EntityRef(id=r[11], name=r[12], type="Decision") if r[11] else None
            decs.append(DecisionModel(
                id=r[0], title=r[1], status=r[2], decided_at=r[3], rationale=r[4],
                maker=maker, document=doc, superseded_by=newer_ref, supersedes=older_ref
            ))
        return decs

    def get_incidents(self) -> List[IncidentModel]:
        g_name = settings.GRAPH_NAME
        res = self.client.query("""
            MATCH (inc:Incident)
            OPTIONAL MATCH (inc)-[:AFFECTED]->(s:System)
            OPTIONAL MATCH (inc)-[:AFFECTED]->(p:Project)
            OPTIONAL MATCH (inc)-[:RESOLVED_BY]->(e:Employee)
            OPTIONAL MATCH (inc)-[:DOCUMENTED_IN]->(d:Document)
            RETURN inc.id, inc.title, inc.severity, inc.status, inc.root_cause, inc.summary,
                   s.id, s.name, p.id, p.name, e.id, e.name, d.id, d.title
            ORDER BY inc.id ASC
        """, graph_name=g_name)
        incs = []
        for r in res.result_set:
            sys_ref = EntityRef(id=r[6], name=r[7], type="System") if r[6] else None
            proj_ref = EntityRef(id=r[8], name=r[9], type="Project") if r[8] else None
            res_ref = EntityRef(id=r[10], name=r[11], type="Employee") if r[10] else None
            doc_ref = EntityRef(id=r[12], name=r[13], type="Document") if r[12] else None
            incs.append(IncidentModel(
                id=r[0], title=r[1], severity=r[2], status=r[3], root_cause=r[4], summary=r[5],
                system=sys_ref, project=proj_ref, resolver=res_ref, document=doc_ref
            ))
        return incs

    def get_neighborhood(self, entity_id: str, hops: int = 1) -> GraphNeighborhood:
        """Retrieve radial graph neighborhood honoring hops (1 or 2)."""
        g_name = settings.GRAPH_NAME
        hops = 2 if hops >= 2 else 1

        if hops == 1:
            cypher = """
                MATCH (center {id: $id})
                OPTIONAL MATCH (center)-[r]-(neighbor)
                RETURN center, r, neighbor
            """
        else:
            cypher = """
                MATCH (center {id: $id})
                OPTIONAL MATCH (center)-[r1]-(n1)
                OPTIONAL MATCH (n1)-[r2]-(n2)
                RETURN center, r1, n1, r2, n2
            """

        res = self.client.query(cypher, {"id": entity_id}, graph_name=g_name)
        nodes_dict: Dict[str, GraphNode] = {}
        edges_set = set()
        edges_list: List[GraphEdge] = []

        def add_node(n):
            if n and hasattr(n, 'properties'):
                nid = n.properties.get("id")
                if nid and nid not in nodes_dict:
                    nlabel = n.properties.get("name") or n.properties.get("title") or nid
                    ntype = n.labels[0] if (hasattr(n, 'labels') and n.labels) else "Entity"
                    nodes_dict[nid] = GraphNode(id=nid, label=nlabel, type=ntype, properties=n.properties)

        def add_edge(rel, n_from, n_to):
            if rel and n_from and n_to:
                from_id = n_from.properties.get("id")
                to_id = n_to.properties.get("id")
                if from_id and to_id:
                    rel_type = rel.relation
                    edge_key = (from_id, rel_type, to_id)
                    if edge_key not in edges_set:
                        edges_set.add(edge_key)
                        edges_list.append(GraphEdge(
                            id=f"e_{from_id}_{rel_type}_{to_id}",
                            source=from_id,
                            target=to_id,
                            type=rel_type,
                            label=rel_type,
                            properties=rel.properties if hasattr(rel, 'properties') else {}
                        ))

        for row in res.result_set:
            center_n = row[0]
            add_node(center_n)
            if hops == 1:
                r, n1 = row[1], row[2]
                if n1:
                    add_node(n1)
                    if r:
                        # determine direction
                        if r.src_node == center_n.id:
                            add_edge(r, center_n, n1)
                        else:
                            add_edge(r, n1, center_n)
            else:
                r1, n1, r2, n2 = row[1], row[2], row[3], row[4]
                if n1:
                    add_node(n1)
                    if r1:
                        if r1.src_node == center_n.id:
                            add_edge(r1, center_n, n1)
                        else:
                            add_edge(r1, n1, center_n)
                if n2:
                    add_node(n2)
                    if r2 and n1:
                        if r2.src_node == n1.id:
                            add_edge(r2, n1, n2)
                        else:
                            add_edge(r2, n2, n1)

        return GraphNeighborhood(
            center_id=entity_id,
            nodes=list(nodes_dict.values()),
            edges=edges_list
        )

    def find_path(self, source_id: str, target_id: str, max_hops: int = 4) -> PathQueryResponse:
        """Find shortest path between two entities in FalkorDB with directional edges."""
        g_name = settings.GRAPH_NAME
        max_hops = max(1, min(6, int(max_hops)))

        # FalkorDB documented shortestPath in RETURN clause
        cypher = f"""
            MATCH (s {{id: $src}}), (t {{id: $tgt}})
            RETURN shortestPath((s)-[*..{max_hops}]-(t))
        """
        try:
            res = self.client.query(cypher, {"src": source_id, "tgt": target_id}, graph_name=g_name)
            if not res.result_set or not res.result_set[0] or not res.result_set[0][0]:
                return PathQueryResponse(
                    found=False,
                    nodes=[],
                    edges=[],
                    explanation=f"No documented path found between '{source_id}' and '{target_id}' within {max_hops} hops."
                )

            path = res.result_set[0][0]
            path_nodes = path.nodes() if callable(path.nodes) else path.nodes
            path_edges = path.edges() if callable(path.edges) else path.edges

            nodes_list = []
            text_segments = []
            for i, node in enumerate(path_nodes):
                nid = node.properties.get("id")
                nlabel = node.properties.get("name") or node.properties.get("title") or nid
                ntype = node.labels[0] if node.labels else "Entity"
                nodes_list.append(GraphNode(id=nid, label=nlabel, type=ntype, properties=node.properties))
                text_segments.append(f"{nlabel} ({ntype})")

            edges_list = []
            for i, rel in enumerate(path_edges):
                rel_type = rel.relation
                u = path_nodes[i]
                v = path_nodes[i+1]
                # Determine direction: u -> v or v -> u
                if rel.src_node == u.id and rel.dest_node == v.id:
                    src_id = u.properties.get("id")
                    tgt_id = v.properties.get("id")
                    dir_str = "→"
                else:
                    src_id = v.properties.get("id")
                    tgt_id = u.properties.get("id")
                    dir_str = "←"

                edges_list.append(GraphEdge(
                    id=f"p_edge_{i}",
                    source=src_id,
                    target=tgt_id,
                    type=rel_type,
                    label=rel_type,
                    properties={"direction": dir_str}
                ))

            explanation = " → ".join(text_segments)
            return PathQueryResponse(
                found=True,
                nodes=nodes_list,
                edges=edges_list,
                explanation=explanation
            )
        except Exception as e:
            logger.error(f"Error in find_path: {e}")
            return PathQueryResponse(
                found=False,
                nodes=[],
                edges=[],
                explanation=f"Graph path exploration error: {str(e)}"
            )

    def ingest_document(self, doc_data: Dict[str, Any], graph_name: Optional[str] = None) -> IngestDocResponse:
        """
        Store Document, scan title and content for references to existing entities,
        and create MENTIONS, ABOUT, AUTHORED, DOCUMENTED_IN edges.
        """
        g_name = graph_name or settings.GRAPH_NAME
        title = doc_data.get("title", "Untitled Document")
        doc_id = doc_data.get("id")
        if not doc_id:
            slug = re.sub(r'[^a-z0-9]', '_', title.lower().strip())
            doc_id = f"doc_{slug[:32]}_{str(uuid.uuid4())[:6]}"

        now_iso = datetime.now(timezone.utc).isoformat()
        content = doc_data.get("content", "")
        summary = doc_data.get("summary", content[:160] if content else "")
        author_id = doc_data.get("author_id")
        project_id = doc_data.get("project_id")
        system_id = doc_data.get("system_id")
        doc_type = doc_data.get("doc_type", "Document")

        # Upsert Document node
        self.client.query("""
            MERGE (d:Document {id: $id})
            SET d.title = $title, d.doc_type = $doc_type, d.summary = $summary,
                d.content = $content, d.url = $url, d.author_id = $author_id,
                d.project_id = $project_id, d.system_id = $system_id,
                d.created_at = $created_at, d.updated_at = $updated_at
        """, {
            "id": doc_id,
            "title": title,
            "doc_type": doc_type,
            "summary": summary,
            "content": content,
            "url": doc_data.get("url"),
            "author_id": author_id,
            "project_id": project_id,
            "system_id": system_id,
            "created_at": doc_data.get("created_at", now_iso),
            "updated_at": now_iso
        }, graph_name=g_name)

        new_edges: List[Dict[str, str]] = []

        # 1. Author edge
        if author_id:
            try:
                self.client.query(
                    "MATCH (e:Employee {id: $author_id}), (d:Document {id: $doc_id}) MERGE (e)-[:AUTHORED]->(d)",
                    {"author_id": author_id, "doc_id": doc_id},
                    graph_name=g_name
                )
                new_edges.append({"from": author_id, "type": "AUTHORED", "to": doc_id})
            except Exception as e:
                logger.debug(f"Author link failed: {e}")

        # 2. Project edge
        if project_id:
            try:
                self.client.query(
                    "MATCH (d:Document {id: $doc_id}), (p:Project {id: $project_id}) MERGE (d)-[:ABOUT]->(p)",
                    {"doc_id": doc_id, "project_id": project_id},
                    graph_name=g_name
                )
                new_edges.append({"from": doc_id, "type": "ABOUT", "to": project_id})
            except Exception as e:
                logger.debug(f"Project link failed: {e}")

        # 3. System edge
        if system_id:
            try:
                self.client.query(
                    "MATCH (d:Document {id: $doc_id}), (s:System {id: $system_id}) MERGE (d)-[:APPLIES_TO]->(s)",
                    {"doc_id": doc_id, "system_id": system_id},
                    graph_name=g_name
                )
                new_edges.append({"from": doc_id, "type": "APPLIES_TO", "to": system_id})
            except Exception as e:
                logger.debug(f"System link failed: {e}")

        # 4. Scan content for entity IDs and names
        full_text = f"{title}\n{summary}\n{content}"
        
        # Load all candidate entities to match
        r_ents = self.client.query("""
            MATCH (n)
            WHERE n.id IS NOT NULL AND (n.name IS NOT NULL OR n.title IS NOT NULL)
            RETURN labels(n)[0], n.id, coalesce(n.name, n.title)
        """, graph_name=g_name)

        candidates = r_ents.result_set if r_ents.result_set else []

        for label, eid, ename in candidates:
            if eid == doc_id:
                continue
            # Regex match ID or exact entity name
            id_pattern = rf"\b{re.escape(eid)}\b"
            name_pattern = rf"\b{re.escape(ename)}\b"
            if re.search(id_pattern, full_text, re.IGNORECASE) or (len(ename) >= 4 and re.search(name_pattern, full_text, re.IGNORECASE)):
                rel_type = "MENTIONS"
                if label == "Decision" or label == "Incident":
                    rel_type = "DOCUMENTED_IN"
                    cypher = f"MATCH (n:{label} {{id: $eid}}), (d:Document {{id: $doc_id}}) MERGE (n)-[:DOCUMENTED_IN]->(d)"
                    edge_record = {"from": eid, "type": "DOCUMENTED_IN", "to": doc_id}
                elif label == "Project":
                    rel_type = "ABOUT"
                    cypher = f"MATCH (d:Document {{id: $doc_id}}), (p:Project {{id: $eid}}) MERGE (d)-[:ABOUT]->(p)"
                    edge_record = {"from": doc_id, "type": "ABOUT", "to": eid}
                    # Also link project_id property on Document
                    self.client.query("MATCH (d:Document {id: $doc_id}) SET d.project_id = $eid", {"doc_id": doc_id, "eid": eid}, graph_name=g_name)
                elif label == "System":
                    rel_type = "APPLIES_TO"
                    cypher = f"MATCH (d:Document {{id: $doc_id}}), (s:System {{id: $eid}}) MERGE (d)-[:APPLIES_TO]->(s)"
                    edge_record = {"from": doc_id, "type": "APPLIES_TO", "to": eid}
                    self.client.query("MATCH (d:Document {id: $doc_id}) SET d.system_id = $eid", {"doc_id": doc_id, "eid": eid}, graph_name=g_name)
                else:
                    cypher = f"MATCH (d:Document {{id: $doc_id}}), (n:{label} {{id: $eid}}) MERGE (d)-[:MENTIONS]->(n)"
                    edge_record = {"from": doc_id, "type": "MENTIONS", "to": eid}

                try:
                    self.client.query(cypher, {"doc_id": doc_id, "eid": eid}, graph_name=g_name)
                    if edge_record not in new_edges:
                        new_edges.append(edge_record)
                except Exception as ex:
                    logger.debug(f"Link creation failed for {eid}: {ex}")

        # Incident reference parser e.g. "INC-104" -> inc_104
        inc_matches = re.findall(r'INC[-_](\d+)', full_text, re.IGNORECASE)
        for inc_num in inc_matches:
            inc_id = f"inc_{inc_num}"
            try:
                self.client.query(
                    "MATCH (i:Incident {id: $inc_id}), (d:Document {id: $doc_id}) MERGE (i)-[:DOCUMENTED_IN]->(d)",
                    {"inc_id": inc_id, "doc_id": doc_id},
                    graph_name=g_name
                )
                edge_rec = {"from": inc_id, "type": "DOCUMENTED_IN", "to": doc_id}
                if edge_rec not in new_edges:
                    new_edges.append(edge_rec)
            except Exception as ex:
                logger.debug(f"Incident link failed: {ex}")

        return IngestDocResponse(
            id=doc_id,
            title=title,
            new_edges=new_edges
        )

    def ingest_json(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """MERGE nodes and relationships into FalkorDB with labeled MERGE and true counts."""
        g_name = settings.GRAPH_NAME
        node_count = 0
        edge_count = 0

        # Merge nodes
        for cat, label in [
            ("departments", "Department"),
            ("skills", "Skill"),
            ("employees", "Employee"),
            ("projects", "Project"),
            ("systems", "System"),
            ("tasks", "Task"),
            ("documents", "Document"),
            ("decisions", "Decision"),
            ("incidents", "Incident"),
            ("tickets", "Ticket"),
            ("chat_threads", "ChatThread")
        ]:
            for item in data.get(cat, []):
                if not item.get("id"):
                    continue
                set_clauses = [f"n.{k} = ${k}" for k in item.keys() if k != "id"]
                set_str = ("SET " + ", ".join(set_clauses)) if set_clauses else ""
                self.client.query(f"MERGE (n:{label} {{id: $id}}) {set_str}", item, graph_name=g_name)
                node_count += 1

        # Merge relationships
        for rel in data.get("relationships", []):
            from_id = rel.get("from")
            to_id = rel.get("to")
            rel_type = rel.get("type")
            if not from_id or not to_id or not rel_type:
                continue
            if rel_type not in ALLOWED_REL_TYPES:
                continue

            from_label = derive_label(from_id)
            to_label = derive_label(to_id)
            if from_label != "Entity" and to_label != "Entity":
                cypher = f"MATCH (a:{from_label} {{id: $from_id}}), (b:{to_label} {{id: $to_id}}) MERGE (a)-[r:{rel_type}]->(b)"
            else:
                cypher = f"MATCH (a {{id: $from_id}}), (b {{id: $to_id}}) MERGE (a)-[r:{rel_type}]->(b)"
            self.client.query(cypher, {"from_id": from_id, "to_id": to_id}, graph_name=g_name)
            edge_count += 1

        return {
            "status": "success",
            "nodes_merged": node_count,
            "edges_merged": edge_count,
            "message": f"Merged {node_count} nodes and {edge_count} relationships into FalkorDB."
        }

    # Session Memory in the Graph (Phase 3 requirement)
    def record_session_turn(self, session_id: str, question: str, answer: str, cited_entity_ids: List[str], focus_id: Optional[str] = None):
        """Persist session turn in graph: (Session)-[:ASKED]->(Question)-[:ANSWERED_WITH]->(Answer), (Answer)-[:CITED]->(entity)."""
        g_name = settings.GRAPH_NAME
        turn_id = str(uuid.uuid4())[:8]
        q_id = f"q_{turn_id}"
        ans_id = f"ans_{turn_id}"
        now_iso = datetime.now(timezone.utc).isoformat()
        f_id = focus_id or (cited_entity_ids[0] if cited_entity_ids else "")

        cypher = """
            MERGE (s:Session {id: $session_id})
            CREATE (q:Question {id: $q_id, text: $question, created_at: $timestamp, focus_id: $focus_id})
            CREATE (a:Answer {id: $ans_id, text: $answer, created_at: $timestamp, focus_id: $focus_id})
            MERGE (s)-[:ASKED]->(q)
            MERGE (q)-[:ANSWERED_WITH]->(a)
        """
        self.client.query(cypher, {
            "session_id": session_id,
            "q_id": q_id,
            "question": question,
            "ans_id": ans_id,
            "answer": answer,
            "timestamp": now_iso,
            "focus_id": f_id
        }, graph_name=g_name)

        for eid in cited_entity_ids:
            try:
                self.client.query("""
                    MATCH (a:Answer {id: $ans_id}), (target {id: $eid})
                    MERGE (a)-[:CITED]->(target)
                """, {"ans_id": ans_id, "eid": eid}, graph_name=g_name)
            except Exception as e:
                logger.debug(f"Failed to cite entity {eid}: {e}")

    def get_session_history(self, session_id: str, limit: int = 5) -> SessionDetail:
        """Retrieve recent session history for context carrying."""
        g_name = settings.GRAPH_NAME
        cypher = """
            MATCH (s:Session {id: $session_id})-[:ASKED]->(q:Question)-[:ANSWERED_WITH]->(a:Answer)
            OPTIONAL MATCH (a)-[:CITED]->(target)
            RETURN q.text, a.text, q.created_at, collect(DISTINCT target.id), a.focus_id
            ORDER BY q.created_at DESC
            LIMIT $limit
        """
        res = self.client.query(cypher, {"session_id": session_id, "limit": limit}, graph_name=g_name)
        turns = []
        for row in reversed(res.result_set if res.result_set else []):
            turns.append(SessionTurn(
                question=row[0],
                answer=row[1],
                timestamp=row[2],
                cited_entity_ids=[cid for cid in row[3] if cid],
                focus_id=row[4] if len(row) > 4 and row[4] else None
            ))
        return SessionDetail(session_id=session_id, turn_count=len(turns), turns=turns)

graph_service = GraphService()
